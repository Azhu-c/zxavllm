# SPDX-License-Identifier: Apache-2.0
"""Ascend-owned runtime extension; never writes to the vLLM installation."""
from __future__ import annotations

import asyncio
import contextlib
import functools
import hashlib
import importlib
import inspect
from pathlib import Path
import threading

from vllm_ascend.core.kv_blocks_routing import (
    choose_rank,
    enabled,
    extension_active,
    route_log_enabled,
    snapshot,
    step_log_enabled,
    timeout_seconds,
    validate_config,
    validate_states,
)

_LOCK = threading.RLock()
_SOURCE_HASHES = {
    "vllm.v1.engine.core": "f9625f331b65be39b14e65e0c0a360d6515d9147777bf7b9cdc2d8bc5eafa622",
    "vllm.v1.engine.core_client": "afb2b627cf9ef861f05b411494156cc6ad5076ea770c6f2a4c8a941ca82103ec",
}
_EXPECTED_CLIENT_METHODS = {'DPLBAsyncMPClient.__init__': '692568c140acbdb0e02f0c5df7034e3e917cd19bbcbbc70bd05392ad10ca17f0', 'DPLBAsyncMPClient.get_core_engine_for_request': 'f9f091f3c1ab38c4de60ff58e216379bd6587570ac9bc3862c74ff9134f06255', 'DPLBAsyncMPClient.process_engine_outputs': '332aeb5b222ce1b73780f1858a210fc1c70ef0e10237010b28280647ffa9b5f8', 'DPLBAsyncMPClient.abort_requests_async': '2e9995eeef2cc91a9243876dbd557390a4bce110b9925aa9087898be5554bffe', 'DPAsyncMPClient.add_request_async': 'e937266fd11defc5e6980b72acf05e33e8531f0b51e0d1d8c0f66016b4c24269', 'AsyncMPClient._call_utility_async': '72f6f12f61197b0f3f3c1c3c5aa80d2b0bad3a21e26dac4102b41e8c0cde7ce9'}


def _verify_source(module) -> None:
    if hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest() != _SOURCE_HASHES[module.__name__]:
        raise RuntimeError(
            f"Unsupported {module.__name__}: expected original vLLM 58d3918. "
            "Restore the previous vLLM-source patch before using the Ascend extension."
        )


class KVBlocksRoutingClientMixin:
    """Reuse upstream send, wave, lifecycle and abort handling through super()."""

    def __init__(self, vllm_config, executor_class, log_stats, client_addresses=None,
                 client_count=1, client_index=0):
        if enabled() or route_log_enabled():
            validate_config(vllm_config, client_count)
        self._kv_blocks_lock = asyncio.Lock()
        self._kv_blocks_next_engine = None
        self._kv_blocks_snapshot = None
        self._kv_blocks_sequence = 0
        self._kv_blocks_pending_requests = set()
        self._kv_blocks_aborted_requests = set()
        super().__init__(vllm_config, executor_class, log_stats,
                         client_addresses, client_count, client_index)

    async def add_request_async(self, request):
        if not enabled() and not route_log_enabled():
            return await super().add_request_async(request)
        request_id = request.request_id
        self._kv_blocks_pending_requests.add(request_id)
        try:
            await self._add_request_with_kv_blocks_async(request)
        finally:
            self._kv_blocks_pending_requests.discard(request_id)
            self._kv_blocks_aborted_requests.discard(request_id)

    async def _add_request_with_kv_blocks_async(self, request):
        async with self._kv_blocks_lock:
            if request.request_id in self._kv_blocks_aborted_requests:
                return
            ranks = list(self.engine_ranks_managed)
            if ranks != list(range(self.vllm_config.parallel_config.data_parallel_size)):
                raise RuntimeError("KV-block routing must cover every Decode rank")
            routing = enabled()
            try:
                states, totals = await self._pull_kv_blocks_states()
            except Exception as error:
                if routing:
                    raise
                # A diagnostic failure must not reject a native-routed request.
                from vllm.logger import logger

                logger.warning("[kv_blocks_observer] Native routing snapshot unavailable: %s", error)
                states, totals = [], None
            if request.request_id in self._kv_blocks_aborted_requests:
                return
            preferred = request.data_parallel_rank
            if preferred is None:
                from vllm.v1.pool.late_interaction import get_late_interaction_engine_index

                preferred = get_late_interaction_engine_index(request.pooling_params, len(ranks))
            selected = choose_rank(totals, self.eng_start_index, preferred) if routing else None
            self._kv_blocks_sequence += 1
            self._kv_blocks_next_engine = selected
            self._kv_blocks_snapshot = (states, totals, ranks, preferred is not None, routing)
            try:
                # Upstream ADD and the next state RPC share the per-engine FIFO.
                # The next pull observes earlier dispatched ADDs, or their completion.
                await super().add_request_async(request)
                if routing:
                    self.eng_start_index = (selected + 1) % len(ranks)
            finally:
                self._kv_blocks_next_engine = None
                self._kv_blocks_snapshot = None

    async def _pull_kv_blocks_states(self):
        tasks = [
            asyncio.create_task(self._call_utility_async(
                "get_ascend_kv_blocks_routing_state", engine=engine
            ))
            for engine in self.core_engines
        ]
        pull = asyncio.gather(*tasks)
        try:
            states = await asyncio.wait_for(pull, timeout=timeout_seconds())
        finally:
            for task in tasks:
                if not task.done():
                    task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await pull
            await asyncio.gather(*tasks, return_exceptions=True)
        return states, validate_states(states, list(self.engine_ranks_managed))

    def get_core_engine_for_request(self, request):
        if self._kv_blocks_snapshot is None:
            if enabled():
                raise RuntimeError("KV-block routing requires a fresh global pull")
            return super().get_core_engine_for_request(request)
        states, totals, ranks, pinned, routing = self._kv_blocks_snapshot
        if routing:
            if self._kv_blocks_next_engine is None:
                raise RuntimeError("KV-block routing requires a fresh global pull")
            # Let the original selector perform its own lifecycle bookkeeping.
            original_rank = request.data_parallel_rank
            request.data_parallel_rank = self._kv_blocks_next_engine
            try:
                chosen = super().get_core_engine_for_request(request)
            finally:
                request.data_parallel_rank = original_rank
        else:
            # Native policy, tie-breaking and count updates are all performed
            # by the original selector exactly once. KV totals are only logged.
            chosen = super().get_core_engine_for_request(request)
        if route_log_enabled():
            from vllm.logger import logger

            selected = self.core_engines.index(chosen)
            logger.info(
                "[kv_blocks_route] seq=%d totals=%s selected=DP%d pinned=%s policy=%s",
                self._kv_blocks_sequence, totals if totals is not None else "unavailable",
                ranks[selected], pinned, "kv_aware" if routing else "native",
            )
            for state in states:
                _log_state(logger, "kv_blocks_route", state, f"seq={self._kv_blocks_sequence}")
        return chosen

    async def abort_requests_async(self, request_ids):
        if enabled() or route_log_enabled():
            self._kv_blocks_aborted_requests.update(
                request_id for request_id in request_ids
                if request_id in self._kv_blocks_pending_requests
            )
        return await super().abort_requests_async(request_ids)

    async def prepare_elastic_ep(self, new_data_parallel_size):
        if enabled() or route_log_enabled():
            raise RuntimeError("Disable KV-block routing before changing DP topology")
        return await super().prepare_elastic_ep(new_data_parallel_size)


def _log_state(logger, tag, state, label):
    running, waiting = state["running_blocks"], state["waiting_blocks"]
    logger.info(
        "[%s] %s DP%d | Run(%d): %s | Wait(%d): %s | total=%d block_size=%d",
        tag, label, state["rank"], len(running), running, len(waiting), waiting,
        sum(running) + sum(waiting), state["block_size"],
    )


def install_client_hooks():
    # Called from NPUPlatform.check_and_update_config, after normal imports
    # and before EngineCoreClient.make_async_mp_client creates the client.
    with _LOCK:
        module = importlib.import_module("vllm.v1.engine.core_client")
        if getattr(module, "_ascend_kv_blocks_routing_installed", False):
            return
        _verify_source(module)
        for dotted_name, expected in _EXPECTED_CLIENT_METHODS.items():
            class_name, method_name = dotted_name.split(".")
            method = getattr(getattr(module, class_name), method_name)
            actual = hashlib.sha256(inspect.getsource(method).encode()).hexdigest()
            if actual != expected:
                raise RuntimeError(f"Another extension changed {dotted_name}; refusing to combine routers")
        original_class = module.DPLBAsyncMPClient
        if original_class.__module__ != module.__name__:
            raise RuntimeError("Another extension already replaced the DP client class")
        original_factory = module.EngineCoreClient.make_async_mp_client
        client_class = type(
            "AscendKVBlocksDPLBAsyncMPClient", (KVBlocksRoutingClientMixin, original_class),
            {"__module__": __name__},
        )

        @functools.wraps(original_factory)
        def factory(vllm_config, executor_class, log_stats, client_addresses=None,
                    client_count=1, client_index=0):
            if enabled() or route_log_enabled():
                validate_config(vllm_config, client_count)
            return original_factory(vllm_config, executor_class, log_stats,
                                    client_addresses, client_count, client_index)

        globals()[client_class.__name__] = client_class
        module.DPLBAsyncMPClient = client_class
        module.EngineCoreClient.make_async_mp_client = staticmethod(factory)
        module._ascend_kv_blocks_routing_installed = True


def install_engine_hooks():
    # Global Ascend patches are loaded in engine-core subprocesses too.
    # Do not import core_client here: it may still be importing core.
    with _LOCK:
        module = importlib.import_module("vllm.v1.engine.core")
        if getattr(module, "_ascend_kv_blocks_routing_installed", False):
            return
        _verify_source(module)
        if hasattr(module.EngineCore, "get_ascend_kv_blocks_routing_state"):
            raise RuntimeError("An incompatible Ascend KV-block RPC already exists")
        original_step = module.EngineCoreProc._process_engine_step

        def get_state(self):
            return snapshot(self.scheduler, self.dp_rank)

        @functools.wraps(original_step)
        def step(self):
            if step_log_enabled():
                from vllm.logger import logger

                label = f"wave={self.current_wave} step={self.step_counter}"
                _log_state(logger, "kv_blocks_step", get_state(self), label)
            return original_step(self)

        module.EngineCore.get_ascend_kv_blocks_routing_state = get_state
        module.EngineCoreProc._process_engine_step = step
        module._ascend_kv_blocks_routing_installed = True


def install_for_config(vllm_config):
    if not extension_active():
        return
    validate_config(vllm_config, 1)
    install_engine_hooks()
    if enabled() or route_log_enabled():
        install_client_hooks()


# This module is imported by the existing Ascend global-patch mechanism.
# The separate config hook handles API-client setup without circular imports.
if extension_active():
    install_engine_hooks()
