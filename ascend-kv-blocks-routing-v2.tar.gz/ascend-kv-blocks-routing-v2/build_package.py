"""Build a reviewable patch against the recorded Ascend branch."""
import ast
from difflib import unified_diff
import hashlib
import json
from pathlib import Path

from edit_sources import FILES, INIT, PLATFORM, update_init, update_platform

ROOT = Path(__file__).resolve().parent
BASE_BLOBS = {
    PLATFORM: "088d67f31354c96f6ee334b5bcd031f312cf0f04",
    INIT: "cb77376726ad81775bbec5be67156fb00f202678",
}
for name, transform in ((PLATFORM, update_platform), (INIT, update_init)):
    data = (ROOT / "base" / name).read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    assert blob == BASE_BLOBS[name], (name, blob)
    path = ROOT / "modified" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(transform(data.decode()))

manifest = {
    "package": "ascend-kv-blocks-routing-v2",
    "vllm_read_only_commit": "58d3918e3ea0a544ffedadad2ba84559e9c51d8f",
    "reference_ascend_commit": "ac22f968735a9f3af60f5833e4f63c7cc1a9e3d2",
    "files": {},
    "vllm_read_only_sha256": {},
}
for fixture, name in (("core.txt", "vllm/v1/engine/core.py"),
                      ("core_client.txt", "vllm/v1/engine/core_client.py"),
                      ("envs.txt", "vllm/envs.py")):
    manifest["vllm_read_only_sha256"][name] = hashlib.sha256((ROOT / "tests/fixtures" / fixture).read_bytes()).hexdigest()
patch = []
for name in FILES:
    data = (ROOT / "modified" / name).read_text()
    ast.parse(data)
    before_path = ROOT / "base" / name
    before = before_path.read_text() if before_path.exists() else ""
    manifest["files"][name] = hashlib.sha256(data.encode()).hexdigest()
    patch.extend(unified_diff(before.splitlines(True), data.splitlines(True),
                              fromfile="a/" + name if before_path.exists() else "/dev/null",
                              tofile="b/" + name))
(ROOT / "ascend-only.patch").write_text("".join(patch))
(ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print("Built Ascend-only patch: all four source paths are under vllm_ascend/")
