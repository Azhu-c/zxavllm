from __future__ import annotations
import asyncio
import copy
import json
import random
import sys
from types import SimpleNamespace as NS
import unittest

from runtime_fixtures import helper, patch, make_client, make_modules, config, req, scheduler, load, ROOT

class SnapshotTests(unittest.IsolatedAsyncioTestCase):
    async def test_config_hook_runs_and_factory_is_static_and_idempotent(self):
        import ast
        client, env, log = make_client()
        module = sys.modules["vllm.v1.engine.core_client"]
        selected_class = module.DPLBAsyncMPClient
        self.assertIsInstance(client, patch.KVBlocksRoutingClientMixin)
        self.assertIsInstance(module.EngineCoreClient.__dict__["make_async_mp_client"], staticmethod)
        tree = ast.parse((ROOT / "modified/vllm_ascend/platform.py").read_text())
        method = next(node for cls in tree.body if isinstance(cls, ast.ClassDef) and cls.name == "NPUPlatform"
                      for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == "check_and_update_config")
        # Execute the actual two inserted statements, not a copy of the hook.
        hook = ast.Module(body=method.body[:2], type_ignores=[])
        exec(compile(hook, "platform.py", "exec"), {"vllm_config": config()})
        self.assertIs(module.DPLBAsyncMPClient, selected_class)
        with self.assertRaisesRegex(ValueError, "api-server-count 1"):
            module.EngineCoreClient.make_async_mp_client(config(), None, False, client_count=2)

    async def test_step_log_wraps_existing_step_and_preserves_it(self):
        client, env, log = make_client(2)
        module = sys.modules["vllm.v1.engine.core"]
        core = module.EngineCoreProc()
        core.scheduler = scheduler([req(129)], skipped=[req(257)])
        core.current_wave, core.step_counter, core.dp_rank = 3, 7, 1
        calls = []
        def step():
            self.assertEqual(len(log.lines), 1)
            calls.append("step")
            return {}, True
        core.step_fn = step
        core.post_step = lambda executed: calls.append("post")
        env.VLLM_ASCEND_KV_BLOCKS_STEP_LOG = True
        self.assertTrue(core._process_engine_step())
        self.assertIn("wave=3 step=7 DP1 | Run(1): [2] | Wait(1): [3]", log.lines[0])
        env.VLLM_ASCEND_KV_BLOCKS_STEP_LOG = False
        self.assertTrue(core._process_engine_step())
        self.assertEqual(calls, ["step", "post", "step", "post"])

    async def test_engine_bootstrap_does_not_import_partial_client(self):
        client, env, log = make_client()
        core, module = make_modules(log)
        del module.DPLBAsyncMPClient  # model a client import paused on importing core
        fresh = load("ascend_kv_patch_bootstrap_test", ROOT / "modified/vllm_ascend/patch/platform/patch_kv_blocks_routing.py")
        self.assertTrue(core._ascend_kv_blocks_routing_installed)
        self.assertFalse(hasattr(module, "_ascend_kv_blocks_routing_installed"))
        self.assertTrue(hasattr(core.EngineCore, "get_ascend_kv_blocks_routing_state"))

    async def test_rejects_another_router_changed_method(self):
        client, env, log = make_client()
        core, module = make_modules(log)
        module.DPLBAsyncMPClient.get_core_engine_for_request = lambda self, request: None
        with self.assertRaisesRegex(RuntimeError, "refusing to combine routers"):
            patch.install_client_hooks()

    def test_dyntralb_formula_and_all_waiting_statuses(self):
        state = helper.snapshot(scheduler(
            [req(1), req(128), req(129)], [req(256)], [req(257), req(0)]), 2)
        self.assertEqual(state["running_blocks"], [1, 1, 2])
        self.assertEqual(state["waiting_blocks"], [2, 3, 0])
        self.assertEqual(state["block_size"], 128)
        self.assertEqual(helper.validate_states([state], [2]), [9])

    def test_no_snapshot_truncation(self):
        state = helper.snapshot(scheduler(waiting=[req(1) for _ in range(1500)]), 0)
        self.assertEqual(len(state["waiting_blocks"]), 1500)

    def test_invalid_block_size(self):
        for value in (0, -1, True, None, 128.0):
            with self.assertRaises(RuntimeError):
                helper.snapshot(scheduler(block_size=value), 0)

    def test_json_round_trip_and_total_includes_waiting(self):
        states = [helper.snapshot(scheduler([req(128)], [req(2560)]), 0),
                  helper.snapshot(scheduler([req(512)]), 1)]
        states = json.loads(json.dumps(states))
        totals = helper.validate_states(states, [0, 1])
        self.assertEqual(totals, [21, 4])
        self.assertEqual(helper.choose_rank(totals, 0, None), 1)

    def test_invalid_and_incomplete_states(self):
        valid = [helper.snapshot(scheduler(), rank) for rank in range(2)]
        variants = [valid[:1], valid[::-1], [None, valid[1]]]
        for key, value in (("running_blocks", [-1]), ("waiting_blocks", [True]),
                           ("waiting_blocks", [1.5]), ("version", 2),
                           ("block_size", 0), ("block_size", 256)):
            bad = copy.deepcopy(valid)
            bad[0][key] = value
            variants.append(bad)
        for states in variants:
            with self.assertRaises(RuntimeError):
                helper.validate_states(states, [0, 1])

    def test_ties_rotate_and_pins_are_preserved(self):
        self.assertEqual(helper.choose_rank([4, 1, 1], 2, None), 2)
        self.assertEqual(helper.choose_rank([4, 1, 1], 0, 0), 0)
        for rank in (-1, 3, True):
            with self.assertRaises(ValueError):
                helper.choose_rank([0, 0, 0], 0, rank)

    def test_supported_topology_and_rejections(self):
        helper.validate_config(config(), 1, routing=True)
        variants = []
        for key, value in (("data_parallel_size", 1), ("data_parallel_external_lb", True),
                           ("data_parallel_hybrid_lb", True)):
            item = config()
            setattr(item.parallel_config, key, value)
            variants.append(item)
        item = config()
        item.kv_transfer_config.kv_role = "kv_producer"
        variants.append(item)
        item = config()
        item.additional_config = {"scheduler_config": {"dyntra_lb_config": {"enabled": True}}}
        variants.append(item)
        for item in variants:
            with self.assertRaises(ValueError):
                helper.validate_config(item, 1, routing=True)
        with self.assertRaisesRegex(ValueError, "api-server-count 1"):
            helper.validate_config(config(), 2, routing=True)


class RoutingTests(unittest.IsolatedAsyncioTestCase):
    async def test_native_observer_logs_original_policy_not_kv_minimum(self):
        client, env, log = make_client(2, enabled=False, observe=True)
        client.schedulers[client.core_engines[0]].running = [req(12800)]
        client.schedulers[client.core_engines[1]].running = [req(128)]
        client.lb_engines = [[0, 0, 0.0], [0, 1, 0.0]]
        request = req(128, "native")
        await client.add_request_async(request)
        self.assertEqual(client.sent, [("native", client.core_engines[0])])
        self.assertIsNone(request.data_parallel_rank)
        self.assertEqual(client.engine_inflight[client.core_engines[0]], 1)
        self.assertIn("totals=[100, 1] selected=DP0 pinned=False policy=native", log.lines[0])
        self.assertEqual(len(log.lines), 3)
        self.assertEqual(client.pulls, 2)

    async def test_native_observer_preserves_controlled_burst_choices(self):
        baseline, _, _ = make_client(3, enabled=False)
        observed, _, log = make_client(3, enabled=False, observe=True)
        for index in range(30):
            await baseline.add_request_async(req(128, str(index)))
            await observed.add_request_async(req(128, str(index)))
        self.assertEqual(baseline.sent, observed.sent)
        self.assertEqual(baseline.engine_inflight, observed.engine_inflight)
        self.assertEqual(baseline.lb_engines, observed.lb_engines)
        self.assertEqual(baseline.eng_start_index, observed.eng_start_index)
        self.assertEqual(observed.pulls, 90)
        self.assertTrue(all("policy=native" in line for line in log.lines if "selected=" in line))

    async def test_native_observer_rpc_failures_do_not_reject_native_request(self):
        for failure in ("rank", "timeout", "invalid"):
            client, env, log = make_client(2, enabled=False, observe=True)
            if failure == "rank":
                client.fail_engine = client.core_engines[1]
            elif failure == "timeout":
                client.pull_delay = 0.03
                env.VLLM_ASCEND_KV_BLOCKS_TIMEOUT_S = 0.001
            else:
                client.bad_states = True
            await client.add_request_async(req(128, failure))
            self.assertEqual(client.sent, [(failure, client.core_engines[0])])
            self.assertTrue(any("totals=unavailable selected=DP0" in line for line in log.lines))
            self.assertTrue(any("snapshot unavailable" in line for line in log.lines))

    async def test_native_observer_preserves_pinned_and_abort_paths(self):
        client, env, log = make_client(3, enabled=False, observe=True)
        await client.add_request_async(req(128, "pinned", rank=2))
        self.assertEqual(client.sent, [("pinned", client.core_engines[2])])
        self.assertIn("pinned=True policy=native", log.lines[0])
        await client.abort_requests_async(["pinned"])
        self.assertEqual(client.events[-1], ("ABORT", client.core_engines[2], ["pinned"]))
        client.pull_delay = 0.02
        task = asyncio.create_task(client.add_request_async(req(128, "cancel")))
        await asyncio.sleep(0.001)
        await client.abort_requests_async(["cancel"])
        await task
        self.assertEqual(len(client.sent), 1)

    async def test_step_logging_alone_works_without_client_observer(self):
        client, env, log = make_client(2, enabled=False, step_log=True)
        self.assertNotIsInstance(client, patch.KVBlocksRoutingClientMixin)
        await client.add_request_async(req(128))
        self.assertEqual(client.pulls, 0)
        module = sys.modules["vllm.v1.engine.core"]
        core = module.EngineCoreProc()
        core.scheduler = scheduler([req(129)])
        core.current_wave, core.step_counter, core.dp_rank = 0, 8, 1
        core.step_fn = lambda: ({}, True)
        core.post_step = lambda executed: None
        core._process_engine_step()
        self.assertEqual(len(log.lines), 1)
        self.assertIn("[kv_blocks_step] wave=0 step=8 DP1", log.lines[0])

    async def test_native_observer_can_observe_dyntralb_disabled_policy_switch(self):
        client, env, log = make_client(enabled=False, observe=True)
        cfg = config()
        cfg.additional_config = {"scheduler_config": {"dyntra_lb_config": {"enabled": True}}}
        helper.validate_config(cfg, 1, routing=False)
        with self.assertRaises(ValueError):
            helper.validate_config(cfg, 1, routing=True)

    async def test_unset_log_flag_defaults_off_for_native_and_on_for_kv(self):
        import os
        from unittest.mock import patch as mock_patch
        with mock_patch.dict(os.environ, {}, clear=True):
            self.assertFalse(helper.extension_active())
            self.assertFalse(helper.route_log_enabled())
            os.environ["VLLM_ASCEND_KV_BLOCKS_ROUTING"] = "1"
            self.assertTrue(helper.extension_active())
            self.assertTrue(helper.route_log_enabled())

    async def test_next_request_sees_previous_add_through_fifo(self):
        client, _, _ = make_client()
        for engine, count in zip(client.core_engines, (10, 1, 3)):
            client.schedulers[engine].running = [req(count * 128)]
        await client.add_request_async(req(9 * 128, "large"))
        self.assertEqual([engine for _, engine in client.sent], [client.core_engines[1]])
        # No fake immediate load increment: first ADD is still in the FIFO.
        self.assertEqual(len(client.pending[client.core_engines[1]]), 1)
        await client.add_request_async(req(128, "next"))
        self.assertEqual([engine for _, engine in client.sent], client.core_engines[1:])
        self.assertEqual(client.pulls, 6)

    async def test_concurrent_burst_matches_sequential_global_minimum(self):
        client, _, log = make_client(8)
        randomizer = random.Random(922)
        counts = [randomizer.randint(1, 45) for _ in range(100)]
        await asyncio.gather(*[
            client.add_request_async(req(count * 128, str(index)))
            for index, count in enumerate(counts)
        ])
        totals = [0] * 8
        for request_id, engine in client.sent:
            rank = int.from_bytes(engine, "little")
            self.assertEqual(totals[rank], min(totals))
            totals[rank] += counts[int(request_id)]
        self.assertEqual(client.pulls, 800)
        self.assertEqual(client.max_active_pulls, 8)
        self.assertEqual(len(client.reqs_in_flight), 100)
        self.assertEqual(sum(client.engine_inflight.values()), 100)
        self.assertEqual(len(log.lines), 900)
        self.assertTrue(any("DP7 | Run(0): [] | Wait(" in line for line in log.lines))

    async def test_finished_request_load_is_refreshed(self):
        client, _, _ = make_client(2)
        client.schedulers[client.core_engines[0]].running = [req(1280)]
        await client.add_request_async(req(128, "a"))
        client.schedulers[client.core_engines[0]].running.clear()
        await client.add_request_async(req(128, "b"))
        self.assertEqual(client.sent, [("a", client.core_engines[1]), ("b", client.core_engines[0])])

    async def test_explicit_and_special_affinity(self):
        for kwargs in ({"rank": 2}, {"pooling": 2}):
            client, _, log = make_client()
            client.schedulers[client.core_engines[2]].running = [req(12800)]
            await client.add_request_async(req(128, **kwargs))
            self.assertEqual(client.sent[0][1], client.core_engines[2])
            self.assertEqual(client.pulls, 3)
            self.assertIn("pinned=True", log.lines[0])

    async def test_timeout_failure_and_invalid_snapshot_send_nothing(self):
        for failure in ("timeout", "rank", "invalid", "missing"):
            client, env, _ = make_client()
            if failure == "timeout":
                env.VLLM_ASCEND_KV_BLOCKS_TIMEOUT_S = 0.001
                client.pull_delay = 0.02
            elif failure == "rank":
                client.fail_engine = client.core_engines[1]
            elif failure == "invalid":
                client.bad_states = True
            else:
                client.engine_ranks_managed = [0, 1]
            with self.assertRaises((RuntimeError, asyncio.TimeoutError)):
                await client.add_request_async(req(128))
            self.assertEqual(client.sent, [])
            self.assertEqual(client.reqs_in_flight, {})
            self.assertFalse(client._kv_blocks_lock.locked())

    async def test_cancel_during_pull_releases_lock_and_sends_nothing(self):
        client, _, _ = make_client()
        client.pull_delay = 0.03
        task = asyncio.create_task(client.add_request_async(req(128, "cancel")))
        await asyncio.sleep(0.001)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assertEqual(client.sent, [])
        self.assertFalse(client._kv_blocks_lock.locked())
        client.pull_delay = 0
        await client.add_request_async(req(128, "ok"))
        self.assertEqual(client.sent, [("ok", client.core_engines[0])])

    async def test_abort_during_pull_or_while_waiting_for_lock(self):
        client, _, _ = make_client()
        client.pull_delay = 0.02
        first = asyncio.create_task(client.add_request_async(req(128, "pulling")))
        second = asyncio.create_task(client.add_request_async(req(128, "queued")))
        await asyncio.sleep(0.001)
        await client.abort_requests_async(["pulling", "queued"])
        await asyncio.gather(first, second)
        self.assertEqual(client.sent, [])
        self.assertEqual(client.reqs_in_flight, {})
        self.assertEqual(client._kv_blocks_pending_requests, set())
        self.assertEqual(client._kv_blocks_aborted_requests, set())

    async def test_abort_after_dispatch_keeps_upstream_rank_routing(self):
        client, _, _ = make_client()
        await client.add_request_async(req(128, "sent", rank=2))
        await client.abort_requests_async(["sent"])
        self.assertEqual(client.events[-1], ("ABORT", client.core_engines[2], ["sent"]))
        self.assertEqual(client.pending[client.core_engines[2]], [])

    async def test_disabled_uses_upstream_routing_without_pulls_or_logs(self):
        client, _, log = make_client(enabled=False)
        await client.add_request_async(req(128, "a"))
        await client.add_request_async(req(128, "b"))
        self.assertEqual([engine for _, engine in client.sent], client.core_engines[:2])
        self.assertEqual(client.pulls, 0)
        self.assertEqual(log.lines, [])

    async def test_cannot_route_without_pull_or_change_topology(self):
        client, _, _ = make_client()
        with self.assertRaisesRegex(RuntimeError, "fresh global pull"):
            client.get_core_engine_for_request(req(128))
        with self.assertRaisesRegex(RuntimeError, "changing DP topology"):
            await client.prepare_elastic_ep(4)

    async def test_finished_outputs_preserve_upstream_tracking(self):
        client, _, _ = make_client()
        await client.add_request_async(req(128, "done"))
        engine = client.reqs_in_flight["done"]
        await type(client).process_engine_outputs(client, NS(finished_requests=["done"]))
        self.assertNotIn("done", client.reqs_in_flight)
        self.assertEqual(client.engine_inflight[engine], 0)

    async def test_logging_can_be_disabled(self):
        client, env, log = make_client()
        env.VLLM_ASCEND_KV_BLOCKS_LOG = False
        await client.add_request_async(req(128))
        self.assertEqual(client.pulls, 3)
        self.assertEqual(log.lines, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
