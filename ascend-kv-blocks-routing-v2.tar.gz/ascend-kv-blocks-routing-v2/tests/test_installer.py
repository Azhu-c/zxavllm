import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
FILES = json.loads((ROOT / "manifest.json").read_text())["files"]


def hashes(root):
    return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in root.rglob("*") if path.is_file()}


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="ascend-kv-routing-test-")
        directory = Path(self.temporary.name)
        self.ascend = directory / "ascend"
        self.vllm = directory / "vllm"
        shutil.copytree(ROOT / "base", self.ascend)
        for fixture, name in (("envs", "vllm/envs.py"), ("core", "vllm/v1/engine/core.py"),
                              ("core_client", "vllm/v1/engine/core_client.py")):
            path = self.vllm / name
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ROOT / "tests/fixtures" / (fixture + ".txt"), path)

    def tearDown(self):
        self.temporary.cleanup()

    def run_installer(self, *args, success=True):
        result = subprocess.run([sys.executable, str(ROOT / "apply.py"),
                                 "--ascend-root", str(self.ascend), "--vllm-root", str(self.vllm),
                                 *map(str, args)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0 if success else 1, result.stdout + result.stderr)
        return result

    def test_check_writes_neither_repository(self):
        before_ascend, before_vllm = hashes(self.ascend), hashes(self.vllm)
        self.run_installer("--check")
        self.assertEqual(hashes(self.ascend), before_ascend)
        self.assertEqual(hashes(self.vllm), before_vllm)

    def test_only_ascend_writes_and_restore_exact(self):
        before_ascend, before_vllm = hashes(self.ascend), hashes(self.vllm)
        self.run_installer("--apply")
        self.assertEqual(hashes(self.vllm), before_vllm)
        for name in FILES:
            self.assertTrue(name.startswith("vllm_ascend/"))
            self.assertTrue((self.ascend / name).exists())
        installed = hashes(self.ascend)
        self.run_installer("--apply")
        self.assertEqual(hashes(self.ascend), installed)
        backup = next(self.ascend.glob("ascend-kv-blocks-routing-backup-*"))
        self.run_installer("--restore", backup)
        restored = {name: value for name, value in hashes(self.ascend).items()
                    if not name.startswith(backup.name + "/")}
        self.assertEqual(restored, before_ascend)
        self.assertEqual(hashes(self.vllm), before_vllm)

    def test_preserves_user_branch_edits(self):
        for name in ("vllm_ascend/platform.py", "vllm_ascend/patch/platform/__init__.py"):
            path = self.ascend / name
            path.write_text(path.read_text() + "\n# existing user DyntraLB branch change\n")
        before = hashes(self.ascend)
        self.run_installer("--apply")
        for name in ("vllm_ascend/platform.py", "vllm_ascend/patch/platform/__init__.py"):
            self.assertIn("# existing user DyntraLB branch change", (self.ascend / name).read_text())
        backup = next(self.ascend.glob("ascend-kv-blocks-routing-backup-*"))
        self.run_installer("--restore", backup)
        restored = {name: value for name, value in hashes(self.ascend).items()
                    if not name.startswith(backup.name + "/")}
        self.assertEqual(restored, before)

    def test_old_vllm_source_patch_is_rejected_without_writes(self):
        path = self.vllm / "vllm/v1/engine/core_client.py"
        path.write_text(path.read_text() + "# previous patch\n")
        before_ascend, before_vllm = hashes(self.ascend), hashes(self.vllm)
        self.run_installer("--apply", success=False)
        self.assertEqual(hashes(self.ascend), before_ascend)
        self.assertEqual(hashes(self.vllm), before_vllm)

    def test_cannot_install_in_vllm_tree(self):
        result = subprocess.run([sys.executable, str(ROOT / "apply.py"),
                                 "--ascend-root", str(self.vllm), "--apply"],
                                capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("do not select vLLM", result.stderr)

    def test_apply_requires_explicit_ascend_root(self):
        result = subprocess.run([sys.executable, str(ROOT / "apply.py"), "--apply"],
                                capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("--ascend-root is required", result.stderr)

    def test_later_edits_are_preserved_by_refusing_restore(self):
        self.run_installer("--apply")
        backup = next(self.ascend.glob("ascend-kv-blocks-routing-backup-*"))
        path = self.ascend / "vllm_ascend/platform.py"
        path.write_text(path.read_text() + "# later edit\n")
        before = hashes(self.ascend)
        self.run_installer("--restore", backup, success=False)
        self.assertEqual(hashes(self.ascend), before)

    def test_fixed_patch_is_ascend_only_and_applies(self):
        before_vllm = hashes(self.vllm)
        patch = ROOT / "ascend-only.patch"
        result = subprocess.run(["git", "apply", "--check", "--whitespace=error", str(patch)],
                                cwd=self.ascend, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        result = subprocess.run(["git", "apply", str(patch)], cwd=self.ascend,
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        for name in FILES:
            self.assertEqual((self.ascend / name).read_bytes(), (ROOT / "modified" / name).read_bytes())
        self.assertEqual(hashes(self.vllm), before_vllm)

    def install_legacy(self):
        result = subprocess.run([sys.executable, str(ROOT / "legacy/v1/apply.py"),
                                 "--ascend-root", str(self.ascend), "--vllm-root", str(self.vllm), "--apply"],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_v1_upgrade_preserves_branch_and_can_restore_both_versions(self):
        platform = self.ascend / "vllm_ascend/platform.py"
        platform.write_text(platform.read_text() + "# user's original branch edit\n")
        before_source = {name: (self.ascend / name).read_bytes() if (self.ascend / name).exists() else None for name in FILES}
        before_vllm = hashes(self.vllm)
        self.install_legacy()
        receipt_path = self.ascend / ".ascend-kv-blocks-routing-install.json"
        legacy_receipt_bytes = receipt_path.read_bytes()
        legacy_receipt = json.loads(legacy_receipt_bytes)
        legacy_source = {name: (self.ascend / name).read_bytes() for name in FILES}
        before_check = hashes(self.ascend)
        check = self.run_installer("--check")
        self.assertIn("--upgrade is available", check.stdout)
        self.assertEqual(hashes(self.ascend), before_check)
        self.run_installer("--upgrade")
        upgraded_receipt = json.loads(receipt_path.read_text())
        self.assertEqual(upgraded_receipt["package"], "ascend-kv-blocks-routing-v2")
        for name in ("vllm_ascend/platform.py", "vllm_ascend/patch/platform/__init__.py"):
            self.assertEqual((self.ascend / name).read_bytes(), legacy_source[name])
        current = hashes(self.ascend)
        self.run_installer("--upgrade")
        self.assertEqual(hashes(self.ascend), current)
        self.run_installer("--restore", upgraded_receipt["backup"])
        self.assertEqual(receipt_path.read_bytes(), legacy_receipt_bytes)
        for name in FILES:
            self.assertEqual((self.ascend / name).read_bytes(), legacy_source[name])
        self.run_installer("--restore", legacy_receipt["backup"])
        self.assertFalse(receipt_path.exists())
        for name, data in before_source.items():
            self.assertEqual((self.ascend / name).read_bytes() if (self.ascend / name).exists() else None, data)
        self.assertEqual(hashes(self.vllm), before_vllm)

    def test_upgrade_preserves_later_source_edits_by_refusing(self):
        self.install_legacy()
        path = self.ascend / "vllm_ascend/core/kv_blocks_routing.py"
        path.write_text(path.read_text() + "# later edit\n")
        before = hashes(self.ascend)
        self.run_installer("--upgrade", success=False)
        self.assertEqual(hashes(self.ascend), before)

    def test_upgrade_requires_existing_installation(self):
        before = hashes(self.ascend)
        self.run_installer("--upgrade", success=False)
        self.assertEqual(hashes(self.ascend), before)


if __name__ == "__main__":
    unittest.main(verbosity=2)
