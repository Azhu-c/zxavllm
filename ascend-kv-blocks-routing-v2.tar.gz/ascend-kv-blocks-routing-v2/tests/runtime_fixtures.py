"""Real pinned upstream client methods, with transport/device substitutes."""
from __future__ import annotations

import ast
import asyncio
from collections import Counter, defaultdict
import copy
import importlib.util
import json
from pathlib import Path
import sys
import time
from types import ModuleType, SimpleNamespace as NS

ROOT = Path(__file__).resolve().parent.parent


def package(name):
    module = ModuleType(name)
    module.__path__ = []
    sys.modules[name] = module
    return module


for name in ("vllm_ascend", "vllm_ascend.core", "vllm_ascend.patch", "vllm_ascend.patch.platform"):
    package(name)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


import os
os.environ["VLLM_ASCEND_KV_BLOCKS_ROUTING"] = "0"
os.environ["VLLM_ASCEND_KV_BLOCKS_LOG"] = "0"
os.environ["VLLM_ASCEND_KV_BLOCKS_STEP_LOG"] = "0"
helper = load("vllm_ascend.core.kv_blocks_routing", ROOT / "modified/vllm_ascend/core/kv_blocks_routing.py")
patch = load("vllm_ascend.patch.platform.patch_kv_blocks_routing",
             ROOT / "modified/vllm_ascend/patch/platform/patch_kv_blocks_routing.py")


class Environment:
    def __setattr__(self, key, value):
        object.__setattr__(self, key, value)
        if key.startswith("VLLM_ASCEND_KV_BLOCKS_"):
            os.environ[key] = str(int(value)) if isinstance(value, bool) else str(value)


class Log:
    def __init__(self):
        self.lines = []

    def info(self, template, *values):
        self.lines.append(template % values)

    def warning(self, template, *values):
        self.lines.append(template % values)


def req(tokens, request_id="req", rank=None, pooling=None):
    return NS(all_token_ids=list(range(tokens)), request_id=request_id,
              data_parallel_rank=rank, pooling_params=pooling, num_computed_tokens=0)


def scheduler(running=(), waiting=(), skipped=(), block_size=128):
    return NS(cache_config=NS(block_size=block_size), block_size=2048,
              running=list(running), waiting=list(waiting), skipped_waiting=list(skipped))


def config(size=3):
    return NS(parallel_config=NS(data_parallel_size=size,
                                data_parallel_external_lb=False,
                                data_parallel_hybrid_lb=False),
              kv_transfer_config=NS(kv_role="kv_consumer"), additional_config={})


async def async_send(value):
    await asyncio.sleep(0)


class BaseIO:
    def __init__(self, vllm_config, executor_class, log_stats,
                 client_addresses=None, client_count=1, client_index=0):
        size = vllm_config.parallel_config.data_parallel_size
        engines = [rank.to_bytes(2, "little") for rank in range(size)]
        self.__dict__.update(
            vllm_config=vllm_config, engine_ranks_managed=list(range(size)), core_engines=engines,
            client_count=client_count, client_index=client_index, current_wave=3,
            engines_running=False, first_req_send_socket=NS(send=async_send),
            lb_engines=[[0, 0, 0.0] for _ in engines], pending={engine: [] for engine in engines},
            schedulers={engine: scheduler() for engine in engines}, sent=[], events=[],
            active_pulls=0, max_active_pulls=0, pulls=0, pull_delay=0,
            fail_engine=None, bad_states=False, resources=NS(engine_dead=False),
        )

    def _ensure_stats_update_task(self):
        pass

    def _ensure_output_queue_task(self):
        pass

    def _send_input(self, request_type, request, chosen_engine):
        if request_type == "ABORT":
            for requests in (self.pending[chosen_engine], self.schedulers[chosen_engine].running,
                             self.schedulers[chosen_engine].waiting, self.schedulers[chosen_engine].skipped_waiting):
                requests[:] = [item for item in requests if item.request_id not in request]
            self.events.append(("ABORT", chosen_engine, request))
            return async_send(None)
        self.pending[chosen_engine].append(copy.deepcopy(request))
        self.sent.append((request.request_id, chosen_engine))
        self.events.append(("ADD", chosen_engine, request.request_id))
        return async_send(None)

    async def _call_utility_async(self, method, *, engine):
        assert method == "get_ascend_kv_blocks_routing_state"
        self.active_pulls += 1
        self.max_active_pulls = max(self.max_active_pulls, self.active_pulls)
        try:
            await asyncio.sleep(self.pull_delay)
            self.pulls += 1
            if engine == self.fail_engine:
                raise RuntimeError("rank failed")
            local = self.schedulers[engine]
            local.waiting.extend(self.pending[engine])
            self.pending[engine].clear()
            engine_module = sys.modules["vllm.v1.engine.core"]
            core = engine_module.EngineCore()
            core.scheduler, core.dp_rank = local, int.from_bytes(engine, "little")
            state = core.get_ascend_kv_blocks_routing_state()
            if self.bad_states:
                state["block_size"] = -1
            self.events.append(("STATE", engine, copy.deepcopy(state)))
            return state
        finally:
            self.active_pulls -= 1


def make_modules(log):
    for name in ("vllm", "vllm.v1", "vllm.v1.engine", "vllm.v1.pool"):
        package(name)
    logger_module = ModuleType("vllm.logger")
    logger_module.logger = log
    sys.modules[logger_module.__name__] = logger_module
    affinity = ModuleType("vllm.v1.pool.late_interaction")
    affinity.get_late_interaction_engine_index = lambda params, count: params
    sys.modules[affinity.__name__] = affinity

    core = ModuleType("vllm.v1.engine.core")
    core.__file__ = str(ROOT / "tests/fixtures/core.txt")
    core.EngineCore = type("EngineCore", (), {})
    tree = ast.parse(Path(core.__file__).read_text())
    method = next(node for cls in tree.body if isinstance(cls, ast.ClassDef) and cls.name == "EngineCoreProc"
                  for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == "_process_engine_step")
    namespace = dict(time=time)
    exec(compile(ast.Module(body=[method], type_ignores=[]), core.__file__, "exec"), namespace)
    core.EngineCoreProc = type("EngineCoreProc", (core.EngineCore,), {"_process_engine_step": namespace[method.name]})
    sys.modules[core.__name__] = core

    client = ModuleType("vllm.v1.engine.core_client")
    client.__file__ = str(ROOT / "tests/fixtures/core_client.txt")
    tree = ast.parse(Path(client.__file__).read_text())
    classes = {node.name: node for node in tree.body if isinstance(node, ast.ClassDef)}
    wanted = {
        "EngineCoreClient": {"make_async_mp_client"},
        "AsyncMPClient": {"_call_utility_async"},
        "DPAsyncMPClient": {"add_request_async"},
        "DPLBAsyncMPClient": {"__init__", "get_core_engine_for_request", "process_engine_outputs",
                              "abort_requests_async", "_abort_requests", "prepare_elastic_ep"},
    }
    nodes = [ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0)]
    for name, names in wanted.items():
        base = "DPAsyncMPClient" if name == "DPLBAsyncMPClient" else "BaseIO"
        body = [node for node in classes[name].body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                and node.name in names]
        nodes.append(ast.ClassDef(name=name, bases=[ast.Name(id=base, ctx=ast.Load())],
                                  keywords=[], body=body, decorator_list=[]))
    client.__dict__.update(
        BaseIO=BaseIO, asyncio=asyncio, sys=sys, Counter=Counter, defaultdict=defaultdict,
        EngineIdentity=bytes, EngineCoreRequestType=NS(ADD="ADD", ABORT="ABORT"),
        get_late_interaction_engine_index=affinity.get_late_interaction_engine_index,
        instrument=lambda **kwargs: lambda function: function,
        msgspec=NS(msgpack=NS(encode=lambda value: json.dumps(
            [value[0], int.from_bytes(value[1], "little")]).encode())),
    )
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])),
                 client.__file__, "exec"), client.__dict__)
    sys.modules[client.__name__] = client
    return core, client


def make_client(size=3, enabled=True, observe=False, step_log=False):
    env = Environment()
    env.VLLM_ASCEND_KV_BLOCKS_ROUTING = enabled
    env.VLLM_ASCEND_KV_BLOCKS_LOG = enabled or observe
    env.VLLM_ASCEND_KV_BLOCKS_STEP_LOG = step_log
    env.VLLM_ASCEND_KV_BLOCKS_TIMEOUT_S = 1.0
    log = Log()
    core, module = make_modules(log)
    patch.install_for_config(config(size))
    client = module.EngineCoreClient.make_async_mp_client(config(size), None, False)
    return client, env, log
