# vllm-ascend KV blocks 分发与独立日志（v2）

**v2 修复：日志开关独立于分发策略。** `ROUTING=0, LOG=1, STEP_LOG=1` 现在会保留原生分发，并打印原生选路结果与逐 step blocks。已安装 v1 的环境需要先执行下面的 `--upgrade`；v1 仅改变参数无法开启这种模式。

这是修正后的实现，所有需要安装的源文件都位于 **`vllm_ascend/`**。前一份 `kv-blocks-routing-58d3918` 包直接修改 vLLM 源码，不符合本次要求；请先撤回旧包，再使用本包。

本包沿用 Ascend 的扩展方式，在启动时挂接 vLLM 的 DP 客户端和 engine utility 接口，**不修改磁盘上的任何 vLLM 源文件**。仍使用此前确认的 vLLM `58d3918e3ea0a544ffedadad2ba84559e9c51d8f` 作为配套接口版本，安装时只读检查它。

## 修改位置

| Ascend 源文件 | 改动 |
| --- | --- |
| `vllm_ascend/platform.py` | 在 `NPUPlatform.check_and_update_config` 插入客户端安装入口 |
| `vllm_ascend/patch/platform/__init__.py` | 在现有全局补丁入口加载 engine 扩展，覆盖 engine 子进程 |
| `vllm_ascend/core/kv_blocks_routing.py` | 新增 blocks 计算、状态校验、选 rank 和环境开关 |
| `vllm_ascend/patch/platform/patch_kv_blocks_routing.py` | 新增 Ascend DP 客户端扩展、状态 RPC、日志和注册逻辑 |

`ascend-only.patch` 以你此前的 `Azhu-c/zxavllm` 提交 `ac22f968735a9f3af60f5833e4f63c7cc1a9e3d2` 为参考生成。[对应 Ascend 平台入口](https://github.com/Azhu-c/zxavllm/blob/ac22f968735a9f3af60f5833e4f63c7cc1a9e3d2/vllm_ascend/platform.py) · [对应全局补丁入口](https://github.com/Azhu-c/zxavllm/blob/ac22f968735a9f3af60f5833e4f63c7cc1a9e3d2/vllm_ascend/patch/platform/__init__.py)

推荐使用 `apply.py`：它在你当前 Ascend 分支的前两个文件中插入标记清楚的小段入口，保留其余内容，不用参考分支的完整文件覆盖你的文件。安装程序会备份这次实际修改的文件，并在选定的 Ascend 根目录保存安装记录。没有编译算子，不需要重新构建 NPU 算子。

## 分发规则

按 DyntraLB 使用的单位计算：

```python
request_blocks = (len(request.all_token_ids) + block_size - 1) // block_size
block_size = scheduler.cache_config.block_size
rank_load = sum(running_blocks) + sum(waiting_blocks)
```

`waiting_blocks` 包括 `waiting` 与 `skipped_waiting`，不截断请求数，包含等待远程 KV、语法和被抢占等仍属于该 rank 的请求。使用当前 token 数，不预测未来输出；这是逻辑负载估计，不是物理 KV pool 使用率。

每个请求先取得分发锁，再向全部 D rank 拉取新状态，等待全部返回并校验后，选择 blocks 总量最小者；同分时轮转。请求发送后，下一个请求重新拉取。ADD 与下一次 RPC 使用同一条到目标 rank 的有序通道，engine FIFO 会先处理已有 ADD 再返回新状态，从而计入之前分发的请求，或反映它已经完成。

读取发生在各 rank 的 engine 主循环安全点，不冻结模型执行，也不保证所有 rank 的状态处于同一个原子时刻或同一个 step。未使用周期性缓存快照代替逐请求同步；RPC 中没有新增 torch collective。KV-aware 模式下，超时、缺失或异常状态不会回退到旧快照发送。

显式指定 `data_parallel_rank` 或上游特殊亲和性时保留指定。等待分发锁或 RPC 时发生 abort 会阻止发送；发送、wave 唤醒、完成回收和 abort 路由复用上游处理。

## 原生分发的观测模式

当 `VLLM_ASCEND_KV_BLOCKS_ROUTING=0`、`VLLM_ASCEND_KV_BLOCKS_LOG=1` 时，也会拉取相同格式的 blocks 快照，但**rank 由原生 `get_core_engine_for_request` 选择一次**，不以 KV 最小值覆盖原生结果，不额外修改其轮转起点、队列估计或请求跟踪。汇总行增加 `policy=native`；KV-aware 模式为 `policy=kv_aware`。

因此原生模式下 `selected` 不一定是 blocks 最少的 rank，这是原生策略与 KV 策略的区别，不应作为选路错误。替身测试中，blocks 为 `[100, 1]`，原生队列评分仍可选择 DP0，日志为：

```text
[kv_blocks_route] seq=1 totals=[100, 1] selected=DP0 pinned=False policy=native
```

为打印完整的发送前快照，原生观测仍会逐请求拉取状态、串行处理观测事务，并产生日志/RPC 开销及可能的时序变化。它用于观测原生分发算法，不能当成无观测开销的原生性能基线。测无观测基线时将三个开关全部设为 0；仅需要逐步状态时，可以 `ROUTING=0, LOG=0, STEP_LOG=1`，此时不挂接客户端，不做逐请求状态 RPC。

原生观测的快照读取失败时，打印 `[kv_blocks_observer]` 提示并继续原生分发，汇总行写 `totals=unavailable`，不编造 blocks；KV-aware 模式仍严格要求完整快照。

## 已安装 v1：直接升级

先停止本次 Decode，解压新版到独立目录并使用 Decode 的 Python 环境：

```bash
tar -xzf ascend-kv-blocks-routing-v2.tar.gz
cd ascend-kv-blocks-routing-v2
python3 apply.py --ascend-root /workspace/dyntralb --upgrade
```

`/workspace/dyntralb` 是你前次检查实际加载的目录；若环境已改变，请先用 `--locate` 重新确认。升级会核对 v1 文件，备份原内容及原安装记录，保留现有两个入口及周围分支代码，仅更新两个 Ascend 模块。vLLM 文件仍只读。升级成功显示 `UPGRADED V1 TO V2 IN VLLM-ASCEND ONLY`。

保存新打印的 `Restore v1:` 命令，可精确回到升级前的 v1；之后原先 v1 的备份记录也仍然有效。存在安装后修改时，升级拒绝覆盖。没有 v1 安装记录的新环境请用 `--apply`。

## 先撤回旧包

如果安装过前一份直接修改 vLLM 的包，先用其安装时打印的 `Restore:` 命令撤回。旧包成功恢复会显示：

```text
RESTORED: restart Decode to load the original files
```

本包会只读核对 vLLM 原文件；旧补丁仍在、版本不符或有其他源代码改动时会拒绝安装，不会擅自覆盖或恢复 vLLM。

## 明确选择 Ascend 安装目录

把本包上传到服务器实验目录。停掉需要修改的 Decode 服务，在它实际使用的 Python 环境中执行：

```bash
tar -xzf ascend-kv-blocks-routing-v2.tar.gz
cd ascend-kv-blocks-routing-v2
python3 apply.py --locate
```

输出会分别标明 `vllm-ascend root` 和 `vLLM root (READ ONLY)`。确认前者是本次要修改的 Ascend 目录，然后显式指定它：

```bash
# /你的/vllm-ascend目录 必须替换成实际目录；该目录内应有 vllm_ascend/platform.py。
python3 apply.py --ascend-root /你的/vllm-ascend目录 --check
python3 apply.py --ascend-root /你的/vllm-ascend目录 --apply
```

安装程序不会猜测写入目录。未指定 `--ascend-root`，或把 vLLM 仓库作为目标，都会退出。`--check` 不修改文件；`--apply` 会打印四个 Ascend 源文件路径、备份位置和恢复命令。

如果当前 Python 环境加载的是另一个 Ascend 安装，修改指定目录不等于修改正在使用的包。应先确认 `--locate` 输出与 Decode 启动脚本的环境、代码路径一致。源码以 editable 方式安装时，重启后可加载这些 Python 修改；使用其他打包方式时需按原有流程让运行环境加载修改后的 Ascend 包。

`tests/fixtures/*.txt` 是供本地替身测试读取的上游参考文本，不会安装，也不会写入 vLLM 目录。

## 启动和开关

本包使用 **`VLLM_ASCEND_` 前缀**。只在 Decode 启动环境设置：

**不开 KV-aware，只看原生分发与逐步状态（本次需求）：**

```bash
export VLLM_ASCEND_KV_BLOCKS_ROUTING=0
export VLLM_ASCEND_KV_BLOCKS_LOG=1
export VLLM_ASCEND_KV_BLOCKS_STEP_LOG=1
export VLLM_LOGGING_LEVEL=INFO
```

**开启 KV-aware：**

```bash
export VLLM_ASCEND_KV_BLOCKS_ROUTING=1
export VLLM_ASCEND_KV_BLOCKS_LOG=1
export VLLM_ASCEND_KV_BLOCKS_STEP_LOG=1
export VLLM_LOGGING_LEVEL=INFO
# 可选；默认 30 秒
export VLLM_ASCEND_KV_BLOCKS_TIMEOUT_S=30
```

保持原来的 P/D、DP/TP/EP、模型、量化、MTP 和异步调度参数。KV-aware 或原生分发观测使用 **`--api-server-count 1`**，内部 DP、`kv_role=kv_consumer`。单独比较分发策略时关闭 `scheduler_config.dyntra_lb_config.enabled`；KV-aware 与 DyntraLB 不能同时开启。v2 的原生日志模式允许配置中保留 DyntraLB，但这代表观测原生前端选路与 DyntraLB 内部调度的组合，不能称为纯原生对照。不要把整个 `--additional-config` 替换掉。

单 API 的限制沿用上一实现，用来保证分发/观测锁覆盖全部新请求；不改变 D rank 数量。逐请求分发/观测不支持多个 API server、external/hybrid LB、弹性 DP 改大小或 Rust frontend。Prefill 和 proxy 不启用这些开关。

| 环境变量 | 默认值 | 含义 |
| --- | --- | --- |
| `VLLM_ASCEND_KV_BLOCKS_ROUTING` | `0` | 1 使用 KV-aware；0 沿用原生选路，日志仍可独立开启 |
| `VLLM_ASCEND_KV_BLOCKS_LOG` | KV-aware 时 `1`，原生时 `0` | 显式设 1 可在两种策略下打印实际目标和全局 blocks 快照 |
| `VLLM_ASCEND_KV_BLOCKS_STEP_LOG` | `0` | 独立打印各 rank 的逐 step 本地数组，不要求 ROUTING=1 |
| `VLLM_ASCEND_KV_BLOCKS_TIMEOUT_S` | `30` | 每次等待全部 rank 状态的超时秒数 |

示例日志仅展示格式：

```text
[kv_blocks_route] seq=1 totals=[10, 1, 3] selected=DP1 pinned=False policy=kv_aware
[kv_blocks_route] seq=1 DP0 | Run(1): [10] | Wait(0): [] | total=10 block_size=128
[kv_blocks_route] seq=1 DP1 | Run(1): [1] | Wait(0): [] | total=1 block_size=128
[kv_blocks_route] seq=1 DP2 | Run(1): [3] | Wait(0): [] | total=3 block_size=128
[kv_blocks_step] wave=3 step=7 DP1 | Run(2): [1, 9] | Wait(1): [2] | total=12 block_size=128
```

逐步日志按 `wave/step/DP` 查看，各进程输出可能交错；它不新增逐步全局同步。KV-aware 模式关闭两个日志开关后，策略仍然每个请求拉取全部状态。无观测原生基线将 `ROUTING=0, LOG=0, STEP_LOG=0` 并重启，保持单 API 和其他参数一致。

## 验证与回退

如果服务能处理请求但没有 blocks 数组日志，可将 `check_kv_runtime.py` 复制到服务端，在同一容器中执行 `python3 check_kv_runtime.py --pid 当前Decode的APIServer进程号`。它只读检查该进程启动时记录的开关、日志配置、Python 路径及同环境解析出的 Ascend 源码目录和四个入口文件；不重新安装补丁，不停止服务，也不实例化引擎。输出的代码目录是新解释器的磁盘路径解析结果，不是对当前 API 对象的运行时检查。

本地通过 **41 项检查**，包括：使用固定版本上游真实客户端方法、Ascend 扩展和 FIFO 传输替身的连续分发；100 个并发到达请求与 8 个模拟 rank；取消、完成、显式 rank、超时、入口注册、静态工厂方法绑定、重复注册和逐步日志；原生观测与无观测在受控队列下选路和记账一致；只开 STEP_LOG 不挂接客户端；原生观测失败仍继续原路由；安装/升级/回退时 vLLM 文件哈希保持不变；v1→v2→v1→原始分支精确恢复。

复现命令：

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p 'test_*.py' -v
```

本机未运行真实 vLLM 进程、PyTorch、NPU、ZMQ 多进程、Mooncake 或真实模型生成/MTP/异步调度和性能实验；模拟检查不能替代服务器功能验证。逐请求同步的额外时延需要实测。

恢复本次 Ascend 修改，先停掉该 Decode，再使用安装时打印的命令：

```bash
python3 apply.py --ascend-root /你的/vllm-ascend目录 \
  --restore /安装时打印的/ascend-kv-blocks-routing-backup-时间戳
```

成功显示 `RESTORED: Ascend source restored`。新安装的恢复会还原两个入口、删除本包新增的两个模块；从 v1 升级的恢复会还原 v1 模块及其安装记录。备份保留，vLLM 文件始终不写入。如果这些 Ascend 文件在安装后又有修改，程序会拒绝覆盖并保留它们。恢复后重启服务。
