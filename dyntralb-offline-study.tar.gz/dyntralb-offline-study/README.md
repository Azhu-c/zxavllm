# DyntraLB 状态数据采集：服务器操作说明

## 先回答：需要修改什么？

**需要给服务器上实际运行的 vLLM Ascend Python 调度器加一个采集钩子。** 修改对象是：

```text
<vLLM Ascend 代码目录>/vllm_ascend/core/dyntra_lb_scheduler.py
```

你不需要手动写 Python 代码：压缩包里的 `capture.patch` 会在该文件中加入几行代码，并在启动服务时加载 `dyntra_capture.py`。不改模型权重，不改变现有调度决策，也不会移除 all-gather。建议在实验用的源码副本操作，按下面步骤先检查版本并备份。

之前的实验资料中，vLLM Ascend 源码目录写作 `/workspace/dyntralb`，启动脚本目录写作 `/workspace/ycp/vllm_serve_run`。**这只是之前脚本使用的路径，我现在无法查看你的服务器；必须以步骤 2 查出的实际路径为准。** 如果服务器上不是这两个路径，请替换为实际路径。

## 压缩包有什么？

解压后目录名称为 `dyntralb-offline-study`：

| 文件 | 作用 |
|---|---|
| `README.md` | 本操作说明 |
| `capture.patch` | 在 DyntraLB 调度器上加入采集钩子 |
| `dyntra_capture.py` | 真正记录状态、计划和实际动作的代码 |
| `collect.sh` | 设置采集环境，再启动你原来的 Decode 脚本 |
| `analyze.py` | 检查采集数据，并做一个简单的离线预测 |
| `install_capture.py` | 用于生成带钩子的代码副本；按照下面 patch 流程操作时不需要运行 |

## 第 1 步：上传和解压

把 `dyntralb-offline-study.tar.gz` 上传到服务器的实验目录。以 `/workspace/ycp/vllm_serve_run` 为例：

```bash
cd /workspace/ycp/vllm_serve_run
tar -xzf dyntralb-offline-study.tar.gz
cd dyntralb-offline-study
export CAPTURE_HOME="$PWD"
```

如果文件上传在其他位置，先将其放到你希望存放实验工具的位置。为避免覆盖已有实验文件，请先检查当前目录下是否已经有 `dyntralb-offline-study`；如果有，请解压到新的空目录。`CAPTURE_HOME` 指的是**解压得到的工具目录**，不是 vLLM Ascend 源码目录。

## 第 2 步：确认实际 Python 代码在哪里

在**平时启动 Decode 服务时使用的 Python 环境**里，执行：

```bash
python3 -c 'import vllm_ascend.core.dyntra_lb_scheduler as m; print(m.__file__)'
```

它会打印一个完整的 `dyntra_lb_scheduler.py` 路径。比如，如果结果恰好是：

```text
/workspace/dyntralb/vllm_ascend/core/dyntra_lb_scheduler.py
```

那么下面将 `REPO` 设置为 `/workspace/dyntralb`。如果打印的是其他目录，就把下面的路径替换为**打印路径中 `vllm_ascend` 前面的目录**。如果导入失败，先检查是否激活了正确环境；不要继续打补丁。

```bash
export REPO=/workspace/dyntralb
sha256sum "$REPO/vllm_ascend/core/dyntra_lb_scheduler.py"
```

本工具针对的源码哈希是：

```text
98d6d5e33dd98477417d1cd293195cb4a7a6a50ea034dd5b3a4f6b420e60cf28
```

**只有实际文件哈希一致，才继续下一步。** 如果不同，请把上面打印的文件路径和哈希发给我；我需要按你的实际版本适配，不能保证此补丁可用。如果你的启动脚本会修改 Python 环境或 `PYTHONPATH`，也需要确认启动后的服务加载的是这个文件。

## 第 3 步：检查并应用采集补丁

确认现在没有使用该源码的实验服务，再执行：

```bash
cd "$REPO"
patch --dry-run -p1 < "$CAPTURE_HOME/capture.patch"
```

如果 dry-run 报错，停止操作，把报错发给我。如果成功，先检查备份不存在，然后备份和应用：

```bash
if [ -e vllm_ascend/core/dyntra_lb_scheduler.py.before_capture ]; then
  echo '备份已经存在，请先检查，不会覆盖。'
else
  cp vllm_ascend/core/dyntra_lb_scheduler.py vllm_ascend/core/dyntra_lb_scheduler.py.before_capture
  patch -p1 < "$CAPTURE_HOME/capture.patch"
fi
```

补丁仅在启动时设置 `DYNTRA_DATA_DIR` 才启用采集。`collect.sh` 会自动设置它。采集期间保留现有 DyntraLB all-gather，方便观察原策略的状态和决策。

## 第 4 步：启动服务和发送请求

1. 像之前一样启动 Prefill 和代理。
2. 找到你**原来用于启动 DyntraLB Decode** 的 bash 文件；不要使用之前 `bubble` 实验中指定 `scheduler_probe.ProbeAsyncScheduler` 的 Decode 文件，那是普通调度器探针。
3. 在 Decode 终端激活原来的 Python/Ascend 环境。每个终端都需要重新设置 `CAPTURE_HOME`；下面是示例，路径不同请替换：

```bash
export CAPTURE_HOME=/workspace/ycp/vllm_serve_run/dyntralb-offline-study
bash "$CAPTURE_HOME/collect.sh" r1 \
  /workspace/ycp/vllm_serve_run/dyntralb-offline-study/results \
  /实际路径/你的DyntraLB_Decode启动脚本.sh
```

**最后一行必须改成你的真实 Decode 启动脚本路径。** `r1` 是这次运行编号；结果目录必须是绝对路径，并且同名运行目录不能已经存在。服务启动后，用之前的客户端正常发送请求。测试完成后按原方法停止 Decode。

如果 Decode 启动脚本会重新设置或清除 `PYTHONPATH`、`DYNTRA_DATA_DIR`，采集模块可能无法加载；请检查脚本和启动日志。我们无法在本地确定你的实际启动脚本行为。

## 第 5 步：检查数据并运行离线分析

Decode 停止后查看：

```bash
ls -lh "$CAPTURE_HOME/results/r1"
python3 "$CAPTURE_HOME/analyze.py" "$CAPTURE_HOME/results/r1"
```

正常时，每个进程/rank 会有一个 `rank-<rank>-pid-<pid>.jsonl` 文件，每一行是一次调度的状态和动作。离线脚本按时间划分训练与测试数据，比较对“下一次调度前运行请求的 block 数”的预测；如果数据太少，会提示样本不足。

请把 `results/r1` 中的 JSONL 文件和分析输出发给我。数据不包含请求 ID 或请求文本，但包含调度负载、时间戳和进程信息，请按你的实验数据管理要求处理。

如果目录为空：先确认 Decode 服务确实启用 DyntraLB、加载的是第 2 步打补丁的 Python 文件，并查看服务日志中是否有 `Dyntra capture` 报错。

## 第 6 步：恢复原代码

在 `$REPO` 下，先检查可否反向应用：

```bash
cd "$REPO"
patch --dry-run -R -p1 < "$CAPTURE_HOME/capture.patch"
```

如果检查成功且你要恢复，运行：

```bash
patch -R -p1 < "$CAPTURE_HOME/capture.patch"
```

这会移除采集钩子；备份文件不会自动删除。如果源码在实验期间还有别的改动，先检查 dry-run 结果再操作，不要强行覆盖。

## 如何理解数据

- `state_pre` 是 `schedule()` 之前的本地状态；block 数为 DyntraLB 估计值，不是实际 KV 显存用量。等待候选快照可能陈旧。
- `plan_pre` 是进入调度前已有计划；`action_observed` 是实际返回的调度结果。计划与执行不一定完全相同。
- `scheduler_cpu_wall_ms` 只记录 CPU 调度函数耗时，**不是**模型设备执行耗时；`reward` 和 `model_execution_ms` 留空。
- 这套工具只检验状态和动作是否能预测下一步负载，不足以直接训练或评估 bandit。现有动作由原策略选择；对其他未采取动作没有反馈。
- 每步写文件可能增加开销；当前工具已通过模拟验证和补丁 dry-run，尚未在你的真实 NPU 服务器测试。
