"""Create an instrumented COPY of the exact archived scheduler; never edit installed code."""
import argparse
import hashlib
from pathlib import Path

ANCHOR = '\nclass AsyncDyntraLBScheduler(DyntraLBScheduler, AsyncScheduler):\n'
INSERT = '''\n# Opt-in observational instrumentation; no change when DYNTRA_DATA_DIR is unset.\nimport os as _capture_os\nif _capture_os.environ.get("DYNTRA_DATA_DIR"):\n    from dyntra_capture import install as _install_capture\n    _install_capture(DyntraLBScheduler, get_dyntra_lb_request_block_num)\n'''

def main():
    p = argparse.ArgumentParser()
    p.add_argument('source', type=Path, help='original dyntra_lb_scheduler.py')
    p.add_argument('output', type=Path, help='new instrumented copy')
    a = p.parse_args()
    data = a.source.read_text(encoding='utf-8')
    if data.count(ANCHOR) != 1 or 'class DyntraLBPolicyMixin' not in data:
        raise SystemExit('Unsupported scheduler version: anchor does not match archived TTFT v2; no output written')
    a.output.parent.mkdir(parents=True, exist_ok=True)
    with a.output.open('x', encoding='utf-8') as out:
        out.write(data.replace(ANCHOR, INSERT + ANCHOR, 1))
    print('source sha256:', hashlib.sha256(data.encode()).hexdigest())
    print('created:', a.output)

if __name__ == '__main__': main()
