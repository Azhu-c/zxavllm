#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
if [[ $# -lt 3 ]]; then
  echo '用法: bash collect.sh RUN_ID OUTPUT_DIR 原有decode启动脚本 [启动脚本参数...]' >&2
  exit 2
fi
RUN_ID="$1"; OUTPUT_DIR="$2"; START_SCRIPT="$3"; shift 3
[[ "$RUN_ID" =~ ^[A-Za-z0-9_-]+$ ]] || { echo 'RUN_ID 仅允许字母、数字、下划线和横线' >&2; exit 2; }
[[ "$OUTPUT_DIR" = /* ]] || { echo 'OUTPUT_DIR 必须是绝对路径' >&2; exit 2; }
[[ -f "$START_SCRIPT" ]] || { echo '找不到 decode 启动脚本' >&2; exit 2; }
[[ -d "$OUTPUT_DIR" ]] || mkdir -p "$OUTPUT_DIR"
RUN_DIR="$OUTPUT_DIR/$RUN_ID"
mkdir "$RUN_DIR" || { echo '运行目录已存在，请换一个 RUN_ID' >&2; exit 1; }
export DYNTRA_DATA_DIR="$RUN_DIR" DYNTRA_RUN_ID="$RUN_ID"
export PYTHONPATH="$HERE${PYTHONPATH:+:$PYTHONPATH}"
echo "采集目录: $RUN_DIR"
echo '请确保安装的 DyntraLB scheduler 已包含采集钩子；服务启动后按原方式发送请求。'
exec bash "$START_SCRIPT" "$@"
