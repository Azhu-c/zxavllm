"""Install only in an explicitly selected vllm-ascend tree; read vLLM only."""
from __future__ import annotations

import argparse
import ast
from datetime import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile

from edit_sources import FILES, INIT, NEW, PLATFORM, update_init, update_platform

HERE = Path(__file__).resolve().parent
MANIFEST = json.loads((HERE / "manifest.json").read_text())
RECEIPT = ".ascend-kv-blocks-routing-install.json"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def locate(package):
    spec = importlib.util.find_spec(package)
    return Path(spec.origin).resolve().parent.parent if spec is not None and spec.origin else None


def replace_files(root, contents):
    # Every source target is constrained to the Ascend package. The only
    # other target is this installer's own receipt in the selected root.
    for name in contents:
        if name not in (*FILES, RECEIPT):
            raise RuntimeError(f"Refusing an unexpected write target: {name}")
        try:
            (root / name).resolve().relative_to(root)
        except ValueError:
            raise RuntimeError(f"Target resolves outside the selected Ascend root: {name}")
    originals = {name: (root / name).read_bytes() if (root / name).exists() else None for name in contents}
    staged, replaced = {}, []
    try:
        for name, data in contents.items():
            if data is None:
                continue
            target = root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as handle:
                handle.write(data)
                staged[name] = Path(handle.name)
            staged[name].chmod(target.stat().st_mode & 0o777 if target.exists() else 0o644)
        for name, data in contents.items():
            if data is None:
                (root / name).unlink()
            else:
                os.replace(staged[name], root / name)
            replaced.append(name)
    except BaseException:
        for name in reversed(replaced):
            if originals[name] is None:
                (root / name).unlink(missing_ok=True)
            else:
                (root / name).write_bytes(originals[name])
        raise
    finally:
        for path in staged.values():
            path.unlink(missing_ok=True)


def verify_bundle():
    if set(MANIFEST["files"]) != set(FILES):
        raise RuntimeError("Invalid bundle file list")
    for name, expected in MANIFEST["files"].items():
        if digest(HERE / "modified" / name) != expected:
            raise RuntimeError(f"Bundle checksum mismatch: {name}")
        ast.parse((HERE / "modified" / name).read_text())


def verify_vllm(root):
    if root is None:
        raise RuntimeError("vLLM was not found in this Python environment")
    print(f"vLLM reference (READ ONLY): {root}")
    for name, expected in MANIFEST["vllm_read_only_sha256"].items():
        if digest(root / name) != expected:
            raise RuntimeError(
                f"vLLM source mismatch: {name}. Restore the previous vLLM-source patch first; "
                "this installer will not write or restore vLLM files."
            )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ascend-root", type=Path, help="explicit directory containing vllm_ascend/")
    parser.add_argument("--vllm-root", type=Path, help="optional READ-ONLY vLLM reference; normally auto-detected")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--locate", action="store_true", help="only print package locations")
    mode.add_argument("--check", action="store_true", help="read-only check (default)")
    mode.add_argument("--apply", action="store_true")
    mode.add_argument("--restore", type=Path, metavar="BACKUP")
    args = parser.parse_args()
    if args.locate:
        print(f"vllm-ascend root: {locate('vllm_ascend')}")
        print(f"vLLM root (READ ONLY): {locate('vllm')}")
        return
    if args.ascend_root is None:
        parser.error("--ascend-root is required; use --locate to inspect locations first")
    root = args.ascend_root.resolve()
    if not (root / PLATFORM).is_file() or not (root / INIT).is_file():
        parser.error("Select the vllm-ascend tree containing vllm_ascend/platform.py; do not select vLLM")
    print(f"vllm-ascend target (SOURCE WRITES HERE ONLY): {root}")
    verify_bundle()
    receipt_path = root / RECEIPT

    if args.restore is not None:
        backup = args.restore.resolve()
        receipt = json.loads(receipt_path.read_text())
        if receipt["package"] != MANIFEST["package"] or receipt["root"] != str(root):
            raise RuntimeError("Installation receipt does not match the selected Ascend root")
        if backup != Path(receipt["backup"]):
            raise RuntimeError("Use the exact backup printed by this installation")
        if json.loads((backup / "receipt.json").read_text()) != receipt:
            raise RuntimeError("Backup receipt mismatch")
        contents = {}
        for name in FILES:
            if digest(root / name) != receipt["after"][name]:
                raise RuntimeError(f"File changed after installation; preserving it: {name}")
            if digest(backup / name) != receipt["before"][name]:
                raise RuntimeError(f"Backup mismatch: {name}")
            contents[name] = (backup / name).read_bytes() if receipt["before"][name] else None
        contents[RECEIPT] = None
        replace_files(root, contents)
        print("RESTORED: Ascend source restored; restart Decode if it was running")
        return

    vllm_root = args.vllm_root.resolve() if args.vllm_root else locate("vllm")
    verify_vllm(vllm_root)
    if receipt_path.exists():
        receipt = json.loads(receipt_path.read_text())
        if receipt["package"] != MANIFEST["package"] or receipt["root"] != str(root):
            raise RuntimeError("Unexpected existing installation receipt")
        if any(digest(root / name) != receipt["after"][name] for name in FILES):
            raise RuntimeError("Installed files have later changes; no files were changed")
        print("ALREADY INSTALLED: Ascend-only extension is present")
        return
    for name in NEW:
        if (root / name).exists():
            raise RuntimeError(f"Preserving an existing file: {name}")
    before = {name: digest(root / name) for name in FILES}
    originals = {name: (root / name).read_bytes() if before[name] else None for name in FILES}
    contents = {
        PLATFORM: update_platform(originals[PLATFORM].decode()).encode(),
        INIT: update_init(originals[INIT].decode()).encode(),
        **{name: (HERE / "modified" / name).read_bytes() for name in NEW},
    }
    for name in FILES:
        print(f"  Ascend source: {root / name}")
    if not args.apply:
        print("CHECK ONLY: compatible Ascend hooks found; no files changed")
        return
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    backup = root / f"ascend-kv-blocks-routing-backup-{stamp}"
    backup.mkdir()
    for name, data in originals.items():
        if data is not None:
            path = backup / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
    receipt = {
        "package": MANIFEST["package"], "root": str(root), "backup": str(backup),
        "before": before, "after": {name: hashlib.sha256(data).hexdigest() for name, data in contents.items()},
    }
    (backup / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    if any(digest(root / name) != before[name] for name in FILES):
        raise RuntimeError("Source changed while preparing backup; no source files were changed")
    verify_vllm(vllm_root)
    contents[RECEIPT] = (json.dumps(receipt, indent=2) + "\n").encode()
    replace_files(root, contents)
    print(f"INSTALLED IN VLLM-ASCEND ONLY: backup={backup}")
    print(f'Restore: python3 "{Path(__file__).resolve()}" --ascend-root "{root}" --restore "{backup}"')


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
