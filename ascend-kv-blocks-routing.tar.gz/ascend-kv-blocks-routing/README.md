# vllm-ascend 内的 KV blocks 感知分发

这是修正后的实现，所有需要安装的源文件都位于 **`vllm_ascend/`**。前一份 `kv-blocks-routing-58d3918` 包直接修改 vLLM 源码，不符合本次要求；请先撤回旧包，再使用本包。

本包沿用 Ascend 的扩展方式，在启动时挂接 vLLM 的 DP 客户端和 engine utility 接口，**不修改磁盘上的任何 vLLM 源文件**。仍使用此前确认的 vLLM `58d3918e3ea0a544ffedadad2ba84559e9c51d8f` 作为配套接口版本，安装时只读检查它。

## 修改位置

| Ascend 源文件 | 改动 |
| --- | --- |
| `vllm_ascend/platform.py` | 在 `NPUPlatform.check_and_update_config` 插入客户端安装入口 |
| `vllm_ascend/patch/platform/__init__.py` | 在现有全局补丁入口加载 engine 扩展，覆盖 engine 子进程 |
| `vllm_ascend/core/kv_blocks_routing.py` | 新增 blocks 计算、状态校验、选 rank 和环境开关 |
| `vllm_ascend/patch/platform/patch_kv_blocks_routing.py` | 新增 Ascend DP 客户端扩展、状态 RPC、日志和注册逻辑 |

`ascend-only.patch` 以你此前的 `Azhu-c/zxavllm` 提交 `ac22f968735a9f3af60f5833e4f63c7cc1a9e3d2` 为参考生成。[对应 Ascend 平台入口](https://github.com/Azhu-c/zxavllm/blob/ac22f968735a9f3af60f5833e4f63c7cc1a9e3d2/vllm_ascend/platform.py) · [对应全局补丁入口](https://github.com/Azhu-c/zxavllm/blob/ac22f968735a9f3af60f5833e4f63c7cc1a9e3d2/vllm_ascend/patch/platform/__init__.py)

推荐使用 `apply.py`：它在你当前 Ascend 分支的前两个文件中插入标记清楚的小段入口，保留其余内容，不用参考分支的完整文件覆盖你的文件。安装程序会备份这次实际修改的文件，并在选定的 Ascend 根目录保存安装记录。没有编译算子，不需要重新构建 NPU 算子。

## 分发规则

按 DyntraLB 使用的单位计算：

```python
request_blocks = (len(request.all_token_ids) + block_size - 1) // block_size
block_size = scheduler.cache_config.block_size
rank_load = sum(running_blocks) + sum(waiting_blocks)
```

`waiting_blocks` 包括 `waiting` 与 `skipped_waiting`，不截断请求数，包含等待远程 KV、语法和被抢占等仍属于该 rank 的请求。使用当前 token 数，不预测未来输出；这是逻辑负载估计，不是物理 KV pool 使用率。

每个请求先取得分发锁，再向全部 D rank 拉取新状态，等待全部返回并校验后，选择 blocks 总量最小者；同分时轮转。请求发送后，下一个请求重新拉取。ADD 与下一次 RPC 使用同一条到目标 rank 的有序通道，engine FIFO 会先处理已有 ADD 再返回新状态，从而计入之前分发的请求，或反映它已经完成。

读取发生在各 rank 的 engine 主循环安全点，不冻结模型执行，也不保证所有 rank 的状态处于同一个原子时刻或同一个 step。未使用周期性缓存快照代替逐请求同步；RPC 中没有新增 torch collective。超时、缺失或异常状态不会回退到旧快照发送。

显式指定 `data_parallel_rank` 或上游特殊亲和性时保留指定。等待分发锁或 RPC 时发生 abort 会阻止发送；发送、wave 唤醒、完成回收和 abort 路由复用上游处理。

## 先撤回旧包

如果安装过前一份直接修改 vLLM 的包，先用其安装时打印的 `Restore:` 命令撤回。旧包成功恢复会显示：

```text
RESTORED: restart Decode to load the original files
```

本包会只读核对 vLLM 原文件；旧补丁仍在、版本不符或有其他源代码改动时会拒绝安装，不会擅自覆盖或恢复 vLLM。

## 明确选择 Ascend 安装目录

把本包上传到服务器实验目录。停掉需要修改的 Decode 服务，在它实际使用的 Python 环境中执行：

```bash
tar -xzf ascend-kv-blocks-routing.tar.gz
cd ascend-kv-blocks-routing
python3 apply.py --locate
```

输出会分别标明 `vllm-ascend root` 和 `vLLM root (READ ONLY)`。确认前者是本次要修改的 Ascend 目录，然后显式指定它：

```bash
# /你的/vllm-ascend目录 必须替换成实际目录；该目录内应有 vllm_ascend/platform.py。
python3 apply.py --ascend-root /你的/vllm-ascend目录 --check
python3 apply.py --ascend-root /你的/vllm-ascend目录 --apply
```

安装程序不会猜测写入目录。未指定 `--ascend-root`，或把 vLLM 仓库作为目标，都会退出。`--check` 不修改文件；`--apply` 会打印四个 Ascend 源文件路径、备份位置和恢复命令。

如果当前 Python 环境加载的是另一个 Ascend 安装，修改指定目录不等于修改正在使用的包。应先确认 `--locate` 输出与 Decode 启动脚本的环境、代码路径一致。源码以 editable 方式安装时，重启后可加载这些 Python 修改；使用其他打包方式时需按原有流程让运行环境加载修改后的 Ascend 包。

`tests/fixtures/*.txt` 是供本地替身测试读取的上游参考文本，不会安装，也不会写入 vLLM 目录。

## 启动和开关

本包使用 **`VLLM_ASCEND_` 前缀**。只在 Decode 启动环境设置：

```bash
export VLLM_ASCEND_KV_BLOCKS_ROUTING=1
export VLLM_ASCEND_KV_BLOCKS_LOG=1
export VLLM_ASCEND_KV_BLOCKS_STEP_LOG=1
# 可选；默认 30 秒
export VLLM_ASCEND_KV_BLOCKS_TIMEOUT_S=30
```

保持原来的 P/D、DP/TP/EP、模型、量化、MTP 和异步调度参数。Decode 使用 **`--api-server-count 1`**，内部 DP、`kv_role=kv_consumer`，并关闭现有配置中的 `scheduler_config.dyntra_lb_config.enabled`。你的 Ascend 仓库可以保留 DyntraLB 代码；单独测试分发策略时关闭其功能即可。不要把整个 `--additional-config` 替换掉。

单 API 的限制沿用上一实现，用来保证分发锁覆盖全部新请求；不改变 D rank 数量。此版本不支持多个 API server、external/hybrid LB、同时启用 DyntraLB、弹性 DP 改大小或 Rust frontend。Prefill 和 proxy 不启用这些开关。

| 环境变量 | 默认值 | 含义 |
| --- | --- | --- |
| `VLLM_ASCEND_KV_BLOCKS_ROUTING` | `0` | 开启新分发策略；关闭时沿用原有逻辑 |
| `VLLM_ASCEND_KV_BLOCKS_LOG` | `1` | 每次分发前打印全局 blocks 数组 |
| `VLLM_ASCEND_KV_BLOCKS_STEP_LOG` | `0` | 各 rank 进入 step 前额外打印本地数组 |
| `VLLM_ASCEND_KV_BLOCKS_TIMEOUT_S` | `30` | 每次等待全部 rank 状态的超时秒数 |

示例日志仅展示格式：

```text
[kv_blocks_route] seq=1 totals=[10, 1, 3] selected=DP1 pinned=False
[kv_blocks_route] seq=1 DP0 | Run(1): [10] | Wait(0): [] | total=10 block_size=128
[kv_blocks_route] seq=1 DP1 | Run(1): [1] | Wait(0): [] | total=1 block_size=128
[kv_blocks_route] seq=1 DP2 | Run(1): [3] | Wait(0): [] | total=3 block_size=128
[kv_blocks_step] wave=3 step=7 DP1 | Run(2): [1, 9] | Wait(1): [2] | total=12 block_size=128
```

逐步日志按 `wave/step/DP` 查看，各进程输出可能交错；它不新增逐步全局同步。功能检查后做性能实验，可以将两个日志开关设为 `0`，策略仍然每个请求拉取全部状态。原生路由对照则设 `VLLM_ASCEND_KV_BLOCKS_ROUTING=0` 并重启，保持单 API 和其他参数一致。

## 验证与回退

本地通过 **31 项检查**，包括：使用固定版本上游真实客户端方法、Ascend 扩展和 FIFO 传输替身的连续分发；100 个并发到达请求与 8 个模拟 rank；取消、完成、显式 rank、超时、入口注册、静态工厂方法绑定、重复注册和逐步日志；安装/回退时 vLLM 全部参考文件的哈希保持不变；Ascend 原有分支内容保留；拒绝装到 vLLM 目录；后续修改保护及精确恢复。

复现命令：

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p 'test_*.py' -v
```

本机未运行真实 vLLM 进程、PyTorch、NPU、ZMQ 多进程、Mooncake 或真实模型生成/MTP/异步调度和性能实验；模拟检查不能替代服务器功能验证。逐请求同步的额外时延需要实测。

恢复本次 Ascend 修改，先停掉该 Decode，再使用安装时打印的命令：

```bash
python3 apply.py --ascend-root /你的/vllm-ascend目录 \
  --restore /安装时打印的/ascend-kv-blocks-routing-backup-时间戳
```

成功显示 `RESTORED: Ascend source restored`。程序恢复两个入口原内容、删除本包新增的两个模块，保留备份；vLLM 文件始终不写入。如果这些 Ascend 文件在安装后又有修改，程序会拒绝覆盖并保留它们。恢复后重启服务。
