"""Small, marked additions to existing Ascend files; preserve branch contents."""
import ast

PLATFORM = "vllm_ascend/platform.py"
INIT = "vllm_ascend/patch/platform/__init__.py"
NEW = (
    "vllm_ascend/core/kv_blocks_routing.py",
    "vllm_ascend/patch/platform/patch_kv_blocks_routing.py",
)
FILES = (PLATFORM, INIT, *NEW)
START = "# BEGIN ASCEND_KV_BLOCKS_ROUTING"
END = "# END ASCEND_KV_BLOCKS_ROUTING"
INIT_BLOCK = (START + "\n"
              "import vllm_ascend.patch.platform.patch_kv_blocks_routing  # noqa: F401\n"
              + END + "\n")


def update_platform(source):
    if START in source or END in source:
        raise RuntimeError("Ascend KV-block config hook already exists or is incomplete")
    tree = ast.parse(source)
    methods = [node for cls in tree.body if isinstance(cls, ast.ClassDef) and cls.name == "NPUPlatform"
               for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == "check_and_update_config"]
    if len(methods) != 1:
        raise RuntimeError("Cannot find a unique NPUPlatform.check_and_update_config")
    method = methods[0]
    if not any(isinstance(node, ast.Name) and node.id == "classmethod" for node in method.decorator_list):
        raise RuntimeError("Unsupported Ascend config hook: expected classmethod")
    if "vllm_config" not in [argument.arg for argument in method.args.args]:
        raise RuntimeError("Unsupported Ascend config hook arguments")
    first = method.body[0]
    has_docstring = isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant) and isinstance(first.value.value, str)
    insert_at = first.end_lineno if has_docstring else first.lineno - 1
    indent = " " * first.col_offset
    block = (indent + START + "\n"
             + indent + "from vllm_ascend.patch.platform.patch_kv_blocks_routing import install_for_config\n"
             + indent + "install_for_config(vllm_config)\n"
             + indent + END + "\n\n")
    lines = source.splitlines(True)
    lines.insert(insert_at, block)
    result = "".join(lines)
    ast.parse(result)
    return result


def update_init(source):
    if START in source or END in source:
        raise RuntimeError("Ascend KV-block engine hook already exists or is incomplete")
    ast.parse(source)
    return source + ("" if source.endswith("\n") else "\n") + "\n" + INIT_BLOCK
