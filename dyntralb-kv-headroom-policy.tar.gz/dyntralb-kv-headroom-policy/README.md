# DyntraLB 交换判据与 Decode KV 余量

这两份增量补丁以已安装 **Ascend-only KV-aware v2** 的 Decode 源码为起点。分发层以该 v2 的两个模块为基准。DyntraLB 的 planner、配置、调度器和引擎入口以 [`Azhu-c/zxavllm@ac22f968`](https://github.com/Azhu-c/zxavllm/tree/ac22f968735a9f3af60f5833e4f63c7cc1a9e3d2) 为基准，配套 [`vllm@58d3918`](https://github.com/vllm-project/vllm/tree/58d3918e3ea0a544ffedadad2ba84559e9c51d8f)。源码改动都落在 `vllm_ascend/`。

## 1. 本地调度用两个门槛

`B_r` 是 rank 的试排 running blocks，`N_r` 是该 rank 的试排运行请求数，`N` 是全局总运行请求数。在每请求每步产出一个 token 的 Decode 近似下：

```text
T = fixed_us + max_r(block_us × B_r + seq_us × N_r)
Q_old = N_old / T_old
Q_new = N_new / (T_new + C_pause / H)
g_tp  = Q_new / Q_old - 1

bubble = max_r(B_r) - mean_r(B_r)
g_bal  = (bubble_old - bubble_new) / bubble_old
```

参考代码里 `fixed_us = 20000`，`block_us = 19.2`。新增的 `seq_us` 用于拟合每步随本地 batch 增长的开销。每个新增的原 running 请求暂停按配置扣除一次暂停及后续恢复成本，并在 `H` 步摊销。这个窗口用于摊销成本。

| 候选操作 | 通过条件 |
| --- | --- |
| 同数量交换，最大 blocks 下降 | 净吞吐收益达到 2% |
| 同数量交换，最大 blocks 持平 | 均衡改善达到 `min_balance_gain`，预测稳态步长不增加，暂停成本摊销后的吞吐下降在预算内 |
| 同数量交换，最大 blocks 上升 | 拒绝 |
| 单独暂停 | 将全局运行数改为 `N-1` 后，净吞吐收益仍达到 2% |

原有的补位、暂停数量预算、最短运行保护和到期恢复仍参与执行。表中的 2% 和均衡门槛用于评价换出原 running 请求的候选，试排阶段刚选入的补位项可以先在内部调整。到期恢复由原调度器处理。

例如两个 rank 当前为 `[300, 30]` blocks，轻载 rank 将 30 换成 75 后变为 `[300, 75]`。最大负载仍是 300，且运行数相同，所以不计暂停成本时 `g_tp=0`，但 bubble 从 135 降到 112.5，`g_bal=16.7%`。若均衡门槛设为 10%，且符合暂停成本与 KV 余量约束，就可以执行。16.7% 衡量的是均衡改善，实际吞吐变化需要压测。

## 2. 完整的 KV 显存限制策略

### 本地观察和分发

每个 Decode rank 在本地检查 KV 池可分配 blocks，并维护一个压力位 `pressure`。出现以下任意情况时置为 1。恢复余量并且当前调度没有观察到 KV 容量不足时清为 0。

- 可分配 blocks 不超过 `max(池容量 × 余量比例, vLLM watermark)`。
- DyntraLB 本地等待请求分配 KV 失败，或试排后复核发现换入请求已放不下。

压力位变化时通知分发端。平稳期间默认每隔约 100 ms 在本地更新一次逻辑 blocks 汇总，只有状态变化才应答。每个 rank 通过已有 utility 通道独立保持一个异步订阅。新请求读 API 侧的缓存，再加上该 API 已发给各 rank、但还未计入报告的 blocks。整个选路过程无需等状态 RPC 返回。KV 池、队列和暂停状态都在所在 rank 读取。

| API 端可见状态 | 分发 |
| --- | --- |
| 有压力位为 0 的 rank | 只在这些 rank 里按逻辑 blocks 选最轻者 |
| 所有 rank 都为 1 | 送到逻辑负载最轻的 rank 排队，记录 `all_tight=True` |
| 订阅尚未就绪或报告读取出错 | 暂用原生选路，直到状态收齐。仍执行本地 KV 准入检查 |
| 显式指定 rank 或原生亲和性 | 保留原归属，由目标 rank 判断何时准入 |

报告可能比引擎状态滞后。压力位为 0 的 rank 也可能放不下一个特别长的输入。最终准入由该 rank 的 KV allocator 决定。基于 pressure 的选路减少的是 API 对所有 rank 的同步等待，实际 TPOT、TTFT 和订阅开销需上机测量。

### 本地准入、暂停和回收

1. **运行中的请求先推进。** 新请求和远端 KV 预取使用 `可分配 blocks − 基础余量 − running 短期增长预算 − 在途 prefill 预留`。物理 KV 已占的部分已从池可分配量扣除。预留量只计算尚需分配的部分。空闲且没有在途 prefill 的 rank 可以接纳一个需要较大比例 KV 池的请求。
2. **暂停只释放运行槽。** 普通 DyntraLB pause 仍持有 KV。planner 的现有 DP all-gather 携带试排物理预算，换出原 running 请求不给预算加回任何块。执行交换前再用本地余量复核，换入项放不下就撤销这轮计划。
3. **优先让已暂停的请求恢复。** 到期请求保留原来优先级。恢复时仍受物理可分配 blocks 和在途 prefill 预留约束，可使用留给新准入的缓冲预算。本地资源检查仍以 vLLM allocator 为准。
4. **池逼满时先等自然释放。** 请求完成或取消后，按 allocator 和 connector 的规则回收。仍有 running 或在途 prefill 时，继续正常执行和回收。若 rank 没有 running、没有在途 prefill、且准入因 KV 分配失败停住，只挑一个没有在途 token 的 DyntraLB 暂停请求，调用 vLLM 的原生重计算抢占，再由 vLLM 判断何时实际释放其 blocks。这条路径会付出重计算成本。
5. **全局都满时，新请求留在 waiting。** 这保证 KV 实际分配受池容量约束。等待队列的长度取决于到达速率与释放速度，持续过载时需要沿用部署侧已有的并发限制。这里看的是 KV 池余量，设备上的其他内存分配有独立的生命周期。

[vLLM 的 KV 分配与余量检查](https://github.com/vllm-project/vllm/blob/58d3918e3ea0a544ffedadad2ba84559e9c51d8f/vllm/v1/core/kv_cache_manager.py#L494-L533) · [原生抢占与重新入队](https://github.com/vllm-project/vllm/blob/58d3918e3ea0a544ffedadad2ba84559e9c51d8f/vllm/v1/core/sched/scheduler.py#L1283-L1324)

## 3. 应用与配置

从 Ascend-only KV-aware v2 起步时，将 `0001` 和 `0002` 放在同一目录。在 Decode 实际加载的 `/workspace/dyntralb` 上先检查。命令中的 `PATCH_DIR` 指向解压后的绝对路径。

```bash
cd /workspace/dyntralb
git apply --check "$PATCH_DIR/0001-kv-aware-headroom.patch" "$PATCH_DIR/0002-dyntralb-balanced-gain.patch"
git apply "$PATCH_DIR/0001-kv-aware-headroom.patch" "$PATCH_DIR/0002-dyntralb-balanced-gain.patch"
```

如果已经打过上一版逐请求检查余量的 `0001` 和 `0002`，仅应用以下升级补丁。

```bash
git apply --check "$PATCH_DIR/upgrade-from-per-request-headroom.patch"
git apply "$PATCH_DIR/upgrade-from-per-request-headroom.patch"
```

如果检查报上下文不匹配，请保留现有文件，按服务器实际加载的源码重新对齐。回退时给同一条 `git apply` 命令加 `-R`，先检查再应用。原 v2 安装器如果校验文件哈希，应先回退这次增量再使用它恢复原版。重启 Decode 后读取新代码。

沿用原路由开关、内部 DP、`kv_consumer` 和 `--api-server-count 1`。将下面两个对象合并到已有 `--additional-config` 的 `scheduler_config` 中。示例用静态模式从 step 0 验证策略，已有实验可继续使用相同的激活模式和 step 范围做对比。

```json
{
  "scheduler_config": {
    "kv_blocks_headroom": {
      "reserve_fraction": 0.05,
      "growth_tokens": 16,
      "report_interval_ms": 100
    },
    "dyntra_lb_config": {
      "enabled": true,
      "mode": "static",
      "start_step": 0,
      "min_throughput_gain": 0.02,
      "min_balance_gain": 0.10,
      "max_balance_throughput_loss": 0.005,
      "step_latency_per_seq_us": 0.0,
      "pause_resume_cost_us": 0.0,
      "gain_horizon_steps": 4
    }
  }
}
```

5% 余量、16 token 增长窗口、100 ms 汇总间隔、10% 均衡门槛和 0.5% 吞吐损失预算都是首轮实验设定。`step_latency_per_seq_us` 和 `pause_resume_cost_us` 的默认值为 0，有当前模型与部署的测量再填。删掉 `kv_blocks_headroom` 后，原 KV-aware v2 逐请求同步分发模式继续可用，DyntraLB 的新余量准入关闭。删掉 `min_balance_gain` 即关闭独立均衡门槛。分发日志开启时，`[kv_blocks_headroom]` 打印各 rank 的 `pressure` 和实际目标。原逐步数组可以继续用 `VLLM_ASCEND_KV_BLOCKS_STEP_LOG=1` 查看。

新装与升级补丁均通过应用和逐文件回退校验。本地通过 46 项 CPU 检查，覆盖连续 100 次分发无需全量快照、压力位翻转、已发请求的负载记账、显式 rank、暂停 KV 保留、试排后余量变化、在途 KV 保护和安全回收分支。未在服务器运行真实 vLLM 多进程、Ascend NPU 或性能测试。
