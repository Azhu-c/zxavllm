# DyntraLB 交换判据与 Decode KV 余量

这两份增量补丁以已安装 **Ascend-only KV-aware v2** 的 Decode 源码为起点。分发层以该 v2 的两个模块为基准。DyntraLB 的 planner、配置、调度器和引擎入口以 [`Azhu-c/zxavllm@ac22f968`](https://github.com/Azhu-c/zxavllm/tree/ac22f968735a9f3af60f5833e4f63c7cc1a9e3d2) 为基准，配套 [`vllm@58d3918`](https://github.com/vllm-project/vllm/tree/58d3918e3ea0a544ffedadad2ba84559e9c51d8f)。源码改动都落在 `vllm_ascend/`。

## 1. 本地调度用两个门槛

`B_r` 是 rank 的试排 running blocks，`N_r` 是该 rank 的试排运行请求数，`N` 是全局总运行请求数。在每请求每步产出一个 token 的 Decode 近似下：

```text
T = fixed_us + max_r(block_us × B_r + seq_us × N_r)
Q_old = N_old / T_old
Q_new = N_new / (T_new + C_pause / H)
g_tp  = Q_new / Q_old - 1

bubble = max_r(B_r) - mean_r(B_r)
g_bal  = (bubble_old - bubble_new) / bubble_old
```

参考代码里 `fixed_us = 20000`，`block_us = 19.2`。新增的 `seq_us` 用于拟合每步随本地 batch 增长的开销。每个新增的原 running 请求暂停按配置扣除一次暂停及后续恢复成本，并在 `H` 步摊销。这个窗口用于摊销成本。

| 候选操作 | 通过条件 |
| --- | --- |
| 同数量交换，最大 blocks 下降 | 净吞吐收益达到 2% |
| 同数量交换，最大 blocks 持平 | 均衡改善达到 `min_balance_gain`，预测稳态步长不增加，暂停成本摊销后的吞吐下降在预算内 |
| 同数量交换，最大 blocks 上升 | 拒绝 |
| 单独暂停 | 将全局运行数改为 `N-1` 后，净吞吐收益仍达到 2% |

原有的补位、暂停数量预算、最短运行保护和到期恢复仍参与执行。表中的 2% 和均衡门槛用于评价换出原 running 请求的候选，试排阶段刚选入的补位项可以先在内部调整。到期恢复由原调度器处理。

例如两个 rank 当前为 `[300, 30]` blocks，轻载 rank 将 30 换成 75 后变为 `[300, 75]`。最大负载仍是 300，且运行数相同，所以不计暂停成本时 `g_tp=0`，但 bubble 从 135 降到 112.5，`g_bal=16.7%`。若均衡门槛设为 10%，且符合暂停成本与 KV 余量约束，就可以执行。16.7% 衡量的是均衡改善，实际吞吐变化需要压测。

## 2. 分发前检查 KV 池

`0001` 在原来的逐请求全 rank 状态读取中取得每个 rank 的 KV 池可分配 blocks。状态通过调度器读取，不需要每次调用设备显存查询。

```text
请求入队后的预计余量
  = KV 池当前可分配 blocks
  - max(KV 池比例余量, vLLM watermark)
  - running 近期增长的预计新增 blocks
  - waiting / skipped_waiting 尚需分配的 blocks
  - 新请求预计新增 blocks
```

- 如果至少一个 rank 余量非负，只在这些 rank 中按原 `running + waiting` 逻辑 blocks 选最轻者。
- 所有 rank 都紧张时，将请求送去预计缺口最小的 rank 排队。日志 `all_tight=True` 可以区分这种情况。显式 rank 和请求亲和性照常保留。
- 已为远端 KV 接收或暂停请求持有的 blocks 已经反映在池状态里。对队列估算只计预计缺的部分。新请求以无前缀命中估算，实际命中和 KV 生命周期由 vLLM 决定。

`0002` 同时约束 DyntraLB 的本地预取和试排准入。预取会先留出近期增长和 in-flight prefill 的预算。planner 使用同一轮原有的 DP all-gather 传余量及候选增量，只准入预算内的候选。**DyntraLB 暂停会继续持有 KV，交换时不能把换出的 running 请求当成释放了对应 blocks。** 空闲 rank 的本地预取和试排可以使用实际池容量，让单个接近池上限的合法请求有机会继续。最后仍由 vLLM allocator 执行分配。

因此高负载时，API 可以收到请求，但某个 Decode rank 可能缺少可分配的 KV blocks，导致远端 KV 接收或运行准入等候。运行中请求扩 KV 失败时还可能触发原生 preemption。KV 池若全局饱和，这版会排队，排队等候取决于释放速度和到达速率。余量只反映 vLLM KV 池，设备上其他分配的 OOM 需要另外观察。[固定版分配检查](https://github.com/vllm-project/vllm/blob/58d3918e3ea0a544ffedadad2ba84559e9c51d8f/vllm/v1/core/kv_cache_manager.py#L494-L533) · [固定版调度器的原生抢占](https://github.com/vllm-project/vllm/blob/58d3918e3ea0a544ffedadad2ba84559e9c51d8f/vllm/v1/core/sched/scheduler.py#L577-L639)

## 3. 应用与配置

将两个补丁放在同一目录。在 Decode 实际加载的 `/workspace/dyntralb` 上先检查。命令中的 `PATCH_DIR` 指向解压后的绝对路径。

```bash
cd /workspace/dyntralb
git apply --check "$PATCH_DIR/0001-kv-aware-headroom.patch" "$PATCH_DIR/0002-dyntralb-balanced-gain.patch"
git apply "$PATCH_DIR/0001-kv-aware-headroom.patch" "$PATCH_DIR/0002-dyntralb-balanced-gain.patch"
```

如果检查报上下文不匹配，请保留现有文件，按服务器实际加载的源码重新对齐。回退时给同一条 `git apply` 命令加 `-R`，先检查再应用。原 v2 安装器如果校验文件哈希，应先回退这次增量再使用它恢复原版。重启 Decode 后读取新代码。

沿用原路由开关、内部 DP、`kv_consumer` 和 `--api-server-count 1`。将下面两个对象合并到已有 `--additional-config` 的 `scheduler_config` 中。示例用静态模式从 step 0 验证策略，已有实验可继续使用相同的激活模式和 step 范围做对比。

```json
{
  "scheduler_config": {
    "kv_blocks_headroom": {
      "reserve_fraction": 0.05,
      "growth_tokens": 16
    },
    "dyntra_lb_config": {
      "enabled": true,
      "mode": "static",
      "start_step": 0,
      "min_throughput_gain": 0.02,
      "min_balance_gain": 0.10,
      "max_balance_throughput_loss": 0.005,
      "step_latency_per_seq_us": 0.0,
      "pause_resume_cost_us": 0.0,
      "gain_horizon_steps": 4
    }
  }
}
```

5% 余量、16 token 展望、10% 均衡门槛和 0.5% 暂停损失预算都是首轮实验设定。`step_latency_per_seq_us` 和 `pause_resume_cost_us` 的默认值为 0，有当前模型与部署的测量再填。删掉 `kv_blocks_headroom` 即关闭余量策略，删掉 `min_balance_gain` 即关闭独立均衡门槛。分发日志开启时，`[kv_blocks_headroom]` 按 rank 打印 `free/reserve/waiting_debt/needed` 和选路结果。

本地通过 44 项 CPU 检查，覆盖原分发路径、两类交换、单暂停、KV 不足、连续请求记账、预取预算及 planner 的 DP 快照字段。新增开关关闭时，1,000 组随机 planner 输入与参考输出一致。已验证补丁应用和回退，尚未检查服务器实际源码或运行 Ascend NPU 压测。
