# SPDX-License-Identifier: Apache-2.0
"""Fresh, serialized Decode DP routing using DyntraLB's logical block unit."""

from __future__ import annotations

from itertools import chain
from typing import Any


def validate_config(config: Any, client_count: int) -> None:
    parallel = config.parallel_config
    if client_count != 1:
        raise ValueError("KV-block routing requires --api-server-count 1")
    if (
        parallel.data_parallel_size <= 1
        or parallel.data_parallel_external_lb
        or parallel.data_parallel_hybrid_lb
    ):
        raise ValueError("KV-block routing requires internal DP over all Decode ranks")
    transfer = config.kv_transfer_config
    if transfer is None or transfer.kv_role != "kv_consumer":
        raise ValueError("Enable KV-block routing only on the P/D Decode kv_consumer")
    additional = config.additional_config or {}
    scheduler = additional.get("scheduler_config", {})
    if scheduler.get("dyntra_lb_config", {}).get("enabled", False):
        raise ValueError("Disable DyntraLB to run the KV-block routing baseline")


def snapshot(scheduler: Any, rank: int) -> dict[str, Any]:
    # Exactly get_dyntra_lb_request_block_num(), including the choice of
    # cache_config.block_size rather than scheduler.block_size for hybrid models.
    block_size = scheduler.cache_config.block_size
    if type(block_size) is not int or block_size <= 0:
        raise RuntimeError(f"Invalid DyntraLB block size: {block_size}")

    def blocks(request: Any) -> int:
        return (len(request.all_token_ids) + block_size - 1) // block_size

    return {
        "version": 1,
        "rank": rank,
        "block_size": block_size,
        "running_blocks": [blocks(request) for request in scheduler.running],
        # Include remote-KV/grammar waits and preempted requests: they still
        # belong to this rank. No max_slots clipping or admissibility filter.
        "waiting_blocks": [
            blocks(request)
            for request in chain(scheduler.waiting, scheduler.skipped_waiting)
        ],
    }


def validate_states(states: list[Any], ranks: list[int]) -> list[int]:
    if not ranks or len(states) != len(ranks) or len(set(ranks)) != len(ranks):
        raise RuntimeError("Incomplete KV-block global snapshot")
    totals: list[int] = []
    block_sizes: set[int] = set()
    for expected_rank, state in zip(ranks, states):
        if (
            not isinstance(state, dict)
            or state.get("version") != 1
            or state.get("rank") != expected_rank
        ):
            raise RuntimeError(f"Invalid KV-block snapshot for rank {expected_rank}")
        block_size = state.get("block_size")
        if type(block_size) is not int or block_size <= 0:
            raise RuntimeError("Invalid KV-block snapshot block size")
        block_sizes.add(block_size)
        total = 0
        for key in ("running_blocks", "waiting_blocks"):
            values = state.get(key)
            if not isinstance(values, list) or any(
                type(value) is not int or value < 0 for value in values
            ):
                raise RuntimeError(f"Invalid KV-block snapshot {key}")
            total += sum(values)
        totals.append(total)
    if len(block_sizes) != 1:
        raise RuntimeError("Decode ranks have different KV-block load units")
    return totals


def choose_rank(totals: list[int], start: int, preferred: int | None) -> int:
    if preferred is not None:
        if type(preferred) is not int or not 0 <= preferred < len(totals):
            raise ValueError(f"Invalid data_parallel_rank: {preferred}")
        return preferred
    # Rotate only to break equal-load ties; never override the minimum load.
    return min(
        ((start + offset) % len(totals) for offset in range(len(totals))),
        key=totals.__getitem__,
    )
