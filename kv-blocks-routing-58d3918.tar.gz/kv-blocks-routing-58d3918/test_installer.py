"""Exercise installation, refusal, patch application and exact restoration."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
MANIFEST = json.loads((HERE / "manifest.json").read_text())


def hashes(root):
    return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in root.rglob("*") if path.is_file()}


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="kv-blocks-install-test-")
        self.root = Path(self.temporary.name) / "vllm-root"
        shutil.copytree(HERE / "base", self.root)

    def tearDown(self):
        self.temporary.cleanup()

    def run_installer(self, *args, success=True):
        result = subprocess.run([sys.executable, str(HERE / "apply.py"),
                                 "--root", str(self.root), *map(str, args)],
                                text=True, capture_output=True)
        self.assertEqual(result.returncode, 0 if success else 1, result.stdout + result.stderr)
        return result

    def test_check_is_read_only(self):
        before = hashes(self.root)
        result = self.run_installer("--check")
        self.assertIn("MATCH", result.stdout)
        self.assertEqual(hashes(self.root), before)

    def test_mismatch_refuses_to_write(self):
        path = self.root / "vllm/v1/engine/core.py"
        path.write_text(path.read_text() + "# custom edit\n")
        before = hashes(self.root)
        self.run_installer("--apply", success=False)
        self.assertEqual(hashes(self.root), before)

    def test_apply_idempotence_and_exact_restore(self):
        before = hashes(self.root)
        self.run_installer("--apply")
        for name, values in MANIFEST["files"].items():
            self.assertEqual(hashlib.sha256((self.root / name).read_bytes()).hexdigest(), values["after"])
        installed = hashes(self.root)
        self.run_installer("--apply")
        self.assertEqual(hashes(self.root), installed)
        backup = next(self.root.glob("kv-blocks-routing-backup-*"))
        self.run_installer("--restore", backup)
        after = {name: value for name, value in hashes(self.root).items()
                 if not name.startswith(backup.name + "/")}
        self.assertEqual(after, before)

    def test_restore_preserves_later_edits_by_refusing(self):
        self.run_installer("--apply")
        backup = next(self.root.glob("kv-blocks-routing-backup-*"))
        path = self.root / "vllm/v1/engine/core.py"
        path.write_text(path.read_text() + "# later edit\n")
        before = hashes(self.root)
        self.run_installer("--restore", backup, success=False)
        self.assertEqual(hashes(self.root), before)

    def test_git_patch_applies_and_reverses_exactly(self):
        before = hashes(self.root)
        patch = HERE / "kv-blocks-routing.patch"
        for arguments in (("--check", "--whitespace=error"), ("--whitespace=error",)):
            result = subprocess.run(["git", "apply", *arguments, str(patch)],
                                    cwd=self.root, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
        for name, values in MANIFEST["files"].items():
            self.assertEqual(hashlib.sha256((self.root / name).read_bytes()).hexdigest(), values["after"])
        result = subprocess.run(["git", "apply", "--reverse", str(patch)],
                                cwd=self.root, text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(hashes(self.root), before)


if __name__ == "__main__":
    unittest.main(verbosity=2)
