"""Dependency-free tests of the patched methods, using FIFO engine substitutes.

No vLLM/NPU is imported. This checks Python control flow, not real ZMQ/model IO.
"""
from __future__ import annotations

import ast
import asyncio
from collections import Counter, defaultdict
import copy
import contextlib
import importlib.util
import json
import math
from pathlib import Path
import random
import sys
from types import SimpleNamespace as NS
import unittest

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "modified/vllm/v1/engine/core_client.py"
HELPER = ROOT / "modified/vllm/v1/engine/kv_blocks_routing.py"
spec = importlib.util.spec_from_file_location("kv_blocks_routing_under_test", HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


def req(tokens, request_id="req", rank=None, pooling=None):
    return NS(all_token_ids=list(range(tokens)), request_id=request_id,
              data_parallel_rank=rank, pooling_params=pooling, num_computed_tokens=0)


def scheduler(running=(), waiting=(), skipped=(), block_size=128):
    return NS(cache_config=NS(block_size=block_size), block_size=2048,
              running=list(running), waiting=list(waiting), skipped_waiting=list(skipped))


def config(size=3):
    return NS(parallel_config=NS(data_parallel_size=size,
                                data_parallel_external_lb=False,
                                data_parallel_hybrid_lb=False),
              kv_transfer_config=NS(kv_role="kv_consumer"), additional_config={})


class Log:
    def __init__(self):
        self.lines = []

    def info(self, template, *args):
        self.lines.append(template % args)


class BaseIO:
    def _ensure_stats_update_task(self):
        pass

    def _ensure_output_queue_task(self):
        pass

    def _send_input(self, request_type, request, chosen_engine):
        # Sending ADD deliberately does not update the scheduler. The next
        # utility RPC must observe it by draining the same engine's FIFO.
        if request_type == "ABORT":
            for requests in (self.pending[chosen_engine],
                             self.schedulers[chosen_engine].running,
                             self.schedulers[chosen_engine].waiting,
                             self.schedulers[chosen_engine].skipped_waiting):
                requests[:] = [item for item in requests if item.request_id not in request]
            self.events.append(("ABORT", chosen_engine, request))
            return async_send(None)
        self.pending[chosen_engine].append(copy.deepcopy(request))
        self.sent.append((request.request_id, chosen_engine))
        self.events.append(("ADD", chosen_engine, request.request_id))
        return async_send(None)

    async def _call_utility_async(self, method, *, engine):
        assert method == "get_kv_blocks_routing_state"
        self.active_pulls += 1
        self.max_active_pulls = max(self.max_active_pulls, self.active_pulls)
        try:
            await asyncio.sleep(self.pull_delay)
            self.pulls += 1
            if engine == self.fail_engine:
                raise RuntimeError("rank failed")
            local = self.schedulers[engine]
            local.waiting.extend(self.pending[engine])
            self.pending[engine].clear()
            state = helper.snapshot(local, int.from_bytes(engine, "little"))
            if self.bad_states:
                state["block_size"] = -1
            self.events.append(("STATE", engine, copy.deepcopy(state)))
            return state
        finally:
            self.active_pulls -= 1


def load_client(env, log):
    tree = ast.parse(SOURCE.read_text())
    classes = {node.name: node for node in tree.body if isinstance(node, ast.ClassDef)}

    def methods(name, wanted):
        return [node for node in classes[name].body
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                and node.name in wanted]

    base = ast.ClassDef(name="DPAsyncMPClient", bases=[ast.Name(id="BaseIO", ctx=ast.Load())],
                        keywords=[], body=methods("DPAsyncMPClient", {"add_request_async"}),
                        decorator_list=[])
    child = ast.ClassDef(name="DPLBAsyncMPClient",
                         bases=[ast.Name(id="DPAsyncMPClient", ctx=ast.Load())], keywords=[],
                         body=methods("DPLBAsyncMPClient", {
                             "add_request_async", "_add_request_with_kv_blocks_async",
                             "get_core_engine_for_request",
                             "process_engine_outputs", "abort_requests_async", "_abort_requests",
                             "prepare_elastic_ep"}), decorator_list=[])
    future = ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0)
    module = ast.fix_missing_locations(ast.Module(body=[future, base, child], type_ignores=[]))
    namespace = dict(BaseIO=BaseIO, asyncio=asyncio, contextlib=contextlib,
                     sys=sys, math=math, envs=env, defaultdict=defaultdict,
                     EngineIdentity=bytes,
                     logger=log, EngineCoreRequestType=NS(ADD="ADD", ABORT="ABORT"),
                     choose_rank=helper.choose_rank, validate_states=helper.validate_states,
                     get_late_interaction_engine_index=lambda params, count: params)
    exec(compile(module, str(SOURCE), "exec"), namespace)
    return namespace["DPLBAsyncMPClient"]


def make_client(size=3, enabled=True):
    env = NS(VLLM_DP_KV_BLOCKS_ROUTING=enabled, VLLM_DP_KV_BLOCKS_LOG=True,
             VLLM_DP_KV_BLOCKS_TIMEOUT_S=1.0)
    log = Log()
    cls = load_client(env, log)
    client = cls()
    engines = [rank.to_bytes(2, "little") for rank in range(size)]
    client.__dict__.update(
        vllm_config=config(size), engine_ranks_managed=list(range(size)),
        core_engines=engines, _kv_blocks_lock=asyncio.Lock(),
        _kv_blocks_next_engine=None, _kv_blocks_sequence=0,
        _kv_blocks_pending_requests=set(), _kv_blocks_aborted_requests=set(),
        eng_start_index=0, client_count=1, client_index=0, current_wave=3,
        engines_running=False, first_req_send_socket=NS(send=async_send),
        engine_inflight=Counter(), reqs_in_flight={}, lb_engines=[[0, 0, 0.0] for _ in engines],
        pending={engine: [] for engine in engines},
        schedulers={engine: scheduler() for engine in engines}, sent=[], events=[],
        active_pulls=0, max_active_pulls=0, pulls=0, pull_delay=0,
        fail_engine=None, bad_states=False, resources=NS(engine_dead=False),
    )
    # DPAsyncMPClient uses msgspec only for the standard first-wave wakeup.
    namespace = cls.add_request_async.__globals__
    namespace["msgspec"] = NS(msgpack=NS(encode=lambda value: json.dumps(
        [value[0], int.from_bytes(value[1], "little")]).encode()))
    return client, env, log


async def async_send(value):
    await asyncio.sleep(0)


class SnapshotTests(unittest.TestCase):
    def test_optional_step_log_prints_before_execution(self):
        tree = ast.parse((ROOT / "modified/vllm/v1/engine/core.py").read_text())
        method = next(node for cls in tree.body if isinstance(cls, ast.ClassDef)
                      for node in cls.body if isinstance(node, ast.FunctionDef)
                      and node.name == "_process_engine_step")
        log = Log()
        env = NS(VLLM_DP_KV_BLOCKS_ROUTING=True, VLLM_DP_KV_BLOCKS_STEP_LOG=True)
        namespace = dict(envs=env, logger=log)
        exec(compile(ast.fix_missing_locations(ast.Module(body=[method], type_ignores=[])),
                     "core.py", "exec"), namespace)
        state = helper.snapshot(scheduler([req(129)], skipped=[req(257)]), 1)
        def step():
            self.assertEqual(len(log.lines), 1)
            return {}, True
        engine = NS(current_wave=3, step_counter=7, dp_rank=1,
                    get_kv_blocks_routing_state=lambda: state,
                    step_fn=step, post_step=lambda executed: None)
        self.assertTrue(namespace["_process_engine_step"](engine))
        self.assertIn("wave=3 step=7 DP1 | Run(1): [2] | Wait(1): [3]", log.lines[0])
        env.VLLM_DP_KV_BLOCKS_STEP_LOG = False
        self.assertTrue(namespace["_process_engine_step"](engine))
        self.assertEqual(len(log.lines), 1)

    def test_dyntralb_formula_and_all_waiting_statuses(self):
        state = helper.snapshot(scheduler(
            [req(1), req(128), req(129)], [req(256)], [req(257), req(0)]), 2)
        self.assertEqual(state["running_blocks"], [1, 1, 2])
        self.assertEqual(state["waiting_blocks"], [2, 3, 0])
        self.assertEqual(state["block_size"], 128)
        self.assertEqual(helper.validate_states([state], [2]), [9])

    def test_no_snapshot_truncation(self):
        state = helper.snapshot(scheduler(waiting=[req(1) for _ in range(1500)]), 0)
        self.assertEqual(len(state["waiting_blocks"]), 1500)

    def test_invalid_block_size(self):
        for value in (0, -1, True, None, 128.0):
            with self.assertRaises(RuntimeError):
                helper.snapshot(scheduler(block_size=value), 0)

    def test_json_round_trip_and_total_includes_waiting(self):
        states = [helper.snapshot(scheduler([req(128)], [req(2560)]), 0),
                  helper.snapshot(scheduler([req(512)]), 1)]
        states = json.loads(json.dumps(states))
        totals = helper.validate_states(states, [0, 1])
        self.assertEqual(totals, [21, 4])
        self.assertEqual(helper.choose_rank(totals, 0, None), 1)

    def test_invalid_and_incomplete_states(self):
        valid = [helper.snapshot(scheduler(), rank) for rank in range(2)]
        variants = [valid[:1], valid[::-1], [None, valid[1]]]
        for key, value in (("running_blocks", [-1]), ("waiting_blocks", [True]),
                           ("waiting_blocks", [1.5]), ("version", 2),
                           ("block_size", 0), ("block_size", 256)):
            bad = copy.deepcopy(valid)
            bad[0][key] = value
            variants.append(bad)
        for states in variants:
            with self.assertRaises(RuntimeError):
                helper.validate_states(states, [0, 1])

    def test_ties_rotate_and_pins_are_preserved(self):
        self.assertEqual(helper.choose_rank([4, 1, 1], 2, None), 2)
        self.assertEqual(helper.choose_rank([4, 1, 1], 0, 0), 0)
        for rank in (-1, 3, True):
            with self.assertRaises(ValueError):
                helper.choose_rank([0, 0, 0], 0, rank)

    def test_supported_topology_and_rejections(self):
        helper.validate_config(config(), 1)
        variants = []
        for key, value in (("data_parallel_size", 1), ("data_parallel_external_lb", True),
                           ("data_parallel_hybrid_lb", True)):
            item = config()
            setattr(item.parallel_config, key, value)
            variants.append(item)
        item = config()
        item.kv_transfer_config.kv_role = "kv_producer"
        variants.append(item)
        item = config()
        item.additional_config = {"scheduler_config": {"dyntra_lb_config": {"enabled": True}}}
        variants.append(item)
        for item in variants:
            with self.assertRaises(ValueError):
                helper.validate_config(item, 1)
        with self.assertRaisesRegex(ValueError, "api-server-count 1"):
            helper.validate_config(config(), 2)


class RoutingTests(unittest.IsolatedAsyncioTestCase):
    async def test_next_request_sees_previous_add_through_fifo(self):
        client, _, _ = make_client()
        for engine, count in zip(client.core_engines, (10, 1, 3)):
            client.schedulers[engine].running = [req(count * 128)]
        await client.add_request_async(req(9 * 128, "large"))
        self.assertEqual([engine for _, engine in client.sent], [client.core_engines[1]])
        # No fake immediate load increment: first ADD is still in the FIFO.
        self.assertEqual(len(client.pending[client.core_engines[1]]), 1)
        await client.add_request_async(req(128, "next"))
        self.assertEqual([engine for _, engine in client.sent], client.core_engines[1:])
        self.assertEqual(client.pulls, 6)

    async def test_concurrent_burst_matches_sequential_global_minimum(self):
        client, _, log = make_client(8)
        randomizer = random.Random(922)
        counts = [randomizer.randint(1, 45) for _ in range(100)]
        await asyncio.gather(*[
            client.add_request_async(req(count * 128, str(index)))
            for index, count in enumerate(counts)
        ])
        totals = [0] * 8
        for request_id, engine in client.sent:
            rank = int.from_bytes(engine, "little")
            self.assertEqual(totals[rank], min(totals))
            totals[rank] += counts[int(request_id)]
        self.assertEqual(client.pulls, 800)
        self.assertEqual(client.max_active_pulls, 8)
        self.assertEqual(len(client.reqs_in_flight), 100)
        self.assertEqual(sum(client.engine_inflight.values()), 100)
        self.assertEqual(len(log.lines), 900)
        self.assertTrue(any("DP7 | Run(0): [] | Wait(" in line for line in log.lines))

    async def test_finished_request_load_is_refreshed(self):
        client, _, _ = make_client(2)
        client.schedulers[client.core_engines[0]].running = [req(1280)]
        await client.add_request_async(req(128, "a"))
        client.schedulers[client.core_engines[0]].running.clear()
        await client.add_request_async(req(128, "b"))
        self.assertEqual(client.sent, [("a", client.core_engines[1]), ("b", client.core_engines[0])])

    async def test_explicit_and_special_affinity(self):
        for kwargs in ({"rank": 2}, {"pooling": 2}):
            client, _, log = make_client()
            client.schedulers[client.core_engines[2]].running = [req(12800)]
            await client.add_request_async(req(128, **kwargs))
            self.assertEqual(client.sent[0][1], client.core_engines[2])
            self.assertEqual(client.pulls, 3)
            self.assertIn("pinned=True", log.lines[0])

    async def test_timeout_failure_and_invalid_snapshot_send_nothing(self):
        for failure in ("timeout", "rank", "invalid", "missing"):
            client, env, _ = make_client()
            if failure == "timeout":
                env.VLLM_DP_KV_BLOCKS_TIMEOUT_S = 0.001
                client.pull_delay = 0.02
            elif failure == "rank":
                client.fail_engine = client.core_engines[1]
            elif failure == "invalid":
                client.bad_states = True
            else:
                client.engine_ranks_managed = [0, 1]
            with self.assertRaises((RuntimeError, asyncio.TimeoutError)):
                await client.add_request_async(req(128))
            self.assertEqual(client.sent, [])
            self.assertEqual(client.reqs_in_flight, {})
            self.assertFalse(client._kv_blocks_lock.locked())

    async def test_cancel_during_pull_releases_lock_and_sends_nothing(self):
        client, _, _ = make_client()
        client.pull_delay = 0.03
        task = asyncio.create_task(client.add_request_async(req(128, "cancel")))
        await asyncio.sleep(0.001)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assertEqual(client.sent, [])
        self.assertFalse(client._kv_blocks_lock.locked())
        client.pull_delay = 0
        await client.add_request_async(req(128, "ok"))
        self.assertEqual(client.sent, [("ok", client.core_engines[0])])

    async def test_abort_during_pull_or_while_waiting_for_lock(self):
        client, _, _ = make_client()
        client.pull_delay = 0.02
        first = asyncio.create_task(client.add_request_async(req(128, "pulling")))
        second = asyncio.create_task(client.add_request_async(req(128, "queued")))
        await asyncio.sleep(0.001)
        await client.abort_requests_async(["pulling", "queued"])
        await asyncio.gather(first, second)
        self.assertEqual(client.sent, [])
        self.assertEqual(client.reqs_in_flight, {})
        self.assertEqual(client._kv_blocks_pending_requests, set())
        self.assertEqual(client._kv_blocks_aborted_requests, set())

    async def test_abort_after_dispatch_keeps_upstream_rank_routing(self):
        client, _, _ = make_client()
        await client.add_request_async(req(128, "sent", rank=2))
        await client.abort_requests_async(["sent"])
        self.assertEqual(client.events[-1], ("ABORT", client.core_engines[2], ["sent"]))
        self.assertEqual(client.pending[client.core_engines[2]], [])

    async def test_disabled_uses_upstream_routing_without_pulls_or_logs(self):
        client, _, log = make_client(enabled=False)
        await client.add_request_async(req(128, "a"))
        await client.add_request_async(req(128, "b"))
        self.assertEqual([engine for _, engine in client.sent], client.core_engines[:2])
        self.assertEqual(client.pulls, 0)
        self.assertEqual(log.lines, [])

    async def test_cannot_route_without_pull_or_change_topology(self):
        client, _, _ = make_client()
        with self.assertRaisesRegex(RuntimeError, "fresh global pull"):
            client.get_core_engine_for_request(req(128))
        with self.assertRaisesRegex(RuntimeError, "changing DP topology"):
            await client.prepare_elastic_ep(4)

    async def test_finished_outputs_preserve_upstream_tracking(self):
        client, _, _ = make_client()
        await client.add_request_async(req(128, "done"))
        engine = client.reqs_in_flight["done"]
        await type(client).process_engine_outputs(client, NS(finished_requests=["done"]))
        self.assertNotIn("done", client.reqs_in_flight)
        self.assertEqual(client.engine_inflight[engine], 0)

    async def test_logging_can_be_disabled(self):
        client, env, log = make_client()
        env.VLLM_DP_KV_BLOCKS_LOG = False
        await client.add_request_async(req(128))
        self.assertEqual(client.pulls, 3)
        self.assertEqual(log.lines, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
