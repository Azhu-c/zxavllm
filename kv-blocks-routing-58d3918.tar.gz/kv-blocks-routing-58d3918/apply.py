"""Check, install, or restore this pinned patch; no third-party packages needed."""
from __future__ import annotations

import argparse
import ast
from datetime import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile

HERE = Path(__file__).resolve().parent
MANIFEST = json.loads((HERE / "manifest.json").read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def stage_replace(root, contents):
    """Stage every file before replacing; restore originals if a write fails."""
    staged = {}
    originals = {name: (root / name).read_bytes() if (root / name).exists() else None
                 for name in contents}
    replaced = []
    try:
        for name, data in contents.items():
            if data is None:
                continue
            target = root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as handle:
                staged[name] = Path(handle.name)
                handle.write(data)
            mode = target.stat().st_mode & 0o777 if target.exists() else 0o644
            staged[name].chmod(mode)
        for name, data in contents.items():
            target = root / name
            if data is None:
                target.unlink()
            else:
                os.replace(staged[name], target)
            replaced.append(name)
    except BaseException:
        for name in reversed(replaced):
            target = root / name
            if originals[name] is None:
                target.unlink(missing_ok=True)
            else:
                target.write_bytes(originals[name])
        raise
    finally:
        for path in staged.values():
            path.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, help="directory containing vllm/; auto-detected by default")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--check", action="store_true", help="read-only check (the default)")
    mode.add_argument("--apply", action="store_true", help="back up and install verified files")
    mode.add_argument("--restore", type=Path, metavar="BACKUP", help="restore this installer's backup")
    args = parser.parse_args()
    if args.root is None:
        spec = importlib.util.find_spec("vllm")
        if spec is None or spec.origin is None:
            parser.error("vllm was not found; use the Decode environment or --root")
        args.root = Path(spec.origin).resolve().parent.parent
    root = args.root.resolve()
    print(f"vLLM root: {root}")
    if not (root / "vllm/v1/engine/core_client.py").is_file():
        parser.error("--root must contain vllm/v1/engine/core_client.py")

    files = MANIFEST["files"]
    for name, hashes in files.items():
        if digest(HERE / "modified" / name) != hashes["after"]:
            raise RuntimeError(f"Bundle is damaged: {name}")
        ast.parse((HERE / "modified" / name).read_text())
    current = {name: digest(root / name) for name in files}
    original = all(current[name] == hashes["before"] for name, hashes in files.items())
    patched = all(current[name] == hashes["after"] for name, hashes in files.items())
    if not original and not patched:
        for name, hashes in files.items():
            if current[name] not in (hashes["before"], hashes["after"]):
                print(f"MISMATCH: {name} sha256={current[name]}", file=sys.stderr)
        raise RuntimeError("Source mismatch or partial installation; no files were changed")

    if args.restore is not None:
        if not patched:
            raise RuntimeError("Restore expects exactly the installed patch; no files were changed")
        backup = args.restore.resolve()
        backup_manifest = json.loads((backup / "manifest.json").read_text())
        if backup_manifest != MANIFEST:
            raise RuntimeError("Backup belongs to a different patch")
        contents = {}
        for name, hashes in files.items():
            if digest(backup / name) != hashes["before"]:
                raise RuntimeError(f"Backup mismatch: {name}")
            contents[name] = (backup / name).read_bytes() if hashes["before"] is not None else None
        stage_replace(root, contents)
        print("RESTORED: restart Decode to load the original files")
        return

    if patched:
        print("ALREADY INSTALLED: all four files match the patch")
        return
    print("MATCH: all original files match the pinned 58d3918 source")
    if not args.apply:
        print("CHECK ONLY: no files changed")
        return
    # Preserve the original files and a reproducible restore command.
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    backup = root / f"kv-blocks-routing-backup-{stamp}"
    backup.mkdir()
    for name, hashes in files.items():
        if hashes["before"] is not None:
            target = backup / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(root / name, target)
    (backup / "manifest.json").write_text(json.dumps(MANIFEST, indent=2) + "\n")
    # Refuse a concurrent source modification between checking and installing.
    if any(digest(root / name) != value for name, value in current.items()):
        raise RuntimeError("Source changed while preparing the backup; no source files were changed")
    contents = {name: (HERE / "modified" / name).read_bytes() for name in files}
    stage_replace(root, contents)
    print(f"INSTALLED: backup={backup}")
    print("Restart Decode with VLLM_DP_KV_BLOCKS_ROUTING=1 and --api-server-count 1")
    print(f'Restore: python3 "{Path(__file__).resolve()}" --root "{root}" --restore "{backup}"')


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
