"""Rebuild the patch from the verified, pinned upstream source files."""

from difflib import unified_diff
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path(__file__).resolve().parent
FILES = ("vllm/envs.py", "vllm/v1/engine/core.py", "vllm/v1/engine/core_client.py")
HELPER = "vllm/v1/engine/kv_blocks_routing.py"
UPSTREAM_BLOBS = {
    "vllm/envs.py": "3f23fb61529679c9e886390543dfed7bb8fc95c8",
    "vllm/v1/engine/core.py": "4e7f25aee5f6da053c4b4ff0e344c486dfb6286f",
    "vllm/v1/engine/core_client.py": "d692a13d658aaaadf9086c14327d6b473e1bea5f",
}


def replace_once(text, before, after):
    if text.count(before) != 1:
        raise RuntimeError(f"Ambiguous source anchor: {before[:100]}")
    return text.replace(before, after, 1)


sources = {name: (ROOT / "base" / name).read_text() for name in FILES}
for name in FILES:
    data = (ROOT / "base" / name).read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    if blob != UPSTREAM_BLOBS[name]:
        raise RuntimeError(f"Pinned upstream blob mismatch: {name}")
envs = sources[FILES[0]]
envs = replace_once(envs, "    VLLM_DP_SIZE: int = 1\n", """    VLLM_DP_SIZE: int = 1
    VLLM_DP_KV_BLOCKS_ROUTING: bool = False
    VLLM_DP_KV_BLOCKS_LOG: bool = True
    VLLM_DP_KV_BLOCKS_STEP_LOG: bool = False
    VLLM_DP_KV_BLOCKS_TIMEOUT_S: float = 30.0
""")
envs = replace_once(envs, '    "VLLM_DP_SIZE": lambda: int(os.getenv("VLLM_DP_SIZE", "1")),\n', '''    "VLLM_DP_SIZE": lambda: int(os.getenv("VLLM_DP_SIZE", "1")),
    # Strict, fresh-state routing for a single internal-DP Decode API server.
    "VLLM_DP_KV_BLOCKS_ROUTING": lambda: (
        os.getenv("VLLM_DP_KV_BLOCKS_ROUTING", "0") == "1"
    ),
    "VLLM_DP_KV_BLOCKS_LOG": lambda: (
        os.getenv("VLLM_DP_KV_BLOCKS_LOG", "1") == "1"
    ),
    "VLLM_DP_KV_BLOCKS_STEP_LOG": lambda: (
        os.getenv("VLLM_DP_KV_BLOCKS_STEP_LOG", "0") == "1"
    ),
    "VLLM_DP_KV_BLOCKS_TIMEOUT_S": lambda: float(
        os.getenv("VLLM_DP_KV_BLOCKS_TIMEOUT_S", "30")
    ),
''')
sources[FILES[0]] = envs

core = sources[FILES[1]]
core = replace_once(core, '    def get_kv_cache_group_metadata(self)', '''    def get_kv_blocks_routing_state(self) -> dict[str, Any]:
        """Read scheduler-owned queues in the engine main loop via utility RPC."""
        from vllm.v1.engine.kv_blocks_routing import snapshot

        return snapshot(self.scheduler, self.dp_rank)

    def get_kv_cache_group_metadata(self)''')
core = replace_once(core, """        # Step the engine core.
        outputs, model_executed = self.step_fn()
""", """        # Optional per-rank queue diagnostics, including dummy/empty ranks.
        if envs.VLLM_DP_KV_BLOCKS_ROUTING and envs.VLLM_DP_KV_BLOCKS_STEP_LOG:
            state = self.get_kv_blocks_routing_state()
            running = state[\"running_blocks\"]
            waiting = state[\"waiting_blocks\"]
            logger.info(
                \"[kv_blocks_step] wave=%d step=%d DP%d | Run(%d): %s | \"
                \"Wait(%d): %s | total=%d block_size=%d\",
                self.current_wave, self.step_counter, self.dp_rank,
                len(running), running, len(waiting), waiting,
                sum(running) + sum(waiting), state[\"block_size\"],
            )
        # Step the engine core.
        outputs, model_executed = self.step_fn()
""")
sources[FILES[1]] = core

client = sources[FILES[2]]
client = replace_once(client, "import contextlib\n", "import contextlib\nimport math\n")
client = replace_once(client, "from vllm.v1.engine.exceptions import EngineDeadError\n", '''from vllm.v1.engine.exceptions import EngineDeadError
from vllm.v1.engine.kv_blocks_routing import (
    choose_rank,
    validate_config as validate_kv_blocks_config,
    validate_states,
)
''')
client = replace_once(client, """        if parallel_config.data_parallel_size > 1:
            if parallel_config.data_parallel_external_lb:
""", """        if envs.VLLM_DP_KV_BLOCKS_ROUTING:
            validate_kv_blocks_config(vllm_config, client_count)
        if parallel_config.data_parallel_size > 1:
            if parallel_config.data_parallel_external_lb:
""")
client = replace_once(client, """        self.client_count = client_count

        # To route aborts""", """        if envs.VLLM_DP_KV_BLOCKS_ROUTING:
            validate_kv_blocks_config(vllm_config, client_count)
            timeout = envs.VLLM_DP_KV_BLOCKS_TIMEOUT_S
            if not math.isfinite(timeout) or timeout <= 0:
                raise ValueError("VLLM_DP_KV_BLOCKS_TIMEOUT_S must be positive")
        self._kv_blocks_lock = asyncio.Lock()
        self._kv_blocks_next_engine: int | None = None
        self._kv_blocks_sequence = 0
        self._kv_blocks_pending_requests: set[str] = set()
        self._kv_blocks_aborted_requests: set[str] = set()
        self.client_count = client_count

        # To route aborts""")
client = replace_once(client, """    def get_core_engine_for_request(self, request: EngineCoreRequest) -> EngineIdentity:
        # Engines are in rank order.
        if (eng_index := request.data_parallel_rank) is None and (
""", '''    async def add_request_async(self, request: EngineCoreRequest) -> None:
        if not envs.VLLM_DP_KV_BLOCKS_ROUTING:
            await super().add_request_async(request)
            return

        # An abort may arrive before upstream's route map exists.
        request_id = request.request_id
        self._kv_blocks_pending_requests.add(request_id)
        try:
            await self._add_request_with_kv_blocks_async(request)
        finally:
            self._kv_blocks_pending_requests.discard(request_id)
            self._kv_blocks_aborted_requests.discard(request_id)

    async def _add_request_with_kv_blocks_async(
        self, request: EngineCoreRequest
    ) -> None:
        # One API server owns all ADDs. Serialize the entire pull/choose/send
        # transaction, including concurrently arriving HTTP requests.
        async with self._kv_blocks_lock:
            if request.request_id in self._kv_blocks_aborted_requests:
                return
            ranks = list(self.engine_ranks_managed)
            if ranks != list(range(self.vllm_config.parallel_config.data_parallel_size)):
                raise RuntimeError("KV-block routing must cover every Decode rank")
            tasks = [
                asyncio.create_task(self._call_utility_async(
                    "get_kv_blocks_routing_state", engine=engine
                ))
                for engine in self.core_engines
            ]
            pull = asyncio.gather(*tasks)
            try:
                states = await asyncio.wait_for(
                    pull, timeout=envs.VLLM_DP_KV_BLOCKS_TIMEOUT_S
                )
            finally:
                for task in tasks:
                    if not task.done():
                        task.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await pull
                await asyncio.gather(*tasks, return_exceptions=True)
            if request.request_id in self._kv_blocks_aborted_requests:
                return
            # Never dispatch with a partial, invalid, or cached snapshot.
            totals = validate_states(states, ranks)
            preferred = request.data_parallel_rank
            if preferred is None:
                preferred = get_late_interaction_engine_index(
                    request.pooling_params, len(self.core_engines)
                )
            selected = choose_rank(totals, self.eng_start_index, preferred)
            self._kv_blocks_sequence += 1
            if envs.VLLM_DP_KV_BLOCKS_LOG:
                logger.info(
                    "[kv_blocks_route] seq=%d totals=%s selected=DP%d pinned=%s",
                    self._kv_blocks_sequence, totals, ranks[selected],
                    preferred is not None,
                )
                for rank, state in zip(ranks, states):
                    running = state["running_blocks"]
                    waiting = state["waiting_blocks"]
                    logger.info(
                        "[kv_blocks_route] seq=%d DP%d | Run(%d): %s | "
                        "Wait(%d): %s | total=%d block_size=%d",
                        self._kv_blocks_sequence, rank, len(running), running,
                        len(waiting), waiting, sum(running) + sum(waiting),
                        state["block_size"],
                    )
            self._kv_blocks_next_engine = selected
            try:
                # Reuse upstream ADD, DP-wave wakeup and request/abort tracking.
                # ADD and the next pull use the same ordered ZMQ channel to
                # this engine. Its FIFO input queue processes the previous ADD
                # before answering that pull, so a burst sees its earlier ADDs.
                await super().add_request_async(request)
                self.eng_start_index = (selected + 1) % len(totals)
            finally:
                self._kv_blocks_next_engine = None

    def get_core_engine_for_request(self, request: EngineCoreRequest) -> EngineIdentity:
        # Engines are in rank order.
        if envs.VLLM_DP_KV_BLOCKS_ROUTING:
            eng_index = self._kv_blocks_next_engine
            if eng_index is None:
                raise RuntimeError("KV-block routing requires a fresh global pull")
        elif (eng_index := request.data_parallel_rank) is None and (
''')
client = replace_once(client, """    async def prepare_elastic_ep(self, new_data_parallel_size: int) -> None:
        \"\"\"Prepare elastic EP scaling without routing requests to new engines.\"\"\"
""", """    async def prepare_elastic_ep(self, new_data_parallel_size: int) -> None:
        \"\"\"Prepare elastic EP scaling without routing requests to new engines.\"\"\"
        if envs.VLLM_DP_KV_BLOCKS_ROUTING:
            raise RuntimeError("Disable KV-block routing before changing DP topology")
""")
client = replace_once(client, """    async def abort_requests_async(self, request_ids: list[str]) -> None:
        if not request_ids or self.resources.engine_dead:
""", """    async def abort_requests_async(self, request_ids: list[str]) -> None:
        if envs.VLLM_DP_KV_BLOCKS_ROUTING:
            self._kv_blocks_aborted_requests.update(
                request_id for request_id in request_ids
                if request_id in self._kv_blocks_pending_requests
            )
        if not request_ids or self.resources.engine_dead:
""")
sources[FILES[2]] = client
sources[HELPER] = (ROOT / "kv_blocks_routing.py").read_text()

patch = []
manifest = {"vllm_commit": "58d3918e3ea0a544ffedadad2ba84559e9c51d8f",
            "upstream_git_blobs": UPSTREAM_BLOBS, "files": {}}
for name, content in sources.items():
    ast.parse(content)
    before_path = ROOT / "base" / name
    before = before_path.read_text() if before_path.exists() else ""
    path = ROOT / "modified" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    patch.extend(unified_diff(before.splitlines(True), content.splitlines(True),
                              fromfile="a/" + name if before_path.exists() else "/dev/null",
                              tofile="b/" + name))
    manifest["files"][name] = {
        "before": hashlib.sha256(before.encode()).hexdigest() if before_path.exists() else None,
        "after": hashlib.sha256(content.encode()).hexdigest(),
    }
(ROOT / "kv-blocks-routing.patch").write_text("".join(patch))
(ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print("Built patch and parsed all four Python files")
