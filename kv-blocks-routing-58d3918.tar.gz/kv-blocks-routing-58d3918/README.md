# DyntraLB 基线上的 KV blocks 感知分发

这份包修改 **vLLM 的 Decode 内部 DP 路由**，将 P/D proxy 转交给 Decode API 的请求依次分配到 D rank。保持原有 Prefill、proxy、Mooncake 和 Decode 调度器的入口；在 Decode 启动时开启本策略。没有启动或改动远程服务器。

## 基线版本

之前讨论的固定配套版本为：

| 项目 | 固定版本 |
| --- | --- |
| vLLM | `58d3918e3ea0a544ffedadad2ba84559e9c51d8f` |
| 不含 DyntraLB 的 vLLM-Ascend 基线 | `11d9a6775c3e3a54d78cd15397a28a04b6736c23` |
| 原 DyntraLB PR head | `2a982061275a8de5f9a05a99ae5adb9d6a1d0b50` |

[DyntraLB PR #12292](https://github.com/vllm-project/vllm-ascend/pull/12292) 和 [Ascend 基线提交](https://github.com/vllm-project/vllm-ascend/commit/11d9a6775c3e3a54d78cd15397a28a04b6736c23) 都标注 `vLLM version: v0.26.0`，并明确指向上面的 vLLM `58d3918` 提交。

**请以提交号为准。** 官方 `v0.26.0` tag 实际指向 `568afb3a13806beb53bb2e6bd518269357b237c0`，与 `58d3918` 不同。服务器显示的 `0.26.1rc1.dev183` 也不足以证明代码提交一致。安装程序核对三个原文件的 SHA-256，版本不匹配时停止。

本包中的 `base/` 是通过 GitHub 读取并核对 Git blob SHA 的官方 `58d3918` 源码；`modified/` 是修改后的完整文件；`kv-blocks-routing.patch` 是对应差异。补丁不要求安装 DyntraLB 的 Python 模块。若采用其他 Ascend 安装，仍需使用与该 vLLM 提交兼容的配套依赖。

## 计算和分发规则

沿用 [DyntraLB 的 request blocks 计算](https://github.com/Azhu-c/zxavllm/blob/ac22f968735a9f3af60f5833e4f63c7cc1a9e3d2/vllm_ascend/core/dyntra_lb_scheduler.py)：

```python
request_blocks = (len(request.all_token_ids) + block_size - 1) // block_size
block_size = scheduler.cache_config.block_size
rank_load = sum(running_blocks) + sum(waiting_blocks)
```

- `all_token_ids` 是当前 prompt 和已产生的 output token 序列；不预测未来输出长度。
- 使用 `cache_config.block_size`。混合模型下，它可能与 `scheduler.block_size` 不同。
- `waiting_blocks` 包含 `waiting` 和 `skipped_waiting`，涵盖等待远程 KV、语法准备、抢占等仍属于该 rank 的请求。不只统计当前可准入候选，也不按 `max_slots` 截断。
- 这是 DyntraLB 的逻辑负载单位，不是 allocator 的物理 KV pool 使用率；共享前缀、混合注意力和 MTP 的实际显存占用不由这个数精确表示。

每个请求执行以下流程：

1. 进入单个 API server 的分发锁；并发到达的请求也依次处理。
2. 向全部 D rank 发起 utility RPC，等待全部返回当前 running/waiting blocks 数组。
3. 校验 rank 完整性、数组和 block size 一致性；任何失败或超时都不使用旧快照发请求。
4. 选择 `rank_load` 最小的 rank；只在负载相同时轮转。
5. 使用上游 ADD 和 wave 唤醒流程发送，保留请求跟踪、完成回收和 abort 的 rank 路由。
6. 后一个请求重新拉取全部状态。上一 ADD 与对该 rank 的下一次 RPC 使用同一条有序 ZMQ 通道，engine FIFO 先处理 ADD，再返回快照；上一请求会计入队列，若已完成则自然不再计入。

如果请求明确指定 `data_parallel_rank` 或带有上游特殊亲和性，保留该指定，日志显示 `pinned=True`。一般自动分发请求始终选择最小负载。等待分发锁或状态 RPC 时发生的 abort 会阻止该请求继续发送。

这里“每次同步全局信息”指每次 ADD 前都等待所有 rank 的新 RPC 响应。各 rank 在自己的 engine 主循环安全点读取队列；不暂停全部 rank，也不声称它们来自同一个原子时刻或相同 engine step。没有依赖 coordinator 的约 100ms 周期快照，没有在 RPC 中新增 torch collective。

**严格依次分发要求 Decode 使用 `--api-server-count 1`，internal DP，且该 API 覆盖全部 rank。** 多 API server、external/hybrid LB、非 `kv_consumer`、同时启用 DyntraLB 会在启动时拒绝；开启后也拒绝弹性修改 DP 拓扑。这一限制用于确保分发锁覆盖全部新请求。

## 安装

将 `kv-blocks-routing-58d3918.tar.gz` 复制到服务器任意实验目录。使用与 Decode 相同的 Python 环境，停掉该实验 Decode 服务后执行：

```bash
tar -xzf kv-blocks-routing-58d3918.tar.gz
cd kv-blocks-routing-58d3918
python3 apply.py --check
python3 apply.py --apply
```

程序自动寻找当前 Python 环境中的 vLLM，并核对原文件。`--check` 不写文件；`--apply` 先保留备份，再安装四个 Python 文件。备份路径和恢复命令会打印出来。也可以通过 `--root /实际路径/vllm源码根目录` 指定包含 `vllm/` 的目录。

如果提示 `MISMATCH`，不要覆盖：当前源码可能是官方 tag、之前的占用率路由补丁，或服务器自己的改动。保留提示中的路径、哈希和对应源码，再适配。旧的 `outputs/dp-kv-aware-routing` 补丁不能与本补丁叠加。

如安装环境从另外的打包产物加载 Python 文件，需让 Decode 环境实际加载这次修改的包；本程序打印的 root 应与 Decode 服务使用的路径一致。

## 启动

只在 **Decode** 的启动环境设置：

```bash
export VLLM_DP_KV_BLOCKS_ROUTING=1
export VLLM_DP_KV_BLOCKS_LOG=1
export VLLM_DP_KV_BLOCKS_STEP_LOG=1
export VLLM_DP_KV_BLOCKS_TIMEOUT_S=30
```

然后使用原来的基线 Decode 启动命令，并把其 `--api-server-count` 设为 `1`。关闭 `scheduler_config.dyntra_lb_config.enabled`；其余模型、P/D、DP/TP/EP、MTP、量化等参数沿用对照配置。Prefill 和 proxy 不需要开启这些变量。所有 Decode rank 的进程都应继承它们。

`VLLM_DP_KV_BLOCKS_STEP_LOG=1` 会在每个 rank 进入 engine step 前打印本地队列，包括空 rank；日志按 `wave/step/DP` 对齐查看，输出可能交错。它不新增逐步全局同步。默认是 `0`。

`VLLM_DP_KV_BLOCKS_LOG=1` 在每次分发前打印全局数组，默认开启。示意如下（仅用于说明格式，不是硬件实测）：

```text
[kv_blocks_route] seq=1 totals=[10, 1, 3] selected=DP1 pinned=False
[kv_blocks_route] seq=1 DP0 | Run(1): [10] | Wait(0): [] | total=10 block_size=128
[kv_blocks_route] seq=1 DP1 | Run(1): [1] | Wait(0): [] | total=1 block_size=128
[kv_blocks_route] seq=1 DP2 | Run(1): [3] | Wait(0): [] | total=3 block_size=128
```

若本次请求为 9 blocks，且下一次读取前其他状态未变化，下一次总量就是 `[10, 10, 3]`，应选择 DP2。上述数组是发送前的快照，不包含当前即将发送的请求。

每步日志格式示例：

```text
[kv_blocks_step] wave=3 step=7 DP1 | Run(2): [1, 9] | Wait(1): [2] | total=12 block_size=128
```

大量数组日志会影响性能。检查功能后做吞吐/时延实验，可以将 `VLLM_DP_KV_BLOCKS_LOG=0`、`VLLM_DP_KV_BLOCKS_STEP_LOG=0`；这只关闭打印，仍然每个请求同步全局状态。

做原生路由对照时，将 `VLLM_DP_KV_BLOCKS_ROUTING=0` 并重新启动 Decode，保持 `--api-server-count 1` 和其余配置一致。关闭后沿用上游路由，不拉取这些快照，也不打印新增数组日志。

## 验证与恢复

本地已通过：

- 20 项 Python 逻辑检查：真实修改方法在运行时替身中执行；覆盖 100 个并发到达请求和 8 个模拟 rank 的连续最小负载分发、FIFO 可见性、请求完成、等待期间 abort、指定 rank、超时/异常拒绝、逐步日志和关闭路径。
- 5 项安装/补丁检查：只读检查、源码不匹配拒绝、重复安装、精确回退、后续改动保护，以及 `git apply` 应用/反向恢复后与原文件逐字节一致。
- 修改后的四个 Python 文件通过语法解析；三个上游原文件已核对官方 Git blob SHA。

可在本目录复现：

```bash
PYTHONDONTWRITEBYTECODE=1 python3 test_routing.py
PYTHONDONTWRITEBYTECODE=1 python3 test_installer.py
```

本机未运行真实 vLLM/PyTorch/Ascend、ZMQ 多进程、Mooncake、模型生成、异步调度/MTP 或性能实验。服务器需要检查启动、少量请求的完整输出、取消/完成和数组日志，再测性能。每个请求等待全部 rank 回复的开销是本方案的一部分。

恢复源码时先停止实验 Decode，再执行安装程序打印的恢复命令：

```bash
python3 apply.py --restore /安装时打印的/kv-blocks-routing-backup-时间戳
```

恢复后重启 Decode。安装后若又修改了这些文件，恢复程序会拒绝覆盖，保留后来的改动。也可在固定提交的源码工作树中用 `git apply --check kv-blocks-routing.patch` 后应用补丁；安装程序与补丁二选一。
