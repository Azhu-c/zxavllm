#!/usr/bin/env python3
"""Batch process files, directories or glob patterns with no extra packages."""
from __future__ import annotations

import argparse
import csv
import glob
import json
from pathlib import Path
import re
import sys

from extract_kv_steps import Extractor, export, write_csv


def input_files(inputs, pattern, recursive):
    result, seen = [], set()
    for item in inputs:
        path = Path(item)
        if path.is_dir():
            found = sorted(path.rglob(pattern) if recursive else path.glob(pattern))
        elif path.is_file():
            found = [path]
        else:
            found = [Path(name) for name in sorted(glob.glob(item, recursive=recursive))]
            if not found:
                raise ValueError(f"No files matched: {item}")
        for path in found:
            path = path.resolve()
            if path.is_file() and path not in seen:
                result.append(path)
                seen.add(path)
    if not result:
        raise ValueError("No input files found")
    return result


def merge_csv(outputs, filename, target):
    fields = ["source_file"]
    for source, directory in outputs:
        with (directory / filename).open(encoding="utf-8-sig", newline="") as handle:
            for field in next(csv.reader(handle)):
                if field not in fields:
                    fields.append(field)
    # Normalize DP0..DPn field order when files have different DP sizes.
    dp_fields = sorted((name for name in fields if re.fullmatch(r"DP\d+_total(?:_before)?", name)),
                       key=lambda name: int(re.search(r"\d+", name)[0]))
    if dp_fields:
        insert_at = min(fields.index(name) for name in dp_fields)
        fields = [name for name in fields if name not in dp_fields]
        fields[insert_at:insert_at] = dp_fields
    with target.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for source, directory in outputs:
            with (directory / filename).open(encoding="utf-8-sig", newline="") as original:
                for row in csv.DictReader(original):
                    writer.writerow({"source_file": str(source), **row})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("inputs", nargs="+", help="log files, directories, or quoted glob patterns")
    parser.add_argument("-o", "--outdir", type=Path, default=Path("kv_extracted"))
    parser.add_argument("--glob", default="*.log", help="file pattern when scanning a directory (default: *.log)")
    parser.add_argument("--recursive", action="store_true", help="scan nested directories too")
    parser.add_argument("--ranks", type=int, help="expected DP count, e.g. 8")
    parser.add_argument("--max-context-lines", type=int, default=1000)
    args = parser.parse_args()
    if args.ranks is not None and args.ranks < 1:
        parser.error("--ranks must be positive")
    if args.max_context_lines < 0:
        parser.error("--max-context-lines must be non-negative")
    files = input_files(args.inputs, args.glob, args.recursive)
    if args.outdir.exists() and any(args.outdir.iterdir()):
        parser.error("Output directory is not empty; choose a new -o directory")
    args.outdir.mkdir(parents=True, exist_ok=True)
    summaries, outputs = [], []
    for index, path in enumerate(files, 1):
        safe_name = re.sub(r"[^\w.-]+", "_", path.stem, flags=re.UNICODE)
        directory = args.outdir / f"{index:04d}_{safe_name}"
        try:
            extractor = Extractor(args.ranks, args.max_context_lines)
            with path.open(encoding="utf-8-sig", errors="replace") as handle:
                for line, text in enumerate(handle, 1):
                    extractor.feed(text, line)
            extractor.finish()
            if not extractor.observations and not extractor.routes:
                summaries.append(dict(source_file=str(path), status="no_kv_records", message="No KV-block step/route records"))
                print(f"[{index}/{len(files)}] 跳过（无KV记录）: {path.name}")
                continue
            directory.mkdir()
            summary = export(extractor, directory, path)
            summaries.append(dict(source_file=str(path), status="ok", output_directory=str(directory.resolve()), **summary))
            outputs.append((path, directory))
            print(f"[{index}/{len(files)}] {path.name}: step={summary['step_rows']}, 分发={summary['route_decisions']}, 未关联={summary['unmatched_routes']}")
        except (OSError, ValueError) as error:
            summaries.append(dict(source_file=str(path), status="error", message=str(error)))
            print(f"[{index}/{len(files)}] 失败: {path.name}: {error}", file=sys.stderr)
    if outputs:
        for name in ("steps.csv", "routes.csv", "rank_steps.csv", "issues.csv"):
            merge_csv(outputs, name, args.outdir / ("all_" + name))
    counts = {
        "input_files": len(files), "processed_files": len(outputs),
        "skipped_files": sum(summary["status"] == "no_kv_records" for summary in summaries),
        "failed_files": sum(summary["status"] == "error" for summary in summaries),
        "step_rows": sum(summary.get("step_rows", 0) for summary in summaries),
        "route_decisions": sum(summary.get("route_decisions", 0) for summary in summaries),
        "unmatched_routes": sum(summary.get("unmatched_routes", 0) for summary in summaries),
    }
    (args.outdir / "batch_summary.json").write_text(json.dumps({**counts, "files": summaries}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    fields = ["source_file", "status", "step_rows", "step_observations", "route_decisions", "associated_routes", "unmatched_routes", "incomplete_steps", "issues", "output_directory", "message"]
    write_csv(args.outdir / "batch_summary.csv", fields, ({key: summary.get(key, "") for key in fields} for summary in summaries))
    print(f"批量结果: {args.outdir.resolve()}")
    print(f"文件={len(outputs)}；step={counts['step_rows']}；分发={counts['route_decisions']}；未关联={counts['unmatched_routes']}")
    return 1 if counts["failed_files"] or not outputs else 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
