# KV 日志批量提取

直接处理现有 Decode 日志，不修改服务或日志。只使用 Python 标准库，无需安装其他包；Python 3.9 及以上可用。

本次更新在 step 总表和分发表末尾增加不均衡度，**最后一列为 `imbalance_l1`：各 rank 与平均负载的绝对差之和**。原有提取命令不变。

## 用法

解压后进入脚本目录：

```bash
tar -xzf kv-log-extractor.tar.gz
cd kv-log-extractor
```

处理单个日志：

```bash
python3 extract_kv_steps.py /实际路径/decoder_kv.log --ranks 8 -o result
```

批量处理整个目录中的日志：

```bash
python3 batch_extract.py /实际路径/log --glob 'decoder*.log' --ranks 8 -o batch_result
```

也可传入多个文件或通配符：

```bash
python3 batch_extract.py '/实际路径/log/decoder*.log' --ranks 8 -o batch_result
```

如果日志在多层子目录中，增加 `--recursive`。目标目录请选新的目录，批量程序会拒绝覆盖已有结果。单文件程序可显式增加 `--overwrite` 重新生成自己的六个输出文件。

如果已经有旧版 CSV，不必重新解析大日志，可以直接补列：

```bash
python3 add_imbalance.py /实际路径/result/all_steps.csv \
  -o /实际路径/result/all_steps_imbalance.csv
```

同样支持 `steps.csv`、`routes.csv` 和 `all_routes.csv`。请将 `add_imbalance.py` 与 `extract_kv_steps.py` 放在同一目录。输入 CSV 保持不变，新指标写入另一个文件；原先已有的同名指标列会重新计算，并将 `imbalance_l1` 放回最后一列。

## 不均衡度怎么算

设某一步有 N 个 DP rank，负载为 `L_i`，平均负载 `avg = sum(L_i) / N`。

直接计算 `sum(L_i - avg)` 会抵消为 0，所以这里使用绝对值：

```text
imbalance_l1 = sum(abs(L_i - avg))
```

新增五列，最后一列始终为你要求的绝对差之和：

| 列名 | 公式 | 用途 |
| --- | --- | --- |
| `load_avg` | `sum(L_i) / N` | 该 step 的平均 rank 负载，单位 blocks |
| `imbalance_l1_normalized` | `sum(abs(L_i-avg)) / sum(L_i)` | 对绝对差之和做归一化，便于比较总负载不同的 step |
| `imbalance_cv` | `sqrt(sum((L_i-avg)^2)/N) / avg` | 变异系数，观察整体离散程度，对较大偏差更敏感 |
| `imbalance_max_avg_excess` | `max(L_i) / avg - 1` | 最重 rank 比平均值高多少，便于观察可能的瓶颈 |
| **`imbalance_l1`（最后一列）** | **`sum(abs(L_i-avg))`** | **你要求的指标，单位 blocks** |

除 `load_avg` 只是背景负载外，四个不均衡指标均是越小越均衡。三个相对指标输出小数，例如 `0.03` 表示 3%；归一化绝对差和、CV、最大超出比例都可能超过 1，不要把它们当成必须处于 0～100% 的概率。

CV 使用全部 DP rank 的**总体标准差**（分母 N，而非 N-1）。其标准定义为标准差与平均值之比：[NIST 定义](https://www.itl.nist.gov/div898/software/dataplot/refman1/auxillar/coefvate.htm)。对于你的 blocks 指标，建议用 `imbalance_l1_normalized` 比较整体偏差，配合 `imbalance_max_avg_excess` 查看最重 rank；CV 可作补充。这些是 blocks 负载指标，不等于实测执行时间的不均衡度。

你的示例得到：

| step | avg | 归一化绝对差和 | CV | 最大超出均值比例 | 绝对差之和 |
| --- | --- | --- | --- | --- | --- |
| 1204 | 145.375 | 0.02601032 | 0.02771584 | 0.03181427 | 30.25 |
| 1205 | 145.25 | 0.03227194 | 0.03671382 | 0.04647160 | 37.5 |
| 1206 | 145 | 0.03103448 | 0.03307470 | 0.04827586 | 36 |

指标使用该行全部 rank 的 `total`。缺 rank 或缺值时，五列全部留空，不会用剩余 rank 代替全体计算。全部 rank 均为 0 时，平均值和绝对差和为 0；三个相对指标数学上为 0/0，脚本按“全零负载均衡”的约定记为 0。所有指标保留最多 8 位小数。

如果原始数组与打印的 total 不一致，指标仍按日志打印的 total 计算，原来的校验提示保留在 `issues.csv`；CSV 补列工具不读取原日志，不能重新核验数组。

## 优先看哪些文件

单文件结果：

| 文件 | 内容 |
| --- | --- |
| `steps.csv` | **每行一个 run/wave/step**；DP0～DP7 的 total，该步关联的分发次数、全部 `seq→DP` |
| `steps.txt` | 同样的逐步结果，用普通文本直接阅读 |
| `routes.csv` | **每行一次分发**；seq、step、selected、pinned、发送前各 rank total、关联依据 |
| `rank_steps.csv` | 每条原始 rank-step 观察；total、running/waiting 数量与 blocks 合计、源文件行号 |
| `issues.csv` | 缺损记录、数组和 total 不一致、相同 step 的状态变化等提示 |
| `summary.json` | 记录数、step 数、缺 rank 的 step 数、未关联分发数等摘要 |

批量结果根目录中：

- **`all_steps.csv`：所有文件的逐 step 总表。**
- **`all_routes.csv`：所有文件的逐次分发总表。**
- `all_rank_steps.csv`、`all_issues.csv`：对应的明细汇总。
- `batch_summary.csv`、`batch_summary.json`：每个文件的处理状态和计数。
- `0001_日志名/` 等子目录：各文件独立的六份结果。

汇总表增加 `source_file` 列，避免不同实验中的同一个 step 或 seq 混在一起。多个输入文件独立解析；连续轮转日志若要作为同一实验连续关联，应先按时间顺序合并为一个输入文件，避免在轮转边界缺失上下文。

## 你提供的日志，提取结果

前一段 step 1204 与本次补充的 1205、1206 合起来得到：

| wave | step | DP0 | DP1 | DP2 | DP3 | DP4 | DP5 | DP6 | DP7 | 分发 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 1204 | 148 | 141 | 148 | 141 | 149 | 147 | 139 | 150 | seq635 → DP6 |
| 0 | 1205 | 148 | 141 | 148 | 141 | 135 | 147 | 152 | 150 | seq636 → DP4 |
| 0 | 1206 | 149 | 141 | 138 | 141 | 142 | 147 | 152 | 150 | seq637 → DP2 |

完整示例在 `combined_output/steps.csv` 与 `combined_output/routes.csv`。

同一步有多次分发时，`dispatches` 会保留全部记录，例如：

```text
seq=635->DP6; seq=636->DP4
```

`dispatch_count=0` 表示日志中没有关联到这一行的分发记录，不等于从不完整日志证明系统没有分发。

## 提取规则

1. 从 `[kv_blocks_step]` 直接读取 `wave`、`step`、DP rank、`total`。按 `(run, wave, step)` 汇总，保留同一秒内的不同 step，不按秒合并。
2. 从 `[kv_blocks_route]` 的汇总行直接读取 `seq` 和 `selected=DPn`，因此**分发目标本身不需要推断**。
3. 现有 route 汇总行没有 wave/step，所以使用该目标 rank 在汇总行之前最近的 step 记录来关联。你的示例中，8 个 rank 的相邻记录都在同一步，且目标 rank 的 Run/Wait 数组也一致。
4. 输出 `association` 明确标注关联方式；有明文 wave/step 的 route 行优先使用明文值。上下文关联是离线日志的关联规则，不是额外记录了真实 ADD 发生在哪个 engine step。
5. 如果目标 rank 的 route 数组与候选 step 数组不同、没有前序 step，或相隔太远，保留该次分发及目标，但把关联 step 留空。候选 step、源文件行号仍保存在 `routes.csv`，不丢记录。

`association` 的常见取值：

| 值 | 含义 |
| --- | --- |
| `context_all_ranks_same_step` | 目标 rank 的相邻 step 可用，且所有 rank 的上下文均为同一个 wave/step |
| `context_selected_rank` | 使用目标 rank 的最近 step；其他 rank 的上下文不齐或步数不同 |
| `explicit_header` | route 行本身明确提供了 wave/step |
| `unmatched_no_prior_step` | 没有前序目标 rank 的 step 日志 |
| `unmatched_snapshot_differs` | route 与候选 step 的目标 rank 数组不同，未强行归入该步 |
| `unmatched_context_too_old` | 最近上下文超过允许的行数距离 |

`selected_snapshot_match=equal` 表示目标 rank 的 Run/Wait 数组及 block size 与候选 step 完全相同；`not_available` 表示缺少对应数组明细。

默认最多跨 1000 行关联，可通过 `--max-context-lines 2000` 调整；`0` 表示不限制距离。距离越大，关联的不确定性越高，建议优先检查缺日志的原因。

## 缺行、重复和重启

- 缺少某 rank 时，对应 `DPn_total` 留空，`missing_ranks` 列出缺失 rank。真实的 total=0 保留为 0。
- 相同 rank/wave/step 的多次记录，`rank_steps.csv` 保留全部观察；`steps.csv` 使用最后一次。状态有变化时在 `changed_rank_states` 和 `issues.csv` 中标明。
- 同一 API PID/run/seq、内容相同的重复分发汇总行不重复计数，次数保留在 `duplicate_headers`。
- 从 engine/API PID 变化区分同一文件内的服务重启，生成新的 `run`。step 在不同 wave 或 run 中重新从 0 开始，不会混成一行。缺少进程前缀或拼接顺序混乱时，应按实验分文件处理。
- HTTP、Mooncake KV 传输日志、coordinator warning 不作为 step 或分发记录。
- 支持 ANSI 颜色码、尾部反斜杠和同一物理行中的多条完整 KV 记录；截断或无法解析的 KV 记录写入 `issues.csv`。
- 每步 total 使用日志打印的值；数组求和不符时保留原值并提示，不擅自改写数据。

提取每个 step 需要源日志包含 `[kv_blocks_step]`，即采集时开启 `VLLM_ASCEND_KV_BLOCKS_STEP_LOG=1` 和 INFO 级别。只有 `[kv_blocks_route]` 的日志仍能提取每次分发，但无法补造没有记录的逐 step total。

## 验证

已对你提供的两段真实日志运行提取：共 **3 个 step、24 条 rank-step 观察、3 次分发**，全部有上下文关联，未发现数组与 total 不一致。

另通过 26 项标准库测试，覆盖真实示例的全部 DP 数值、同一步多次分发、同秒不同 step、wave 重置、进程重启、缺 rank、重复与截断日志、数组不匹配、批量汇总和噪声文件，以及不均衡度已知分布、全零负载、单 rank、缩放不变性、缺值、CSV 最后一列和旧 CSV 补列。

```bash
PYTHONDONTWRITEBYTECODE=1 python3 test_extractor.py
```
