import csv
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from extract_kv_steps import Extractor, export, IMBALANCE_FIELDS, load_imbalance

ROOT = Path(__file__).resolve().parent


def state(rank=0, step=1, total=3, wave=0, pid=None):
    pid = pid or 100 + rank
    return (f"(EngineCore_DP{rank} pid={pid}) INFO 11-13 12:48:46 [x.py:1] "
            f"[kv_blocks_step] wave={wave} step={step} DP{rank} | Run(1): [{total}] | Wait(0): [] | total={total} block_size=128")


def header(seq=1, selected=0, totals=(3,), pid=500, pinned=False, meta=""):
    return (f"(APIServer pid={pid}) INFO 11-13 12:48:46 [x.py:2] [kv_blocks_route] seq={seq} {meta}"
            f"totals={list(totals)} selected=DP{selected} pinned={pinned}")


def detail(seq=1, rank=0, total=3, pid=500):
    return (f"(APIServer pid={pid}) INFO 11-13 12:48:46 [x.py:3] [kv_blocks_route] seq={seq} DP{rank} "
            f"| Run(1): [{total}] | Wait(0): [] | total={total} block_size=128")


def parse(lines, ranks=None, distance=1000):
    parser = Extractor(ranks, distance)
    for line, text in enumerate(lines, 1):
        parser.feed(text, line)
    return parser.finish()


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


class ExtractionTests(unittest.TestCase):
    def test_user_logs_all_three_steps_and_routes(self):
        parser = parse((ROOT / "sample_combined.log").read_text().splitlines(), 8)
        self.assertEqual([(route.step, route.seq, route.selected) for route in parser.routes],
                         [(1204, 635, 6), (1205, 636, 4), (1206, 637, 2)])
        self.assertEqual([parser.steps[(1, 0, step, rank)].total for step, rank in ((1204, 6), (1205, 4), (1206, 2))], [139, 135, 138])
        self.assertEqual(len(parser.observations), 24)
        self.assertEqual(parser.issues, [])
        self.assertTrue(all(route.snapshot_match == "equal" for route in parser.routes))
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp)
            export(parser, directory, ROOT / "sample_combined.log")
            rows = read_csv(directory / "steps.csv")
            self.assertEqual([[int(row[f"DP{rank}_total"]) for rank in range(8)] for row in rows], [
                [148, 141, 148, 141, 149, 147, 139, 150],
                [148, 141, 148, 141, 135, 147, 152, 150],
                [149, 141, 138, 141, 142, 147, 152, 150],
            ])
            self.assertEqual([row["dispatches"] for row in rows], ["seq=635->DP6", "seq=636->DP4", "seq=637->DP2"])

    def test_multiple_dispatches_per_step_are_all_retained(self):
        parser = parse([state(1, total=2), state(0, total=3), header(totals=(3, 2), selected=1),
                        header(seq=2, totals=(3, 4), selected=0)])
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp)
            export(parser, directory, Path("test.log"))
            row = read_csv(directory / "steps.csv")[0]
            self.assertEqual(row["dispatch_count"], "2")
            self.assertEqual(row["dispatches"], "seq=1->DP1; seq=2->DP0")

    def test_same_timestamp_does_not_merge_steps(self):
        parser = parse([state(step=1), header(seq=1), state(step=2), header(seq=2)])
        self.assertEqual([route.step for route in parser.routes], [1, 2])

    def test_wave_reset_does_not_merge_same_step_number(self):
        parser = parse([state(step=1, wave=0), header(seq=1), state(step=1, wave=1), header(seq=2)])
        self.assertEqual([(route.wave, route.step) for route in parser.routes], [(0, 1), (1, 1)])

    def test_engine_and_api_restart_get_separate_runs(self):
        parser = parse([state(pid=100), header(pid=500), state(pid=200), header(pid=600)])
        self.assertEqual([(route.run, route.step) for route in parser.routes], [(1, 1), (2, 1)])
        self.assertEqual(len(parser.steps), 2)

    def test_new_api_before_new_steps_does_not_reuse_old_context(self):
        parser = parse([state(pid=100), header(pid=500), header(pid=600), state(pid=200)])
        self.assertEqual(parser.routes[1].run, 2)
        self.assertIsNone(parser.routes[1].step)
        self.assertIn((2, 0, 1, 0), parser.steps)

    def test_routes_without_step_logs_still_keep_targets(self):
        parser = parse([header(selected=1, totals=(3, 2))])
        self.assertEqual(parser.routes[0].selected, 1)
        self.assertIsNone(parser.routes[0].step)

    def test_conflicting_snapshot_keeps_route_but_leaves_step_unmatched(self):
        parser = parse([state(total=3), header(totals=(4,)), detail(total=4)])
        self.assertEqual(parser.routes[0].association, "unmatched_snapshot_differs")
        self.assertIsNone(parser.routes[0].step)
        self.assertEqual(parser.routes[0].selected, 0)

    def test_missing_rank_stays_blank_and_real_zero_stays_zero(self):
        parser = parse([state(total=0)], ranks=2)
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp)
            export(parser, directory, Path("test.log"))
            row = read_csv(directory / "steps.csv")[0]
            self.assertEqual((row["DP0_total"], row["DP1_total"]), ("0", ""))
            self.assertEqual((row["complete"], row["missing_ranks"]), ("0", "DP1"))
            self.assertTrue(all(row[name] == "" for name in IMBALANCE_FIELDS))

    def test_duplicate_headers_do_not_count_two_dispatches(self):
        parser = parse([state(), header(), header(), detail()])
        self.assertEqual(len(parser.routes), 1)
        self.assertEqual(parser.routes[0].duplicate_headers, 1)

    def test_changed_duplicate_step_state_is_flagged_and_all_observations_kept(self):
        parser = parse([state(total=3), state(total=4)])
        self.assertEqual(parser.steps[(1, 0, 1, 0)].total, 4)
        self.assertEqual(len(parser.observations), 2)
        self.assertIn((1, 0, 1, 0), parser.conflicts)

    def test_ansi_backslashes_and_joined_records(self):
        parser = parse(["\x1b[32m" + state(0) + "\x1b[0m\\ " + state(1, total=4),
                        "WARNING unrelated", header(totals=(3, 4)) + "\\"])
        self.assertEqual(len(parser.observations), 2)
        self.assertEqual(parser.routes[0].step, 1)
        self.assertEqual(parser.issues, [])

    def test_partial_record_is_reported_and_next_valid_line_is_parsed(self):
        parser = parse(["[kv_blocks_step] wave=0 step=1 DP0 | Run(1): [", state(), header()])
        self.assertEqual(len(parser.issues), 1)
        self.assertEqual(parser.routes[0].step, 1)

    def test_printed_total_is_preserved_when_array_sum_disagrees(self):
        parser = parse([state().replace("total=3", "total=9")])
        self.assertEqual(parser.observations[0].total, 9)
        self.assertFalse(parser.observations[0].valid)
        self.assertEqual(parser.issues[0]["kind"], "invalid_state")

    def test_explicit_header_step_has_priority(self):
        parser = parse([state(step=1), header(meta="wave=2 step=10 "), detail()])
        self.assertEqual((parser.routes[0].wave, parser.routes[0].step), (2, 10))
        self.assertEqual(parser.routes[0].association, "explicit_header")

    def test_non_minimum_unpinned_selection_is_reported_but_pinned_allowed(self):
        parser = parse([header(selected=0, totals=(5, 1)), header(seq=2, selected=0, totals=(5, 1), pinned=True)])
        self.assertEqual(sum(issue["kind"] == "selection_not_minimum" for issue in parser.issues), 1)
        self.assertEqual(len(parser.routes), 2)

    def test_stale_context_not_assigned(self):
        parser = parse([state(), "noise", "noise", header()], distance=2)
        self.assertEqual(parser.routes[0].association, "unmatched_context_too_old")

    def test_batch_real_logs_with_noise_file(self):
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp)
            noise = directory / "proxy.log"
            noise.write_text("POST /v1/chat/completions 200 OK\n")
            output = directory / "result"
            result = subprocess.run([sys.executable, str(ROOT / "batch_extract.py"),
                                     str(ROOT / "sample.log"), str(ROOT / "sample_extended.log"), str(noise),
                                     "--ranks", "8", "-o", str(output)], text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            rows = read_csv(output / "all_steps.csv")
            self.assertEqual([row["step"] for row in rows], ["1204", "1205", "1206"])
            self.assertEqual(list(rows[0])[-1], "imbalance_l1")
            self.assertEqual([float(row["imbalance_l1"]) for row in rows], [30.25, 37.5, 36.0])
            routes = read_csv(output / "all_routes.csv")
            self.assertEqual([row["selected"] for row in routes], ["DP6", "DP4", "DP2"])
            self.assertEqual(len({row["source_file"] for row in rows}), 2)
            self.assertEqual([row["status"] for row in read_csv(output / "batch_summary.csv")], ["ok", "ok", "no_kv_records"])


class ImbalanceTests(unittest.TestCase):
    def test_known_distribution(self):
        self.assertEqual(load_imbalance([1, 1, 1, 5]), dict(
            load_avg=2.0, imbalance_l1_normalized=0.75, imbalance_cv=0.8660254,
            imbalance_max_avg_excess=1.5, imbalance_l1=6.0))

    def test_equal_zero_and_single_rank_loads(self):
        for values, average in (([10] * 8, 10.0), ([0] * 8, 0.0), ([7], 7.0)):
            metrics = load_imbalance(values)
            self.assertEqual(metrics["load_avg"], average)
            self.assertTrue(all(metrics[name] == 0 for name in IMBALANCE_FIELDS if name != "load_avg"))

    def test_scale_invariance_of_relative_metrics(self):
        small, large = load_imbalance([1, 1, 1, 5]), load_imbalance([10, 10, 10, 50])
        self.assertEqual(large["imbalance_l1"], 10 * small["imbalance_l1"])
        for name in ("imbalance_l1_normalized", "imbalance_cv", "imbalance_max_avg_excess"):
            self.assertEqual(small[name], large[name])
        self.assertEqual(small, load_imbalance([5, 1, 1, 1]))

    def test_incomplete_invalid_and_empty_data_stay_blank(self):
        for values in (None, [], [1, None], [1, -1], [True, 1], [float("nan"), 1]):
            self.assertEqual(load_imbalance(values), dict.fromkeys(IMBALANCE_FIELDS, ""))

    def test_one_busy_rank_and_seven_idle(self):
        metrics = load_imbalance([80, 0, 0, 0, 0, 0, 0, 0])
        self.assertEqual(metrics["load_avg"], 10.0)
        self.assertEqual(metrics["imbalance_l1"], 140.0)
        self.assertEqual(metrics["imbalance_l1_normalized"], 1.75)
        self.assertEqual(metrics["imbalance_max_avg_excess"], 7.0)
        self.assertAlmostEqual(metrics["imbalance_cv"], 7 ** 0.5, places=7)

    def test_user_sample_metrics_and_last_column(self):
        parser = parse((ROOT / "sample_combined.log").read_text().splitlines(), 8)
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp)
            export(parser, directory, ROOT / "sample_combined.log")
            for name in ("steps.csv", "routes.csv"):
                rows = read_csv(directory / name)
                self.assertEqual(list(rows[0])[-1], "imbalance_l1")
                self.assertEqual([float(row["imbalance_l1"]) for row in rows], [30.25, 37.5, 36.0])
                self.assertEqual([float(row["load_avg"]) for row in rows], [145.375, 145.25, 145.0])
            self.assertIn("imbalance_l1=30.25", (directory / "steps.txt").read_text())

    def test_existing_csv_upgrade_preserves_input_and_blank_data(self):
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp)
            source, target = directory / "old.csv", directory / "new.csv"
            source.write_text("step,DP0_total,DP1_total,complete\n1,1,5,1\n2,2,,0\n3,0,0,1\n")
            before = source.read_bytes()
            result = subprocess.run([sys.executable, str(ROOT / "add_imbalance.py"), str(source), "-o", str(target)],
                                    capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertEqual(source.read_bytes(), before)
            rows = read_csv(target)
            self.assertEqual(list(rows[0])[-1], "imbalance_l1")
            self.assertEqual([row["imbalance_l1"] for row in rows], ["4.0", "", "0.0"])

    def test_existing_route_csv_upgrade_replaces_old_metric_columns(self):
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp)
            source, target = directory / "old_routes.csv", directory / "new_routes.csv"
            source.write_text("seq,DP0_total_before,DP1_total_before,imbalance_l1\n7,1,5,999\n")
            result = subprocess.run([sys.executable, str(ROOT / "add_imbalance.py"), str(source), "-o", str(target)],
                                    capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            rows = read_csv(target)
            self.assertEqual(list(rows[0])[-1], "imbalance_l1")
            self.assertEqual(rows[0]["imbalance_l1"], "4.0")


if __name__ == "__main__":
    unittest.main(verbosity=2)
