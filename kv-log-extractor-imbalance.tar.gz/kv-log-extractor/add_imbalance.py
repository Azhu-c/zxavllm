#!/usr/bin/env python3
"""Append imbalance metrics to an existing steps/routes CSV; preserve input."""
from __future__ import annotations

import argparse
import csv
from pathlib import Path
import re
import sys

from extract_kv_steps import IMBALANCE_FIELDS, load_imbalance


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", type=Path, help="steps.csv, all_steps.csv, routes.csv or all_routes.csv")
    parser.add_argument("-o", "--output", type=Path, help="default: INPUTNAME_imbalance.csv")
    parser.add_argument("--overwrite", action="store_true", help="replace an existing output file")
    args = parser.parse_args()
    output = args.output or args.csv.with_name(args.csv.stem + "_imbalance.csv")
    if output.resolve() == args.csv.resolve():
        parser.error("Choose a separate output path; the input CSV is never overwritten")
    if output.exists() and not args.overwrite:
        parser.error("Output exists; choose another -o path or use --overwrite")
    count, blank = 0, 0
    with args.csv.open(encoding="utf-8-sig", newline="") as source:
        reader = csv.DictReader(source)
        original_fields = reader.fieldnames or []
        candidates = {}
        for suffix in ("_total", "_total_before"):
            fields = {int(match[1]): name for name in original_fields
                      if (match := re.fullmatch(r"DP(\d+)" + suffix, name))}
            if fields:
                candidates[suffix] = fields
        if len(candidates) != 1:
            parser.error("Expected one wide-table group of DPn_total or DPn_total_before columns")
        columns = next(iter(candidates.values()))
        ranks = list(range(max(columns) + 1))
        fields = [name for name in original_fields if name not in IMBALANCE_FIELDS] + IMBALANCE_FIELDS
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("w", encoding="utf-8-sig", newline="") as target:
            writer = csv.DictWriter(target, fieldnames=fields)
            writer.writeheader()
            for row in reader:
                values = None
                try:
                    if row.get("complete", "1") != "0":
                        values = [int(row[columns[rank]].strip()) for rank in ranks]
                except (KeyError, TypeError, ValueError, AttributeError):
                    pass
                metrics = load_imbalance(values)
                row.update(metrics)
                writer.writerow(row)
                count += 1
                blank += metrics["imbalance_l1"] == ""
    print(f"输出: {output.resolve()}")
    print(f"行数: {count}；因缺失或无效负载而留空的指标行数: {blank}")
    print("最后一列 imbalance_l1 = sum(abs(rank_total - load_avg))")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
