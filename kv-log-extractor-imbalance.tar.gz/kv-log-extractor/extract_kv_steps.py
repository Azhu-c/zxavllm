#!/usr/bin/env python3
"""Extract per-step DP loads and request-routing decisions from KV-block logs.

Standard library only. Reads the input log without changing it.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from dataclasses import dataclass, field
import hashlib
import json
import math
from pathlib import Path
import re
import sys

ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
TAG = re.compile(r"\[kv_blocks_(step|route)\]")
ATTR = re.compile(r"\b(seq|wave|step)\s*=\s*(\d+)\b")
PID = re.compile(r"\bpid\s*=\s*(\d+)")
TIME = re.compile(r"\b\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d+)?")
STATE = re.compile(
    r"(?P<meta>.*?)\bDP(?P<rank>\d+)\s*\|\s*Run\((?P<nr>\d+)\)\s*:\s*"
    r"(?P<running>\[[^\]]*\])\s*\|\s*Wait\((?P<nw>\d+)\)\s*:\s*"
    r"(?P<waiting>\[[^\]]*\])\s*\|\s*total\s*=\s*(?P<total>\d+)"
    r"\s+block_size\s*=\s*(?P<block_size>\d+)"
)
HEADER = re.compile(
    r"(?P<meta>.*?)\btotals\s*=\s*(?P<totals>\[[^\]]*\])\s+"
    r"selected\s*=\s*DP(?P<selected>\d+)\s+pinned\s*=\s*(?P<pinned>True|False|true|false|0|1)"
)

# Keep the user's requested absolute-deviation sum as the final column.
IMBALANCE_FIELDS = [
    "load_avg", "imbalance_l1_normalized", "imbalance_cv",
    "imbalance_max_avg_excess", "imbalance_l1",
]


def load_imbalance(values):
    """Rank-population load dispersion; no metrics for incomplete data.

    L1 = sum(abs(Li - mean)); normalized L1 = L1 / sum(Li).
    CV uses population standard deviation (divide variance by N, not N-1).
    All-zero loads are treated as balanced: the three relative metrics are
    assigned 0 by convention, since their mathematical denominators are 0.
    """
    if not values or any(type(value) is not int or value < 0 for value in values):
        return dict.fromkeys(IMBALANCE_FIELDS, "")
    count, total = len(values), sum(values)
    if total == 0:
        return dict.fromkeys(IMBALANCE_FIELDS, 0.0)
    # Integer-centered differences avoid cancellation when the absolute
    # loads are large but their differences are small.
    centered = [count * value - total for value in values]
    absolute_sum = sum(abs(value) for value in centered)
    return dict(
        load_avg=round(total / count, 8),
        imbalance_l1_normalized=round(absolute_sum / (count * total), 8),
        imbalance_cv=round(math.sqrt(sum(value * value for value in centered) / count) / total, 8),
        imbalance_max_avg_excess=round((count * max(values) - total) / total, 8),
        imbalance_l1=round(absolute_sum / count, 8),
    )


def integers(text):
    values = json.loads(text)
    if not isinstance(values, list) or any(type(value) is not int or value < 0 for value in values):
        raise ValueError("expected a list of non-negative integers")
    return values


@dataclass
class Observation:
    run: int
    wave: int | None
    step: int | None
    rank: int
    total: int
    running_count: int
    waiting_count: int
    running_total: int
    waiting_total: int
    block_size: int
    signature: str
    valid: bool
    source_line: int
    timestamp: str
    pid: str


@dataclass
class Route:
    run: int
    seq: int
    selected: int
    pinned: bool
    totals: list[int]
    source_line: int
    timestamp: str
    pid: str
    context: dict[int, Observation]
    explicit_wave: int | None = None
    explicit_step: int | None = None
    details: dict[int, Observation] = field(default_factory=dict)
    duplicate_headers: int = 0
    wave: int | None = None
    step: int | None = None
    association: str = "unmatched_no_prior_step"
    snapshot_match: str = "not_available"


class Extractor:
    def __init__(self, ranks=None, max_context_lines=1000):
        self.requested_ranks = ranks
        self.max_context_lines = max_context_lines
        self.active_run = 1
        self.engine_pid_runs = {}
        self.current_rank_pids = {}
        self.api_pid_runs = {}
        self.active_api_pid = None
        self.latest = defaultdict(dict)
        self.steps = {}
        self.observations = []
        self.observation_counts = Counter()
        self.conflicts = set()
        self.routes = []
        self.route_index = {}
        self.issues = []
        self.rank_count = ranks or 0
        self.lines_read = 0

    def issue(self, line, kind, message):
        self.issues.append(dict(source_line=line, kind=kind, message=message))

    def state_run(self, rank, pid):
        if not pid:
            return self.active_run
        if pid in self.engine_pid_runs:
            return self.engine_pid_runs[pid]
        if rank in self.current_rank_pids and self.current_rank_pids[rank] != pid:
            self.active_run += 1
            self.current_rank_pids.clear()
            self.active_api_pid = None
        self.current_rank_pids[rank] = pid
        self.engine_pid_runs[pid] = self.active_run
        return self.active_run

    def api_run(self, pid):
        if not pid:
            return self.active_run
        if pid in self.api_pid_runs:
            return self.api_pid_runs[pid]
        if self.active_api_pid is not None and pid != self.active_api_pid:
            self.active_run += 1
            self.current_rank_pids.clear()
        self.active_api_pid = pid
        self.api_pid_runs[pid] = self.active_run
        return self.active_run

    def parse_state(self, match, run, line, timestamp, pid, attrs):
        running = integers(match["running"])
        waiting = integers(match["waiting"])
        rank, total = int(match["rank"]), int(match["total"])
        nr, nw, block_size = int(match["nr"]), int(match["nw"]), int(match["block_size"])
        valid = nr == len(running) and nw == len(waiting) and total == sum(running) + sum(waiting) and block_size > 0
        if not valid:
            self.issue(line, "invalid_state", "Run/Wait counts, array sum, total or block_size disagree; printed total retained")
        self.rank_count = max(self.rank_count, rank + 1)
        signature = hashlib.sha256(json.dumps([running, waiting, block_size], separators=(",", ":")).encode()).hexdigest()
        return Observation(run, attrs.get("wave"), attrs.get("step"), rank, total, nr, nw,
                           sum(running), sum(waiting), block_size, signature, valid, line, timestamp, pid)

    def route_key(self, run, pid, seq):
        key = (run, pid, seq)
        if key in self.route_index or pid:
            return key
        candidates = [key for key in self.route_index if key[0] == run and key[2] == seq]
        return candidates[0] if len(candidates) == 1 else key

    def feed(self, raw, line):
        self.lines_read = line
        text = ANSI.sub("", raw)
        tags = list(TAG.finditer(text))
        for index, tag in enumerate(tags):
            prefix = text[tags[index - 1].end() if index else 0:tag.start()]
            pids, timestamps = PID.findall(prefix), TIME.findall(prefix)
            pid, timestamp = (pids[-1] if pids else ""), (timestamps[-1] if timestamps else "")
            end = tags[index + 1].start() if index + 1 < len(tags) else len(text)
            body = text[tag.end():end].strip()
            try:
                if tag[1] == "route" and (head := HEADER.search(body)):
                    attrs = {name: int(value) for name, value in ATTR.findall(head["meta"])}
                    if "seq" not in attrs:
                        raise ValueError("route header has no seq")
                    totals = integers(head["totals"])
                    if not totals:
                        raise ValueError("empty route totals")
                    run = self.api_run(pid)
                    selected = int(head["selected"])
                    pinned = head["pinned"].lower() in ("true", "1")
                    key = (run, pid, attrs["seq"])
                    old = self.route_index.get(key)
                    if old and (old.selected, old.pinned, old.totals) == (selected, pinned, totals):
                        old.duplicate_headers += 1
                        continue
                    if old:
                        self.issue(line, "repeated_seq", "Same API PID/run/seq has different route headers; both retained")
                    route = Route(run, attrs["seq"], selected, pinned, totals, line, timestamp, pid,
                                  dict(self.latest[run]), attrs.get("wave"), attrs.get("step"))
                    self.routes.append(route)
                    self.route_index[key] = route
                    self.rank_count = max(self.rank_count, len(totals), selected + 1)
                    if selected >= len(totals):
                        self.issue(line, "invalid_selected_rank", "Selected rank is outside the totals array")
                    elif not pinned and totals[selected] != min(totals):
                        self.issue(line, "selection_not_minimum", "Unpinned selected rank does not have the minimum printed total")
                    continue
                state = STATE.search(body)
                if not state:
                    raise ValueError("unrecognized or incomplete KV log record")
                attrs = {name: int(value) for name, value in ATTR.findall(state["meta"])}
                if tag[1] == "step":
                    if "wave" not in attrs or "step" not in attrs:
                        raise ValueError("step record has no wave/step")
                    run = self.state_run(int(state["rank"]), pid)
                    observation = self.parse_state(state, run, line, timestamp, pid, attrs)
                    key = (run, observation.wave, observation.step, observation.rank)
                    old = self.steps.get(key)
                    if old and (old.signature, old.total) != (observation.signature, observation.total):
                        self.conflicts.add(key)
                        self.issue(line, "step_state_changed", "Same rank/wave/step has multiple states; wide table uses last observation")
                    self.steps[key] = observation
                    self.observation_counts[key] += 1
                    self.observations.append(observation)
                    # Do not move context backwards if an older record arrives later.
                    latest = self.latest[run].get(observation.rank)
                    if latest is None or (observation.wave, observation.step) >= (latest.wave, latest.step):
                        self.latest[run][observation.rank] = observation
                else:
                    if "seq" not in attrs:
                        raise ValueError("route detail has no seq")
                    run = self.api_run(pid)
                    route = self.route_index.get(self.route_key(run, pid, attrs["seq"]))
                    if route is None:
                        self.issue(line, "orphan_route_detail", "No matching preceding route header")
                        continue
                    observation = self.parse_state(state, run, line, timestamp, pid, attrs)
                    route.details[observation.rank] = observation
                    if observation.rank < len(route.totals) and observation.total != route.totals[observation.rank]:
                        self.issue(line, "route_total_disagrees", "Route detail total differs from route header")
            except (ValueError, TypeError, KeyError, json.JSONDecodeError) as error:
                self.issue(line, "parse_error", str(error))

    def finish(self):
        if self.requested_ranks and self.rank_count > self.requested_ranks:
            self.issue(0, "rank_count_exceeded", "Observed more ranks than --ranks; all observed ranks retained")
        for route in self.routes:
            context = route.context.get(route.selected)
            detail = route.details.get(route.selected)
            if context and detail:
                route.snapshot_match = "equal" if context.valid and detail.valid and context.signature == detail.signature else "different"
            if route.explicit_wave is not None and route.explicit_step is not None:
                route.wave, route.step = route.explicit_wave, route.explicit_step
                route.association = "explicit_header"
            elif context is None:
                route.association = "unmatched_no_prior_step"
            elif self.max_context_lines and route.source_line - context.source_line > self.max_context_lines:
                route.association = "unmatched_context_too_old"
            elif route.snapshot_match == "different":
                route.association = "unmatched_snapshot_differs"
            else:
                route.wave, route.step = context.wave, context.step
                contexts = [route.context.get(rank) for rank in range(len(route.totals))]
                same_step = all(item and (item.wave, item.step) == (context.wave, context.step) for item in contexts)
                route.association = "context_all_ranks_same_step" if same_step else "context_selected_rank"
        return self


def write_csv(path, fields, rows):
    # UTF-8 BOM makes Chinese Windows/Excel viewers recognize the encoding.
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def export(extractor, directory, input_path):
    ranks = list(range(extractor.rank_count))
    grouped_routes = defaultdict(list)
    for route in extractor.routes:
        if route.wave is not None and route.step is not None:
            grouped_routes[(route.run, route.wave, route.step)].append(route)
    step_keys = sorted({key[:3] for key in extractor.steps} | set(grouped_routes))
    step_rows = []
    for run, wave, step in step_keys:
        states = {rank: extractor.steps.get((run, wave, step, rank)) for rank in ranks}
        routes = grouped_routes[(run, wave, step)]
        present = [rank for rank, state in states.items() if state is not None]
        missing = [rank for rank in ranks if rank not in present]
        row = dict(run=run, wave=wave, step=step,
                   dispatch_count=len(routes), dispatches="; ".join(f"seq={route.seq}->DP{route.selected}" for route in routes),
                   complete=int(not missing), missing_ranks=";".join(f"DP{rank}" for rank in missing),
                   association_methods=";".join(sorted({route.association for route in routes})),
                   changed_rank_states=";".join(f"DP{rank}" for rank in ranks if (run, wave, step, rank) in extractor.conflicts))
        row.update({f"DP{rank}_total": states[rank].total if states[rank] is not None else "" for rank in ranks})
        row.update(load_imbalance([states[rank].total for rank in ranks] if not missing else None))
        step_rows.append(row)
    step_fields = ["run", "wave", "step", *[f"DP{rank}_total" for rank in ranks], "dispatch_count", "dispatches",
                   "association_methods", "complete", "missing_ranks", "changed_rank_states", *IMBALANCE_FIELDS]
    write_csv(directory / "steps.csv", step_fields, step_rows)

    route_rows = []
    for route in extractor.routes:
        context = route.context.get(route.selected)
        selected_total = route.totals[route.selected] if route.selected < len(route.totals) else ""
        row = dict(run=route.run, seq=route.seq, wave=route.wave, step=route.step,
                   selected=f"DP{route.selected}", pinned=route.pinned, selected_total=selected_total,
                   minimum_total=min(route.totals), selected_is_minimum=int(selected_total == min(route.totals)),
                   association=route.association, selected_snapshot_match=route.snapshot_match,
                   candidate_wave=context.wave if context else None, candidate_step=context.step if context else None,
                   context_line=context.source_line if context else None,
                   context_gap_lines=route.source_line - context.source_line if context else None,
                   source_line=route.source_line, timestamp=route.timestamp, api_pid=route.pid,
                   duplicate_headers=route.duplicate_headers)
        row.update({f"DP{rank}_total_before": route.totals[rank] if rank < len(route.totals) else "" for rank in ranks})
        row.update(load_imbalance(route.totals if len(route.totals) == len(ranks) else None))
        route_rows.append(row)
    route_fields = ["run", "seq", "wave", "step", "selected", "pinned", "selected_total", "minimum_total", "selected_is_minimum",
                    *[f"DP{rank}_total_before" for rank in ranks], "association", "selected_snapshot_match", "candidate_wave", "candidate_step",
                    "context_line", "context_gap_lines", "source_line", "timestamp", "api_pid", "duplicate_headers", *IMBALANCE_FIELDS]
    write_csv(directory / "routes.csv", route_fields, route_rows)

    long_fields = ["run", "wave", "step", "rank", "total", "running_count", "waiting_count", "running_total", "waiting_total",
                   "block_size", "valid", "source_line", "timestamp", "pid"]
    long_rows = ({key: getattr(state, key) for key in long_fields} for state in extractor.observations)
    write_csv(directory / "rank_steps.csv", long_fields, long_rows)
    write_csv(directory / "issues.csv", ["source_line", "kind", "message"], extractor.issues)
    methods = Counter(route.association for route in extractor.routes)
    summary = dict(input=str(input_path.resolve()), lines_read=extractor.lines_read, ranks=extractor.rank_count,
                   runs=len({key[0] for key in step_keys} | {route.run for route in extractor.routes}),
                   step_rows=len(step_rows), step_observations=len(extractor.observations), route_decisions=len(extractor.routes),
                   associated_routes=sum(route.wave is not None and route.step is not None for route in extractor.routes),
                   unmatched_routes=sum(route.wave is None or route.step is None for route in extractor.routes),
                   association_counts=dict(methods), incomplete_steps=sum(not row["complete"] for row in step_rows),
                   changed_step_rank_cells=len(extractor.conflicts), issues=len(extractor.issues),
                   imbalance_columns=IMBALANCE_FIELDS,
                   imbalance_definition="L1=sum|Li-avg|; normalized_L1=L1/sum(Li); population_CV=std_population/avg; max_avg_excess=max(Li)/avg-1; relative metrics are 0 by convention for all-zero loads; incomplete-rank rows are blank.",
                   note="Step totals are directly parsed. Routes without wave/step use the preceding selected-rank step context; this is not an exact event-step timestamp.")
    (directory / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (directory / "steps.txt").open("w", encoding="utf-8") as handle:
        handle.write("分发目标直接取 selected；未显式记录 step 的分发按相邻日志关联，关联方式见 routes.csv。\n")
        for row in step_rows:
            totals = " ".join(f"DP{rank}={row[f'DP{rank}_total'] if row[f'DP{rank}_total'] != '' else 'NA'}" for rank in ranks)
            dispatches = row["dispatches"] or "日志中无关联分发记录"
            metrics = " ".join(f"{name}={row[name] if row[name] != '' else 'NA'}" for name in IMBALANCE_FIELDS)
            handle.write(f"run={row['run']} wave={row['wave']} step={row['step']} | {totals} | {dispatches} | {metrics}\n")
        if summary["unmatched_routes"]:
            handle.write(f"另有 {summary['unmatched_routes']} 条分发未关联 step，仍完整保存在 routes.csv。\n")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("log", type=Path, help="Decode log file")
    parser.add_argument("-o", "--outdir", type=Path, help="output directory; default: LOGNAME_extracted")
    parser.add_argument("--ranks", type=int, help="expected DP rank count; e.g. 8 (otherwise inferred)")
    parser.add_argument("--max-context-lines", type=int, default=1000, help="maximum line distance for contextual route-step association; 0 means unlimited")
    parser.add_argument("--overwrite", action="store_true", help="replace the six generated output files if already present")
    args = parser.parse_args()
    if args.ranks is not None and args.ranks < 1:
        parser.error("--ranks must be positive")
    if args.max_context_lines < 0:
        parser.error("--max-context-lines must be non-negative")
    directory = args.outdir or args.log.with_name(args.log.stem + "_extracted")
    names = ("steps.csv", "routes.csv", "rank_steps.csv", "issues.csv", "summary.json", "steps.txt")
    if not args.overwrite and any((directory / name).exists() for name in names):
        parser.error("Output files already exist; select another -o directory or use --overwrite")
    extractor = Extractor(args.ranks, args.max_context_lines)
    with args.log.open("r", encoding="utf-8-sig", errors="replace") as handle:
        for line, raw in enumerate(handle, 1):
            extractor.feed(raw, line)
    extractor.finish()
    if not extractor.observations and not extractor.routes:
        parser.error("No [kv_blocks_step] or [kv_blocks_route] records found")
    directory.mkdir(parents=True, exist_ok=True)
    summary = export(extractor, directory, args.log)
    print(f"输出目录: {directory.resolve()}")
    print(f"step: {summary['step_rows']}；rank-step观察: {summary['step_observations']}；分发: {summary['route_decisions']}")
    print(f"已关联step的分发: {summary['associated_routes']}；未关联: {summary['unmatched_routes']}；不完整step: {summary['incomplete_steps']}")
    print("优先查看 steps.csv 或 steps.txt；逐次分发见 routes.csv。")
    if summary["issues"]:
        print(f"有 {summary['issues']} 条解析/一致性提示，见 issues.csv。")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
