/* Copyright 2026 The xLLM Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://github.com/xLLM-AI/xllm/blob/main/LICENSE

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#pragma once

#include <cstdint>
#include <optional>
#include <string>

namespace xllm::triton_jit {

// Kernel launch grid (number of blocks in each dimension).
struct Grid {
  uint32_t x = 1;
  uint32_t y = 1;
  uint32_t z = 1;
};

// Triton compile / launch meta-parameters.
struct LaunchCfg {
  int32_t num_warps = 1;
  int32_t num_stages = 1;
  std::string bottleneck = "";
  std::optional<bool> enable_fp_fusion;
  std::optional<bool> enable_soft_i64;
  std::optional<bool> force_use_shared_memory;
};

}  // namespace xllm::triton_jit
