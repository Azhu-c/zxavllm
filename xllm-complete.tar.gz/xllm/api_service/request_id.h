/* Copyright 2026 The xLLM Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://github.com/xLLM-AI/xllm/blob/main/LICENSE

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#pragma once

#include <brpc/controller.h>

#include <string>
#include <string_view>

namespace xllm::api_service {

bool is_valid_x_request_id(std::string_view x_request_id);

std::string get_header_x_request_id(const brpc::Controller* controller);

std::string generate_x_request_id();

std::string resolve_x_request_id(
    const brpc::Controller* controller,
    std::string_view body_x_request_id = std::string_view{});

std::string ensure_http_x_request_id(brpc::Controller* controller);

}  // namespace xllm::api_service
