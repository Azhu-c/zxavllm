/* Copyright 2025-2026 The xLLM Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://github.com/xLLM-AI/xllm/blob/main/LICENSE

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#pragma once

#include <cstdint>
#include <limits>
#include <memory>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "butil/base64.h"
#include "common.pb.h"
#include "core/common/message.h"
#include "core/common/types.h"
#include "multimodal.pb.h"

namespace xllm {
namespace mm_service_utils {

template <typename Outputs, typename GetMedia>
bool reserve_binary_payload(const Outputs& outputs,
                            GetMedia get_media,
                            std::string& binary_payload) {
  size_t total_bytes = 0;
  for (const auto& output : outputs) {
    const std::string_view media = get_media(output);
    if (media.size() > std::numeric_limits<size_t>::max() - total_bytes) {
      return false;
    }
    total_bytes += media.size();
  }
  binary_payload.reserve(total_bytes);
  return true;
}

inline void append_binary_payload(std::string_view data,
                                  proto::BinaryRef& binary_ref,
                                  std::string& binary_payload) {
  binary_ref.set_offset(static_cast<uint64_t>(binary_payload.size()));
  binary_ref.set_length(static_cast<uint64_t>(data.size()));
  binary_payload.append(data.data(), data.size());
}

inline void fill_media_source(std::string_view data,
                              std::string_view name,
                              bool use_binary,
                              proto::MediaSource& source,
                              std::string& binary_payload) {
  source.set_name(name.data(), name.size());
  source.set_modality(name.data(), name.size());
  if (use_binary) {
    source.set_type("binary");
    source.clear_base64();
    append_binary_payload(data, *source.mutable_binary(), binary_payload);
    return;
  }
  source.set_type("base64");
  source.clear_binary();
  butil::Base64Encode(butil::StringPiece(data.data(), data.size()),
                      source.mutable_base64());
}

template <typename Response>
auto* initialize_generation_response(Response& response,
                                     const std::string& request_id,
                                     int64_t created_time,
                                     const std::string& model) {
  response.set_object("list");
  response.set_id(request_id);
  response.set_created(created_time);
  response.set_model(model);
  return response.mutable_output();
}

template <typename Call>
bool build_messages(const google::protobuf::RepeatedPtrField<
                        xllm::proto::MMChatMessage>& req_messages,
                    std::vector<Message>& out_messages,
                    std::shared_ptr<Call> call,
                    int image_limit) {
  out_messages.clear();
  out_messages.reserve(req_messages.size());

  for (const auto& req_message : req_messages) {
    MMContentVec contents;

    contents.reserve(req_message.content_size());
    for (const auto& item : req_message.content()) {
      if (item.type() == "text") {
        contents.emplace_back(item.type(), item.text());

      } else if (item.type() == "image_url") {
        ImageURL image_url;
        image_url.url = item.image_url().url();
        for (const auto& [k, v] : item.image_url().headers()) {
          image_url.headers[k] = v;
        }
        contents.emplace_back(item.type(), std::move(image_url));

      } else if (item.type() == "video_url") {
        VideoURL video_url;
        video_url.url = item.video_url().url();
        for (const auto& [k, v] : item.video_url().headers()) {
          video_url.headers[k] = v;
        }
        contents.emplace_back(item.type(), std::move(video_url));

      } else if (item.type() == "audio_url") {
        AudioURL audio_url;
        audio_url.url = item.audio_url().url();
        for (const auto& [k, v] : item.audio_url().headers()) {
          audio_url.headers[k] = v;
        }
        contents.emplace_back(item.type(), std::move(audio_url));
      } else if (item.type() == "image_embedding") {
        contents.emplace_back("image_embedding", item.image_embedding());
      } else if (item.type() == "video_embedding") {
        contents.emplace_back("video_embedding", item.video_embedding());
      } else if (item.type() == "audio_embedding") {
        contents.emplace_back("audio_embedding", item.audio_embedding());
      } else {
        call->finish_with_error(StatusCode::INVALID_ARGUMENT,
                                "message content type is invalid.");
        return false;
      }
    }

    out_messages.emplace_back(req_message.role(), std::move(contents));
    auto& msg = out_messages.back();

    if (req_message.has_tool_call_id()) {
      msg.tool_call_id = req_message.tool_call_id();
    }

    if (req_message.tool_calls_size() > 0) {
      Message::ToolCallVec tool_calls;
      tool_calls.reserve(req_message.tool_calls_size());
      for (const auto& tool_call : req_message.tool_calls()) {
        tool_calls.emplace_back();
        auto& tc = tool_calls.back();
        if (tool_call.has_id()) {
          tc.id = tool_call.id();
        }
        tc.type = tool_call.type();
        tc.function.name = tool_call.function().name();
        tc.function.arguments = tool_call.function().arguments();
      }
      msg.tool_calls = std::move(tool_calls);
    }
  }

  for (auto& msg : out_messages) {
    if (msg.calc_count("image_url") > image_limit) {
      call->finish_with_error(StatusCode::INVALID_ARGUMENT,
                              "Number of images in a single message exceeds "
                              "the allowed image limit.");
      return false;
    }
  }

  return true;
};

}  // namespace mm_service_utils
}  // namespace xllm
