/* Copyright 2025-2026 The xLLM Authors.
Copyright 2024 The ScaleLLM Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://github.com/xLLM-AI/xllm/blob/main/LICENSE

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#pragma once
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <string_view>
#include <unordered_map>

#include "core/framework/model/causal_lm.h"
#include "core/framework/model/causal_rec.h"
#include "core/framework/model/causal_vlm.h"
#include "core/framework/model/dit_model.h"
#include "core/framework/model/generic_rec.h"
#include "core/framework/model/rec_model.h"
#include "core/framework/model_context/dit_model_context.h"
#include "core/framework/model_context/model_context.h"
#include "core/framework/tokenizer/tokenizer_args.h"
#include "core/util/json_reader.h"
#include "core/util/type_traits.h"  // IWYU pragma: keep
#include "processors/multimodal_processor.h"

namespace xllm {

class Options;

using CausalLMFactory =
    std::function<std::unique_ptr<CausalLM>(const ModelContext& context)>;

using RecModelFactory =
    std::function<std::unique_ptr<RecModel>(const ModelContext& context)>;

using CausalVLMFactory =
    std::function<std::unique_ptr<CausalVLM>(const ModelContext& context)>;

using DiTModelFactory =
    std::function<std::unique_ptr<DiTModel>(const DiTModelContext& context)>;

using MultimodalProcessorFactory =
    std::function<std::unique_ptr<MultimodalProcessorBase>(
        const ModelArgs& model_args,
        std::shared_ptr<Tokenizer> tokenizer,
        const TokenizerArgs& tokenizer_args)>;

using ModelArgsLoader =
    std::function<bool(const JsonReader& json, ModelArgs* args)>;

using QuantArgsLoader =
    std::function<bool(const JsonReader& json, QuantArgs* args)>;

using TokenizerArgsLoader =
    std::function<bool(const JsonReader& json, TokenizerArgs* args)>;

struct CausalLMRegistration {
  CausalLMFactory factory;
  int32_t priority = 0;
};

struct CausalVLMRegistration {
  CausalVLMFactory factory;
  int32_t priority = 0;
};

// Model-advertised CP mode: NONE or MODEL (shard after embed / merge before
// LM head). Backend capability queries decide the concrete model data path.
enum class CpShardingMode : int8_t {
  NONE = 0,
  MODEL = 1,
};

// Rewrites a target model's args into the registered MTP draft form. The
// registry owns dispatch so engines never name a concrete MTP model.
using MtpArgsAdapter =
    std::function<void(ModelArgs& args, bool is_python_model)>;

struct MtpModelCapabilities {
  bool native_draft_requires_accepted_span_replay = false;
  bool native_draft_owns_embedding_and_lm_head = false;
  bool python_draft_owns_embedding_and_lm_head = false;
};

// TODO: add default args loader.
struct ModelMeta {
  std::unordered_map<std::string, CausalLMRegistration> causal_lm_factories;
  RecModelFactory rec_model_factory;
  std::unordered_map<std::string, CausalVLMRegistration> causal_vlm_factories;
  DiTModelFactory dit_model_factory;
  MultimodalProcessorFactory multimodal_processor_factory;
  ModelArgsLoader model_args_loader;
  QuantArgsLoader quant_args_loader;
  TokenizerArgsLoader tokenizer_args_loader;
  CpShardingMode cp_sharding_mode = CpShardingMode::NONE;
  bool supports_dcp = false;
  MtpModelCapabilities mtp_capabilities;
  MtpArgsAdapter mtp_args_adapter;
};

// Model config names may be aliases, but registry lookups use one canonical
// key across backend, args-loader, and multimodal registrations.
inline std::string canonical_model_registration_name(
    std::string_view model_type) {
  if (model_type == "glm5_3_flash") {
    return "glm5_next";
  }
  return std::string(model_type);
}

// Model registry is a singleton class that registers all models with the
// ModelFactory, ModelArgParser to facilitate model loading.
class ModelRegistry {
 public:
  static ModelRegistry* get_instance();

  static void register_causallm_factory(const std::string& name,
                                        CausalLMFactory factory);

  static bool register_causallm_factory(std::string name,
                                        CausalLMFactory factory,
                                        int32_t priority);

  static bool register_causallm_factory(std::string name,
                                        std::string implementation,
                                        CausalLMFactory factory,
                                        int32_t priority = 0);

  static void register_rec_model_factory(const std::string& name,
                                         RecModelFactory factory);

  static void register_causalvlm_factory(const std::string& name,
                                         CausalVLMFactory factory);

  static bool register_causalvlm_factory(std::string name,
                                         CausalVLMFactory factory,
                                         int32_t priority);

  static bool register_causalvlm_factory(std::string name,
                                         std::string implementation,
                                         CausalVLMFactory factory,
                                         int32_t priority = 0);

  static void register_dit_model_factory(const std::string& name,
                                         DiTModelFactory factory);

  static void register_model_backend(const std::string& name,
                                     const std::string& backend);

  static void register_model_args_loader(const std::string& name,
                                         ModelArgsLoader loader);

  static void register_quant_args_loader(const std::string& name,
                                         QuantArgsLoader loader);

  static void register_tokenizer_args_loader(const std::string& name,
                                             TokenizerArgsLoader loader);

  static void register_multimodal_processor_factory(
      const std::string& name,
      MultimodalProcessorFactory factory);

  // Register the model-side CP sharding mode advertised by `name`. Defaults to
  // NONE for any unregistered model.
  static void register_cp_sharding_mode(const std::string& name,
                                        CpShardingMode mode);

  // Read-only query of the registered CP sharding mode. Returns NONE when
  // `name` is unknown or the model did not opt into model-side CP.
  static CpShardingMode get_cp_sharding_mode(const std::string& name);

  static void register_dcp_capability(const std::string& name);
  static bool supports_dcp(const std::string& name);

  static void register_mtp_shared_weight_owner(const std::string& name);

  static void register_mtp_args_adapter(const std::string& name,
                                        MtpArgsAdapter adapter);

  static void register_mtp_capabilities(const std::string& name,
                                        MtpModelCapabilities capabilities);

  static MtpModelCapabilities get_mtp_capabilities(const std::string& name);

  static void configure_mtp_args(ModelArgs& args,
                                 std::string_view algorithm,
                                 bool is_draft_engine,
                                 bool is_python_model);

  static CausalLMFactory get_causallm_factory(const std::string& name);

  static CausalLMFactory get_causallm_factory(
      const std::string& name,
      const std::string& implementation);

  static RecModelFactory get_rec_model_factory(const std::string& name);

  static CausalVLMFactory get_causalvlm_factory(const std::string& name);

  static CausalVLMFactory get_causalvlm_factory(
      const std::string& name,
      const std::string& implementation);

  static DiTModelFactory get_dit_model_factory(const std::string& name);

  static ModelArgsLoader get_model_args_loader(const std::string& name);

  static QuantArgsLoader get_quant_args_loader(const std::string& name);

  static TokenizerArgsLoader get_tokenizer_args_loader(const std::string& name);

  static MultimodalProcessorFactory get_multimodal_processor_factory(
      const std::string& name);

  static bool has_dit_model_factory(const std::string& name);

  static std::string get_model_backend(const std::string& name);

 private:
  std::unordered_map<std::string, ModelMeta> model_registry_;
  std::unordered_map<std::string, std::string> model_backend_;
};

bool resolve_model_registration_name(const std::string& model_type,
                                     std::string* resolved_name,
                                     std::string* error_message = nullptr);

// Lazily register the NPU ATB model-side CP pipeline capability for the four
// supported models (deepseek_v32, deepseek_v32_mtp, glm_moe_dsa,
// glm_moe_dsa_mtp) and return whether `resolved_name` is CP-capable.
// Idempotent. `resolved_name` must already be backend-resolved (see
// resolve_model_registration) so qwen3_atb etc. are not misclassified.
bool is_npu_model_cp_capable(const std::string& resolved_name);

// Native DCP capability is distinct from prefill CP sharding capability.
bool is_npu_model_dcp_capable(const std::string& resolved_name);

int64_t get_npu_linear_state_cache_block_limit(const std::string& model_type);

bool is_mlu_model_cp_capable(const std::string& resolved_name);

bool resolve_model_registration(const std::string& model_type,
                                const std::string& requested_npu_kernel_backend,
                                std::string* effective_npu_kernel_backend,
                                std::string* resolved_name,
                                std::string* error_message = nullptr);

// Resolve a selected model extension before applying built-in backend rules.
// model_component is "causal_lm" or "causal_vlm". Registered model extensions
// use TORCH for AUTO and honor explicit ATB/TORCH/XLITE; XLITE still requires a
// build with USE_XLITE. Families without that component retain built-in rules.
bool resolve_model_registration(const std::string& model_type,
                                const std::string& requested_npu_kernel_backend,
                                const std::string& extension_impl,
                                std::string_view model_component,
                                std::string* effective_npu_kernel_backend,
                                std::string* resolved_name,
                                std::string* error_message = nullptr);

#if defined(USE_NPU)
// Resolve the model-specific NPU kernel backend before constructing a runtime
// engine. This applies only to the LLM/VLM/Rec model registry; DiT has its own
// model registry and backend selection. LLM/VLM pass their model component to
// apply Options::extension_impl before built-in backend validation.
void resolve_npu_kernel_backend(Options* options,
                                std::string_view model_component = "");
#endif

std::unique_ptr<CausalLM> create_llm_model(const ModelContext& context);

std::unique_ptr<RecModel> create_rec_model(const ModelContext& context);

std::unique_ptr<CausalVLM> create_vlm_model(const ModelContext& context);

std::unique_ptr<DiTModel> create_dit_model(const DiTModelContext& context);

// Macro to register a model with the ModelRegistry
#define REGISTER_CAUSAL_MODEL_WITH_VARNAME(                        \
    VarName, ModelType, ModelClass, ...)                           \
  const bool VarName##_registered = []() {                         \
    ::xllm::ModelRegistry::register_causallm_factory(              \
        #ModelType, [](const ::xllm::ModelContext& context) {      \
          ModelClass model(context);                               \
          model->eval();                                           \
          return std::make_unique<xllm::CausalLMImpl<ModelClass>>( \
              std::move(model), context.get_tensor_options());     \
        } __VA_OPT__(, ) __VA_ARGS__);                             \
    return true;                                                   \
  }()

#define REGISTER_CAUSAL_MODEL(ModelType, ModelClass, ...) \
  REGISTER_CAUSAL_MODEL_WITH_VARNAME(                     \
      ModelType, ModelType, ModelClass __VA_OPT__(, ) __VA_ARGS__)

// Register a CausalLM subclass directly. Higher priorities replace lower
// priorities for the same model and implementation; ties keep the first.
#define CONCAT_MODEL_REGISTRATION_IMPL(left, right) left##right
#define CONCAT_MODEL_REGISTRATION(left, right) \
  CONCAT_MODEL_REGISTRATION_IMPL(left, right)

#define REGISTER_CAUSAL_LM_WITH_VARNAME(                                 \
    VarName, ModelType, Implementation, ModelClass, ...)                 \
  namespace {                                                            \
  const bool CONCAT_MODEL_REGISTRATION(VarName, _causal_lm_registered) = \
      ::xllm::ModelRegistry::register_causallm_factory(                  \
          #ModelType,                                                    \
          Implementation,                                                \
          [](const ::xllm::ModelContext& context) {                      \
            auto model = std::make_unique<ModelClass>(context);          \
            model->eval();                                               \
            return model;                                                \
          } __VA_OPT__(, ) __VA_ARGS__);                                 \
  }

#define REGISTER_CAUSAL_LM(ModelType, Implementation, ModelClass, ...)      \
  REGISTER_CAUSAL_LM_WITH_VARNAME(                                          \
      CONCAT_MODEL_REGISTRATION(xllm_causal_lm_registration_, __COUNTER__), \
      ModelType,                                                            \
      Implementation,                                                       \
      ModelClass __VA_OPT__(, ) __VA_ARGS__)

#define REGISTER_CAUSAL_REC_MODEL_WITH_VARNAME(VarName, ModelType, ModelClass) \
  const bool VarName##_causal_rec_registered = []() {                          \
    ModelRegistry::register_rec_model_factory(                                 \
        #ModelType, [](const ModelContext& context) {                          \
          ModelClass model(context);                                           \
          model->eval();                                                       \
          return std::make_unique<xllm::CausalRecImpl<ModelClass>>(            \
              std::move(model), context.get_tensor_options());                 \
        });                                                                    \
    return true;                                                               \
  }()

#define REGISTER_CAUSAL_REC_MODEL(ModelType, ModelClass) \
  REGISTER_CAUSAL_REC_MODEL_WITH_VARNAME(ModelType, ModelType, ModelClass)

#define REGISTER_GENERIC_REC_MODEL_WITH_VARNAME(                     \
    VarName, ModelType, ModelClass)                                  \
  const bool VarName##_generic_rec_registered = []() {               \
    ModelRegistry::register_rec_model_factory(                       \
        #ModelType, [](const ModelContext& context) {                \
          ModelClass model(context);                                 \
          model->eval();                                             \
          return std::make_unique<xllm::GenericRecImpl<ModelClass>>( \
              std::move(model), context.get_tensor_options());       \
        });                                                          \
    return true;                                                     \
  }()

#define REGISTER_GENERIC_REC_MODEL(ModelType, ModelClass) \
  REGISTER_GENERIC_REC_MODEL_WITH_VARNAME(ModelType, ModelType, ModelClass)

#define REGISTER_CAUSAL_VLM_MODEL_WITH_VARNAME(                     \
    VarName, ModelType, ModelClass, ...)                            \
  const bool VarName##_registered = []() {                          \
    ::xllm::ModelRegistry::register_causalvlm_factory(              \
        #ModelType, [](const ::xllm::ModelContext& context) {       \
          ModelClass model(context);                                \
          model->eval();                                            \
          return std::make_unique<xllm::CausalVLMImpl<ModelClass>>( \
              std::move(model), context.get_tensor_options());      \
        } __VA_OPT__(, ) __VA_ARGS__);                              \
    return true;                                                    \
  }()

#define REGISTER_CAUSAL_VLM_MODEL(ModelType, ModelClass, ...) \
  REGISTER_CAUSAL_VLM_MODEL_WITH_VARNAME(                     \
      ModelType, ModelType, ModelClass __VA_OPT__(, ) __VA_ARGS__)

#define REGISTER_CAUSAL_VLM_WITH_VARNAME(                                 \
    VarName, ModelType, Implementation, ModelClass, ...)                  \
  namespace {                                                             \
  const bool CONCAT_MODEL_REGISTRATION(VarName, _causal_vlm_registered) = \
      ::xllm::ModelRegistry::register_causalvlm_factory(                  \
          #ModelType,                                                     \
          Implementation,                                                 \
          [](const ::xllm::ModelContext& context) {                       \
            auto model = std::make_unique<ModelClass>(context);           \
            model->eval();                                                \
            return model;                                                 \
          } __VA_OPT__(, ) __VA_ARGS__);                                  \
  }

#define REGISTER_CAUSAL_VLM(ModelType, Implementation, ModelClass, ...)      \
  REGISTER_CAUSAL_VLM_WITH_VARNAME(                                          \
      CONCAT_MODEL_REGISTRATION(xllm_causal_vlm_registration_, __COUNTER__), \
      ModelType,                                                             \
      Implementation,                                                        \
      ModelClass __VA_OPT__(, ) __VA_ARGS__)

#define REGISTER_DIT_MODEL_WITH_VARNAME(VarName, ModelType, ModelClass) \
  const bool VarName##_registered = []() {                              \
    ModelRegistry::register_dit_model_factory(                          \
        #ModelType, [](const DiTModelContext& context) {                \
          ModelClass model(context);                                    \
          model->eval();                                                \
          return std::make_unique<xllm::DiTModelImpl<ModelClass>>(      \
              std::move(model), context.get_tensor_options());          \
        });                                                             \
    return true;                                                        \
  }()

#define REGISTER_DIT_MODEL(ModelType, ModelClass) \
  REGISTER_DIT_MODEL_WITH_VARNAME(ModelType, ModelType, ModelClass)

#define REGISTER_MODEL_BACKEND_WITH_VARNAME(VarName, ModelType, Backend) \
  const bool VarName##_backend_registered = []() {                       \
    ModelRegistry::register_model_backend(#ModelType, Backend);          \
    return true;                                                         \
  }()

#define REGISTER_MODEL_BACKEND(ModelType, Backend) \
  REGISTER_MODEL_BACKEND_WITH_VARNAME(ModelType, ModelType, Backend)

#define REGISTER_MULTIMODAL_PROCESSOR_WITH_VARNAME(              \
    VarName, ModelType, ProcessorClass)                          \
  const bool VarName##_multimodal_processor_registered = []() {  \
    ModelRegistry::register_multimodal_processor_factory(        \
        #ModelType,                                              \
        [](const ModelArgs& model_args,                          \
           std::shared_ptr<Tokenizer> tokenizer,                 \
           const TokenizerArgs& tokenizer_args) {                \
          return std::make_unique<ProcessorClass>(               \
              model_args, std::move(tokenizer), tokenizer_args); \
        });                                                      \
    return true;                                                 \
  }()

#define REGISTER_MULTIMODAL_PROCESSOR(ModelType, ProcessorClass) \
  REGISTER_MULTIMODAL_PROCESSOR_WITH_VARNAME(                    \
      ModelType, ModelType, ProcessorClass)

// Macro to register a model args loader with the ModelRegistry
#define REGISTER_MODEL_ARGS_LOADER_WITH_VARNAME(VarName, ModelType, Loader) \
  const bool VarName##_args_loader_registered = []() {                      \
    ModelRegistry::register_model_args_loader(#ModelType, Loader);          \
    return true;                                                            \
  }()

#define REGISTER_MODEL_ARGS_LOADER(ModelType, Loader) \
  REGISTER_MODEL_ARGS_LOADER_WITH_VARNAME(ModelType, ModelType, Loader)

#define REGISTER_MODEL_ARGS_WITH_VARNAME(VarName, ModelType, ...)       \
  REGISTER_MODEL_ARGS_LOADER_WITH_VARNAME(                              \
      VarName, ModelType, [](const JsonReader& json, ModelArgs* args) { \
        UNUSED_PARAMETER(json);                                         \
        UNUSED_PARAMETER(args);                                         \
        __VA_ARGS__();                                                  \
        return true;                                                    \
      })

#define REGISTER_MODEL_ARGS(ModelType, ...) \
  REGISTER_MODEL_ARGS_WITH_VARNAME(ModelType, ModelType, __VA_ARGS__)

// Macro to register a quantization args loader with the ModelRegistry
#define REGISTER_QUANT_ARGS_LOADER_WITH_VARNAME(VarName, ModelType, Loader) \
  const bool VarName##_quant_args_loader_registered = []() {                \
    ModelRegistry::register_quant_args_loader(#ModelType, Loader);          \
    return true;                                                            \
  }()

#define REGISTER_QUANT_ARGS_LOADER(ModelType, Loader) \
  REGISTER_QUANT_ARGS_LOADER_WITH_VARNAME(ModelType, ModelType, Loader)

// Macro to register a tokenizer args loader with the ModelRegistry
#define REGISTER_TOKENIZER_ARGS_LOADER_WITH_VARNAME(                   \
    VarName, ModelType, Loader)                                        \
  const bool VarName##_tokenizer_args_loader_registered = []() {       \
    ModelRegistry::register_tokenizer_args_loader(#ModelType, Loader); \
    return true;                                                       \
  }()

#define REGISTER_TOKENIZER_ARGS_LOADER(ModelType, Loader) \
  REGISTER_TOKENIZER_ARGS_LOADER_WITH_VARNAME(ModelType, ModelType, Loader)

#define REGISTER_TOKENIZER_ARGS_WITH_VARNAME(VarName, ModelType, ...)       \
  REGISTER_TOKENIZER_ARGS_LOADER_WITH_VARNAME(                              \
      VarName, ModelType, [](const JsonReader& json, TokenizerArgs* args) { \
        UNUSED_PARAMETER(json);                                             \
        UNUSED_PARAMETER(args);                                             \
        __VA_ARGS__();                                                      \
        return true;                                                        \
      })

#define REGISTER_TOKENIZER_ARGS(ModelType, ...) \
  REGISTER_TOKENIZER_ARGS_WITH_VARNAME(ModelType, ModelType, __VA_ARGS__)

#define LOAD_ARG(arg_name, json_name)                          \
  [&] {                                                        \
    auto value = args->arg_name();                             \
    using value_type = remove_optional_t<decltype(value)>;     \
    if (auto data_value = json.value<value_type>(json_name)) { \
      args->arg_name() = data_value.value();                   \
    }                                                          \
  }()

#define LOAD_ARG_OR(arg_name, json_name, default_value)                     \
  [&] {                                                                     \
    auto value = args->arg_name();                                          \
    using value_type = remove_optional_t<decltype(value)>;                  \
    args->arg_name() = json.value_or<value_type>(json_name, default_value); \
  }()

#define LOAD_ARG_OR_FUNC(arg_name, json_name, ...)             \
  [&] {                                                        \
    auto value = args->arg_name();                             \
    using value_type = remove_optional_t<decltype(value)>;     \
    if (auto data_value = json.value<value_type>(json_name)) { \
      args->arg_name() = data_value.value();                   \
    } else {                                                   \
      args->arg_name() = __VA_ARGS__();                        \
    }                                                          \
  }()

#define SET_ARG(arg_name, value) [&] { args->arg_name() = value; }()

}  // namespace xllm
