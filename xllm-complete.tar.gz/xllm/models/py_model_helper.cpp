/* Copyright 2025-2026 The xLLM Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://github.com/xLLM-AI/xllm/blob/main/LICENSE

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

// Infrastructure for the embedded Python model executor:
// - Interpreter lifecycle (ensure_python_interpreter)
// - Weight loading (PyStateDict Python binding)
// - Config serialization (dtype_to_string, PyDictVisitor)

#include "models/py_model_helper.h"

#include <Python.h>
#include <c10/util/Exception.h>
#include <glog/logging.h>
#include <pybind11/embed.h>
#include <torch/extension.h>

#include <cstdlib>
#include <mutex>
#include <string>

#include "core/framework/config/model_config.h"
#include "core/framework/state_dict/state_dict.h"
#include "core/kernels/xllm_torch_ops.h"
#include "core/kv_cache/storage/kv_cache.h"
#include "core/util/pybind_helper.h"

namespace py = pybind11;

namespace xllm {

namespace {

void prepend_sys_path(const std::string& dir) {
  if (dir.empty()) {
    return;
  }
  py::module_ sys = py::module_::import("sys");
  py::list path = py::reinterpret_borrow<py::list>(sys.attr("path"));
  for (auto item : path) {
    if (py::isinstance<py::str>(item) && item.cast<std::string>() == dir) {
      return;
    }
  }
  path.attr("insert")(0, py::str(dir));
}

}  // namespace

py::list build_python_kv_caches(const std::vector<KVCache>& kv_caches) {
  py::list python_caches;
  for (const auto& kv_cache : kv_caches) {
    python_caches.append(py::make_tuple(
        optional_tensor(kv_cache.get_k_cache()),
        optional_tensor(kv_cache.get_v_cache()),
        optional_tensor(kv_cache.get_index_cache()),
        optional_tensor(kv_cache.get_conv_cache()),
        optional_tensor(kv_cache.get_ssm_cache()),
        optional_tensor(kv_cache.get_swa_cache()),
        optional_tensor(kv_cache.get_compress_kv_state()),
        optional_tensor(kv_cache.get_compress_score_state()),
        optional_tensor(kv_cache.get_compress_index_kv_state()),
        optional_tensor(kv_cache.get_compress_index_score_state()),
        optional_tensor(kv_cache.get_indexer_cache_scale()),
        optional_tensor(kv_cache.get_kpool_tail())));
  }
  return python_caches;
}

// ---------------------------------------------------------------------------
// dtype_to_string
// ---------------------------------------------------------------------------

std::string dtype_to_string(const torch::TensorOptions& options) {
  switch (c10::typeMetaToScalarType(options.dtype())) {
    case torch::kBFloat16:
      return "bfloat16";
    case torch::kFloat16:
      return "float16";
    case torch::kFloat32:
      return "float32";
    case torch::kFloat64:
      return "float64";
    default:
      return "bfloat16";
  }
}

// ---------------------------------------------------------------------------
// ensure_python_interpreter
// ---------------------------------------------------------------------------

void ensure_python_interpreter() {
  static std::once_flag flag;
  std::call_once(flag, []() {
    ensure_xllm_torch_ops_registered();

    const bool we_initialized = !Py_IsInitialized();
    if (we_initialized) {
#if defined(USE_NPU)
      setenv("TORCH_DEVICE_BACKEND_AUTOLOAD", "0", 0);
#endif
      py::initialize_interpreter(/*init_signal_handlers=*/false);
    }

    {
      py::gil_scoped_acquire gil;
      std::string model_path = ModelConfig::get_instance().python_model_path();
      if (model_path.empty()) {
        const char* env = std::getenv("XLLM_PYTHON_MODEL_PATH");
        if (env != nullptr) {
          model_path = env;
        }
      }
      prepend_sys_path(model_path);
      const char* phase = "importing xllm.python";
      try {
#if defined(USE_NPU)
        if (we_initialized) {
          phase = "importing xllm.python._npu_bootstrap";
          py::module_::import("xllm.python._npu_bootstrap");
        }
#endif
        phase = "importing xllm.python";
        py::module_ python_package = py::module_::import("xllm.python");
        phase = "initializing xllm.python runtime";
        python_package.attr("initialize_runtime")();
      } catch (const py::error_already_set& e) {
        LOG(FATAL) << "Failed while " << phase << " (python_model_path='"
                   << model_path << "'; empty uses the default Python path). "
                   << e.what();
      }
    }

    if (we_initialized) {
      PyEval_SaveThread();
    }
  });
}

// ---------------------------------------------------------------------------
// PyStateDict
// ---------------------------------------------------------------------------

torch::Tensor PyStateDict::get_tensor(const std::string& name) const {
  CHECK(sd_ != nullptr) << "PyStateDict: access after release";
  return sd_->get_tensor(name);
}

bool PyStateDict::has(const std::string& name) const {
  CHECK(sd_ != nullptr) << "PyStateDict: access after release";
  return sd_->has(name);
}

py::list PyStateDict::keys() const {
  CHECK(sd_ != nullptr) << "PyStateDict: access after release";
  py::list result;
  for (const auto& [key, _] : *sd_) {
    result.append(py::str(key));
  }
  return result;
}

void ensure_xllm_weight_loader_module() {
  py::module_ sys = py::module_::import("sys");
  py::dict modules = py::reinterpret_borrow<py::dict>(sys.attr("modules"));
  const py::str module_name("xllm_weight_loader");
  if (modules.contains(module_name)) {
    return;
  }

  py::object module_object =
      py::module_::import("types").attr("ModuleType")(module_name);
  py::module_ module = py::reinterpret_borrow<py::module_>(module_object);
  py::class_<PyStateDict>(module, "StateDict")
      .def("get_tensor", &PyStateDict::get_tensor, py::arg("name"))
      .def("has", &PyStateDict::has, py::arg("name"))
      .def("keys", &PyStateDict::keys);
  modules[module_name] = module;
}

}  // namespace xllm
