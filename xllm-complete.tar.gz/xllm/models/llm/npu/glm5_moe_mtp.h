/* Copyright 2025-2026 The xLLM Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://github.com/xLLM-AI/xllm/blob/main/LICENSE

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#pragma once

#include <string>
#include <unordered_set>
#include <vector>

#include "core/layers/common/rotary_embedding_util.h"
#include "deepseek_v32.h"
#include "models/llm/npu/glm_shared_expert_stream.h"
#include "mtp_model_base.h"

namespace xllm::npu::model {

class GlmMoeDsaMtpModelImpl
    : private GlmSharedExpertStreamOwner,
      public xllm::npu::model::MtpModelImplBase<DeepseekV32DecoderLayer> {
 public:
  GlmMoeDsaMtpModelImpl(const ModelContext& context)
      : GlmSharedExpertStreamOwner(context),
        xllm::npu::model::MtpModelImplBase<DeepseekV32DecoderLayer>(
            "glm_moe_dsa_mtp",
            context) {
    auto model_args = context.get_model_args();
    auto options = context.get_tensor_options();

    int32_t mask_value = model_args.dtype() == "bfloat16" ? 1 : -9984;
    attn_mask_ = layer::AttentionMask(options.device(),
                                      options.dtype().toScalarType(),
                                      /*mask_value=*/mask_value);

    cos_sin_ = layer::rotary::get_concat_rotary_embedding(
        model_args.qk_rope_head_dim(),
        model_args.max_position_embeddings(),
        model_args.rope_theta(),
        options);
  }

 protected:
  void forward_layer(DeepseekV32DecoderLayer& layer,
                     torch::Tensor& h,
                     torch::Tensor& cos_pos,
                     torch::Tensor& sin_pos,
                     torch::Tensor& attn_mask,
                     KVCache& kv_cache,
                     const ModelParamsView& input_params,
                     torch::Tensor& topk_indices,
                     int32_t layer_index,
                     aclrtEvent* event,
                     std::atomic<bool>* event_flag) override {
    layer->forward_with_mtp_topk(h,
                                 cos_pos,
                                 sin_pos,
                                 attn_mask,
                                 kv_cache,
                                 input_params,
                                 topk_indices,
                                 index_topk_,
                                 device_,
                                 layer_index,
                                 event,
                                 event_flag);
  }
};
TORCH_MODULE(GlmMoeDsaMtpModel);

class GlmMoeDsaMtpForCausalLMImpl
    : public xllm::npu::model::MtpForCausalLMImplBase<GlmMoeDsaMtpModel> {
 public:
  GlmMoeDsaMtpForCausalLMImpl(const ModelContext& context)
      : xllm::npu::model::MtpForCausalLMImplBase<GlmMoeDsaMtpModel>(context) {}
};
TORCH_MODULE(GlmMoeDsaMtpForCausalLM);

// register the causal model
REGISTER_CAUSAL_MODEL(glm_moe_dsa_mtp, GlmMoeDsaMtpForCausalLM);

REGISTER_MODEL_ARGS(
    glm_moe_dsa_mtp,
    ([&] {
      LOAD_ARG_OR(model_type, "model_type", "glm_moe_dsa_mtp");
      LOAD_ARG_OR(dtype, "dtype", "");
      LOAD_ARG_OR(attention_bias, "attention_bias", false);
      LOAD_ARG_OR(attention_dropout, "attention_dropout", 0.0f);

      LOAD_ARG_OR(vocab_size, "vocab_size", 154880);
      LOAD_ARG_OR(hidden_size, "hidden_size", 6144);
      LOAD_ARG_OR(n_layers, "num_hidden_layers", 1);
      LOAD_ARG_OR(n_heads, "num_attention_heads", 64);
      LOAD_ARG_OR(n_kv_heads, "num_key_value_heads", 64);
      LOAD_ARG_OR(intermediate_size, "intermediate_size", 12288);
      LOAD_ARG_OR(max_position_embeddings, "max_position_embeddings", 202752);
      LOAD_ARG_OR(rms_norm_eps, "rms_norm_eps", 1e-5);
      LOAD_ARG_OR_FUNC(eos_token_id_vec, "eos_token_id", [&] {
        return std::vector<int32_t>{154820, 154827, 154829};
      });
      LOAD_ARG_OR(bos_token_id, "bos_token_id", 0);
      LOAD_ARG_OR(rope_theta, "rope_parameters.rope_theta", 1000000.0f);

      LOAD_ARG_OR(use_sliding_window, "use_sliding_window", false);
      LOAD_ARG_OR(sliding_window, "sliding_window", 4096);
      LOAD_ARG_OR(max_window_layers, "max_window_layers", 61);

      LOAD_ARG_OR(first_k_dense_replace, "first_k_dense_replace", 3);
      LOAD_ARG_OR(hidden_act, "hidden_act", "silu");
      LOAD_ARG_OR(moe_layer_freq, "moe_layer_freq", 1);
      LOAD_ARG_OR(topk_method, "topk_method", "noaux_tc");
      LOAD_ARG_OR(n_routed_experts, "n_routed_experts", 256);
      LOAD_ARG_OR(n_shared_experts, "n_shared_experts", 1);
      LOAD_ARG_OR(num_experts_per_tok, "num_experts_per_tok", 8);
      LOAD_ARG_OR(moe_intermediate_size, "moe_intermediate_size", 2048);
      LOAD_ARG_OR(routed_scaling_factor, "routed_scaling_factor", 2.5f);
      LOAD_ARG_OR(norm_topk_prob, "norm_topk_prob", true);
      LOAD_ARG_OR(n_group, "n_group", 1);
      LOAD_ARG_OR(topk_group, "topk_group", 1);
      LOAD_ARG_OR(scoring_func, "scoring_func", "sigmoid");
      LOAD_ARG_OR(qk_nope_head_dim, "qk_nope_head_dim", 192);
      LOAD_ARG_OR(qk_rope_head_dim, "qk_rope_head_dim", 64);
      LOAD_ARG_OR(v_head_dim, "v_head_dim", 256);
      LOAD_ARG_OR(q_lora_rank, "q_lora_rank", 2048);
      LOAD_ARG_OR(kv_lora_rank, "kv_lora_rank", 512);
      LOAD_ARG_OR(index_head_dim, "index_head_dim", 128);
      LOAD_ARG_OR(num_nextn_predict_layers, "num_nextn_predict_layers", 1);
      LOAD_ARG_OR(index_n_heads, "index_n_heads", 32);
      LOAD_ARG_OR(index_topk, "index_topk", 2048);
      LOAD_ARG_OR(index_topk_freq, "index_topk_freq", 1);
      LOAD_ARG_OR(index_topk_pattern, "index_topk_pattern", "");
      LOAD_ARG_OR(index_skip_topk_offset, "index_skip_topk_offset", 0);
      LOAD_ARG_OR(indexer_types, "indexer_types", std::vector<std::string>());
      LOAD_ARG_OR(
          mlp_layer_types, "mlp_layer_types", std::vector<std::string>());
      LOAD_ARG_OR(index_share_for_mtp_iteration,
                  "index_share_for_mtp_iteration",
                  false);

      LOAD_ARG_OR(use_qk_norm, "use_qk_norm", true);
      LOAD_ARG_OR(indexer_rope_interleave, "indexer_rope_interleave", true);
      LOAD_ARG_OR(rope_theta, "rope_theta", args->rope_theta());
      LOAD_ARG_OR(tie_word_embeddings, "tie_word_embeddings", false);

      SET_ARG(head_dim, args->qk_nope_head_dim() + args->qk_rope_head_dim());
      LOAD_ARG_OR_FUNC(
          rotary_dim, "rotary_dim", [&] { return args->qk_rope_head_dim(); });

      SET_ARG(stop_token_ids,
              std::unordered_set<int32_t>(args->eos_token_id_vec().begin(),
                                          args->eos_token_id_vec().end()));
    }));

REGISTER_TOKENIZER_ARGS(glm_moe_dsa_mtp, [&] {
  const std::vector<std::string> parser_visible_special_tokens({"<tool_call>",
                                                                "</tool_call>",
                                                                "<arg_key>",
                                                                "</arg_key>",
                                                                "<arg_value>",
                                                                "</arg_value>",
                                                                "<think>",
                                                                "</think>"});
  SET_ARG(visible_special_tokens, parser_visible_special_tokens);
});
}  // namespace xllm::npu::model
