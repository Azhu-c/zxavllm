# Copyright 2026 The xLLM Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/xLLM-AI/xllm/blob/main/LICENSE
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""CUDA kernels.

``xllm.python.initialize_runtime()`` binds this package as
``xllm.python.kernels`` when the active platform is CUDA, so layers and models
import one fixed path and carry no hardware branch. Its peers -- ``kernels_npu``
and any package added for new hardware -- are bound the same way on their own
platform. Exactly one of them is initialized in a process; they share no code
and never import each other. ``setup.py`` ships only the package matching
``--device``.

Launchers live under ``triton/`` and ``flashinfer/``; the modules here bind one
kernel per name in ``__all__``. Peer packages export the same names, so a name
without a CUDA kernel is still exported here, raising
:class:`NotImplementedError` and carrying the signature an implementation has
to meet.
"""

from __future__ import annotations

from .activation import dequant_swiglu_quant, silu_and_mul
from .attention import (
    batch_matmul_transpose,
    reshape_paged_cache,
    update_decode_graph_metadata,
    vision_fusion_attention,
)
from .causal_conv1d import (
    causal_conv1d_decode,
    causal_conv1d_prefill,
)
from .gated_delta_net import (
    chunk_gated_delta_rule,
    fused_gdn_prefill_post_conv,
    fused_recurrent_gated_delta_rule_packed_decode,
    resolve_gdn_prefill_backend,
)
from .linear import (
    prepare_quant_weight,
    prepare_row_parallel_weight,
)
from .mla import (
    deepseek_mla_preprocess_decode,
    deepseek_mla_preprocess_decode_v2,
    has_mla_preprocess_v2,
    prepare_mla_preprocess_v2_q_b,
    prepare_mla_preprocess_v2_qkv,
)
from .moe import (
    cutlass_fused_moe,
    fused_moe,
    grouped_moe,
    moe_expert_compute,
    moe_fused_topk,
    moe_gate_routing,
    moe_gmm1,
    moe_gmm2_combine,
    moe_token_dispatch,
    prepare_grouped_moe_weights,
    supports_cutlass_moe,
)
from .normalization import (
    fused_add_rms_norm,
    fused_add_rms_norm_dynamic_quant,
    gemma_rms_norm,
    l2_norm,
    rms_norm,
    rms_norm_gated,
)
from .quantization import (
    dynamic_quant,
    quant_matmul,
    quantize_per_tensor,
)
from .rotary_embedding import (
    apply_qk_rotary,
    fused_qk_norm_rope,
    has_fused_qk_rotary,
    inplace_partial_rotary_mul,
    interleaved_rotary_embedding,
    mrope,
    vision_rotary_mul,
)
from .sparse_attention import (
    lightning_indexer,
    lightning_indexer_out,
    quant_lightning_indexer,
    quant_lightning_indexer_metadata,
    scatter_nd_update,
    sparse_flash_attention,
    sparse_flash_attention_lse,
    sparse_flash_attention_out,
)


def _initialize_runtime() -> None:
    """Register native-op FakeTensor implementations when CUDA is selected."""
    from . import _custom_op  # noqa: F401


__all__ = [
    "rms_norm",
    "gemma_rms_norm",
    "fused_add_rms_norm",
    "fused_add_rms_norm_dynamic_quant",
    "l2_norm",
    "rms_norm_gated",
    "silu_and_mul",
    "dequant_swiglu_quant",
    "reshape_paged_cache",
    "update_decode_graph_metadata",
    "vision_fusion_attention",
    "batch_matmul_transpose",
    "fused_qk_norm_rope",
    "apply_qk_rotary",
    "has_fused_qk_rotary",
    "inplace_partial_rotary_mul",
    "interleaved_rotary_embedding",
    "mrope",
    "vision_rotary_mul",
    "moe_fused_topk",
    "cutlass_fused_moe",
    "fused_moe",
    "grouped_moe",
    "moe_gate_routing",
    "moe_expert_compute",
    "moe_token_dispatch",
    "moe_gmm1",
    "moe_gmm2_combine",
    "prepare_grouped_moe_weights",
    "supports_cutlass_moe",
    "prepare_row_parallel_weight",
    "prepare_quant_weight",
    "deepseek_mla_preprocess_decode",
    "deepseek_mla_preprocess_decode_v2",
    "has_mla_preprocess_v2",
    "prepare_mla_preprocess_v2_q_b",
    "prepare_mla_preprocess_v2_qkv",
    "quant_matmul",
    "quantize_per_tensor",
    "dynamic_quant",
    "lightning_indexer",
    "lightning_indexer_out",
    "quant_lightning_indexer",
    "quant_lightning_indexer_metadata",
    "scatter_nd_update",
    "sparse_flash_attention",
    "sparse_flash_attention_out",
    "sparse_flash_attention_lse",
    "causal_conv1d_prefill",
    "causal_conv1d_decode",
    "resolve_gdn_prefill_backend",
    "fused_gdn_prefill_post_conv",
    "fused_recurrent_gated_delta_rule_packed_decode",
    "chunk_gated_delta_rule",
]
