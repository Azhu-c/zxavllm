/**
 * Copyright (c) 2025-2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef CATLASS_GEMM_TILE_COPY_L1_TO_L0A_HPP
#define CATLASS_GEMM_TILE_COPY_L1_TO_L0A_HPP

#if (defined(CATLASS_ARCH) && CATLASS_ARCH == 2201)
#include "catlass/gemm/tile/atlasa2/copy_l1_to_l0a.hpp"
#endif
#if (defined(CATLASS_ARCH) && CATLASS_ARCH == 3510)
#include "catlass/gemm/tile/ascend950/copy_l1_to_l0a.hpp"
#endif

#endif
