#
# Copyright (c) 2026 Huawei Technologies Co., Ltd. All Rights Reserved.
# This file is a part of the vllm-ascend project.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from collections.abc import Callable

import torch
from vllm.distributed import get_tp_group
from vllm.distributed.eplb.eplb_state import EplbLayerState

from vllm_ascend.ascend_forward_context import _EXTRA_CTX, MoECommType
from vllm_ascend.device.device_op import DeviceOperator
from vllm_ascend.distributed.utils import split_tensor_along_first_dim
from vllm_ascend.ops.fused_moe.router.grouped_topk_router import AscendGroupedTopKRouter


class AscendFusedTopKRouter(AscendGroupedTopKRouter):
    """Router adapter that uses Ascend's existing expert-selection path."""

    def __init__(
        self,
        top_k: int,
        global_num_experts: int,
        renormalize: bool = True,
        use_grouped_topk: bool = False,
        num_expert_group: int | None = None,
        topk_group: int | None = None,
        custom_routing_function: Callable | None = None,
        scoring_func: str = "softmax",
        routed_scaling_factor: float = 1.0,
        e_score_correction_bias: torch.Tensor | None = None,
        eplb_state: EplbLayerState | None = None,
        num_logical_experts: int | None = None,
        tid2eid: torch.Tensor | None = None,
        select_experts_fn: Callable[..., tuple[torch.Tensor, torch.Tensor]] | None = None,
    ):
        super().__init__(
            top_k=top_k,
            global_num_experts=global_num_experts,
            num_expert_group=num_expert_group,
            topk_group=topk_group,
            eplb_state=eplb_state,
        )
        self.renormalize = renormalize
        self.use_grouped_topk = use_grouped_topk
        self.num_expert_group = num_expert_group
        self.topk_group = topk_group
        self.custom_routing_function = custom_routing_function
        self.scoring_func = scoring_func
        self.routed_scaling_factor = routed_scaling_factor
        self.e_score_correction_bias = e_score_correction_bias
        self.num_logical_experts = num_logical_experts if num_logical_experts is not None else global_num_experts
        self.tid2eid = tid2eid

    def is_fused_supported(
        self,
        hidden_states: torch.Tensor,
    ) -> bool:
        topk_group = self.topk_group if self.topk_group is not None else 1
        num_expert_group = self.num_expert_group if self.num_expert_group is not None else 1
        if not (
            num_expert_group > 0
            and hidden_states.shape[-1] % num_expert_group == 0
            and hidden_states.shape[-1] // num_expert_group > 2
        ):
            return False
        if self.top_k > (hidden_states.shape[-1] / (num_expert_group * topk_group)):
            return False
        if topk_group * hidden_states.shape[-1] / num_expert_group < self.top_k:  # noqa: SIM103
            return False
        return True

    def _compute_routing(
        self,
        hidden_states: torch.Tensor,
        router_logits: torch.Tensor,
        indices_type: torch.dtype | None,
        *,
        input_ids: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if not self.is_fused_supported(hidden_states):
            return super()._compute_routing(
                hidden_states=hidden_states,
                router_logits=router_logits,
                indices_type=indices_type,
                input_ids=input_ids,
            )

        topk_group = self.topk_group if self.topk_group is not None else 1
        num_expert_group = self.num_expert_group if self.num_expert_group is not None else 1
        renorm = int(self.renormalize)
        if self.scoring_func == "sqrtsoftplus":
            if self.tid2eid is not None:
                if input_ids is None:
                    raise ValueError("DeepSeek V4 hash MoE routing requires input_ids.")
                input_ids = input_ids.to(torch.int64)
                tid2eid_ones = self.tid2eid.to(torch.int32)
                if _EXTRA_CTX.moe_comm_type == MoECommType.ALLGATHER:
                    prepare_finalize = _EXTRA_CTX.moe_comm_method.prepare_finalize
                    input_ids = prepare_finalize.all_gather_input_id_with_dp_group(input_ids)
                else:
                    input_ids = _EXTRA_CTX.moe_comm_method.pad_and_split_input_ids(input_ids)

                if _EXTRA_CTX.flash_comm_v1_enabled and _EXTRA_CTX.moe_comm_type != MoECommType.ALLGATHER:
                    # Process for Flash Comm V1
                    tp_size = get_tp_group().world_size
                    tp_rank = get_tp_group().rank_in_group
                    splitted_input = split_tensor_along_first_dim(input_ids, num_partitions=tp_size)
                    input_ids = splitted_input[tp_rank].contiguous()
                input_ids = torch.where(input_ids == -1, 0, input_ids)
            else:
                input_ids = None
                tid2eid_ones = None
            topk_weights, topk_ids, _ = torch.ops._C_ascend.moe_gating_top_k_hash(
                x=router_logits,
                k=self.top_k,
                bias=self.e_score_correction_bias,
                input_ids=input_ids,
                tid2eid=tid2eid_ones,
                k_group=topk_group,
                group_count=num_expert_group,
                routed_scaling_factor=self.routed_scaling_factor,
                eps=1e-20,
                group_select_mode=1,
                # The hash custom op currently rejects renorm != 0. Apply
                # norm_topk_prob in Python below before returning to MoE compute.
                renorm=0,
                norm_type=2,
                out_flag=False,
            )
            return topk_weights, topk_ids
        norm_type = 0 if self.scoring_func == "softmax" else 1
        if self.e_score_correction_bias is not None and self.e_score_correction_bias.dtype != router_logits.dtype:
            self.e_score_correction_bias = self.e_score_correction_bias.to(router_logits.dtype)
        topk_weights, topk_ids, _ = DeviceOperator.moe_gating_top_k(
            router_logits,
            k=self.top_k,
            k_group=topk_group,
            group_count=num_expert_group,
            group_select_mode=1,
            renorm=renorm,
            norm_type=norm_type,  # 0: softmax; 1: sigmoid
            out_flag=False,
            routed_scaling_factor=self.routed_scaling_factor,
            eps=1e-20,
            bias_opt=self.e_score_correction_bias,
        )

        return topk_weights, topk_ids
