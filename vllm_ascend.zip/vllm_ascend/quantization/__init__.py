#
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
# This file is a part of the vllm-ascend project.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""Ascend quantization module.

This module intentionally avoids eager imports so that importing lightweight
submodules (for example ``quant_type``) does not trigger heavy registration
paths and circular imports during startup.
"""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .compressed_tensors_config import AscendCompressedTensorsConfig
    from .fp8_config import AscendFp8Config
    from .modelslim_config import AscendModelSlimConfig

__all__ = ["AscendModelSlimConfig", "AscendCompressedTensorsConfig", "AscendFp8Config"]


def __getattr__(name: str) -> Any:
    if name == "AscendModelSlimConfig":
        from .modelslim_config import AscendModelSlimConfig

        return AscendModelSlimConfig
    if name == "AscendCompressedTensorsConfig":
        from .compressed_tensors_config import AscendCompressedTensorsConfig

        return AscendCompressedTensorsConfig
    if name == "AscendFp8Config":
        from .fp8_config import AscendFp8Config

        return AscendFp8Config
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
